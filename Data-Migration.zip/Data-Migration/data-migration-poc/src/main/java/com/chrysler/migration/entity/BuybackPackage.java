package com.chrysler.migration.entity;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MapsId;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.LazyToOne;
import org.hibernate.annotations.LazyToOneOption;

/**
 * The persistent class for the BUYBACK_PACKAGE database table.
 * 
 */
@Entity
@Table(name = "BYBK_PKG")
@NamedQuery(name = "BuybackPackage.findAll", query = "SELECT b FROM BuybackPackage b")
public class BuybackPackage extends AuditColumns implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private int iBybk;

	@Column(name = "I_BYBK_PKG_CASE")
	private String iBybkPkgCase;

	@Column(name = "I_LAW_CASE")
	private String iLawCase;

	@Column(name = "L_ARB_CASE_FILED")
	private String lArbCaseFiled;

	@Column(name = "L_DSPSL_ONLY")
	private String lDspslOnly;

	@Column(name = "L_LEMON_LAW_FILED")
	private String lLemonLawFiled;

	@Column(name = "L_REP_VHCL")
	private String lRepVhcl;

	@Column(name = "N_SALES_DLR")
	private String nSalesDlr;

	@Column(name = "N_SERV_DLR")
	private String nServDlr;

	@Column(name = "T_ARB")
	private Timestamp tArb;

	@Column(name = "T_LEGL_LTR")
	private Timestamp tLeglLtr;

	@Column(name = "T_RE_ACQSN")
	private Timestamp tReAcqsn;

	@Column(name = "X_BUS_CENTR")
	private String xBusCentr;

	@Column(name = "X_BYBK_PKG_REAS")
	private String xBybkPkgReas;

	@Column(name = "I_REAQ_BOD")
	private String iReaqBod;

	@Column(name = "I_BODID")
	private String I_BODID;

	// bi-directional one-to-one association to Buyback
	@OneToOne(fetch = FetchType.LAZY)
	@MapsId
	@LazyToOne(LazyToOneOption.NO_PROXY)
	@JoinColumn(name = "I_BYBK")
	private Buyback buyback;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_BYBK_PKG_TYP")
	private CodeMaster packageType;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_BYBK_PKG_CATGY")
	private CodeMaster packageCategory;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_BYBK_PKG_STATE")
	private CodeMaster packageState;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_ARB_DECN")
	private CodeMaster arbitrationDecision;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_SALES_BUS_CENTR")
	private CodeMaster salesBC;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_SERV_BUS_CENTR")
	private CodeMaster serviceBC;

	public BuybackPackage() {
	}

	public int getIBybk() {
		return this.iBybk;
	}

	public void setIBybk(int iBybk) {
		this.iBybk = iBybk;
	}

	public String getIBybkPkgCase() {
		return this.iBybkPkgCase;
	}

	public void setIBybkPkgCase(String iBybkPkgCase) {
		this.iBybkPkgCase = iBybkPkgCase;
	}

	public String getILawCase() {
		return this.iLawCase;
	}

	public void setILawCase(String iLawCase) {
		this.iLawCase = iLawCase;
	}

	public String getLArbCaseFiled() {
		return this.lArbCaseFiled;
	}

	public void setLArbCaseFiled(String lArbCaseFiled) {
		this.lArbCaseFiled = lArbCaseFiled;
	}

	public String getLLemonLawFiled() {
		return this.lLemonLawFiled;
	}

	public void setLLemonLawFiled(String lLemonLawFiled) {
		this.lLemonLawFiled = lLemonLawFiled;
	}

	public String getLRepVhcl() {
		return this.lRepVhcl;
	}

	public void setLRepVhcl(String lRepVhcl) {
		this.lRepVhcl = lRepVhcl;
	}

	public String getNSalesDlr() {
		return this.nSalesDlr;
	}

	public void setNSalesDlr(String nSalesDlr) {
		this.nSalesDlr = nSalesDlr;
	}

	public String getNServDlr() {
		return this.nServDlr;
	}

	public void setNServDlr(String nServDlr) {
		this.nServDlr = nServDlr;
	}

	public Timestamp getTArb() {
		return this.tArb;
	}

	public void setTArb(Timestamp tArb) {
		this.tArb = tArb;
	}

	public Timestamp getTLeglLtr() {
		return this.tLeglLtr;
	}

	public void setTLeglLtr(Timestamp tLeglLtr) {
		this.tLeglLtr = tLeglLtr;
	}

	public Timestamp getTReAcqsn() {
		return this.tReAcqsn;
	}

	public void setTReAcqsn(Timestamp tReAcqsn) {
		this.tReAcqsn = tReAcqsn;
	}

	public String getXBusCentr() {
		return this.xBusCentr;
	}

	public void setXBusCentr(String xBusCentr) {
		this.xBusCentr = xBusCentr;
	}

	public String getXBybkPkgReas() {
		return this.xBybkPkgReas;
	}

	public void setXBybkPkgReas(String xBybkPkgReas) {
		this.xBybkPkgReas = xBybkPkgReas;
	}

	public Buyback getBuyback() {
		return this.buyback;
	}

	public void setBuyback(Buyback buyback) {
		this.buyback = buyback;
	}

	public CodeMaster getPackageType() {
		return this.packageType;
	}

	public void setPackageType(CodeMaster packageType) {
		this.packageType = packageType;
	}

	public CodeMaster getPackageCategory() {
		return this.packageCategory;
	}

	public void setPackageCategory(CodeMaster packageCategory) {
		this.packageCategory = packageCategory;
	}

	public CodeMaster getPackageState() {
		return this.packageState;
	}

	public void setPackageState(CodeMaster packageState) {
		this.packageState = packageState;
	}

	public CodeMaster getArbitrationDecision() {
		return this.arbitrationDecision;
	}

	public void setArbitrationDecision(CodeMaster arbitrationDecision) {
		this.arbitrationDecision = arbitrationDecision;
	}

	public CodeMaster getSalesBC() {
		return this.salesBC;
	}

	public void setSalesBC(CodeMaster salesBC) {
		this.salesBC = salesBC;
	}

	public CodeMaster getServiceBC() {
		return this.serviceBC;
	}

	public void setServiceBC(CodeMaster serviceBC) {
		this.serviceBC = serviceBC;
	}

	public String getiReaqBod() {
		return iReaqBod;
	}

	public void setiReaqBod(String iReaqBod) {
		this.iReaqBod = iReaqBod;
	}

	public String getI_BODID() {
		return I_BODID;
	}

	public void setI_BODID(String i_BODID) {
		I_BODID = i_BODID;
	}

	public String getDisposalOnly() {
		return lDspslOnly;
	}

	public void setDisposalOnly(String lDspslOnly) {
		this.lDspslOnly = lDspslOnly;
	}

}