package com.chrysler.migration.entity;

import java.io.Serializable;
import java.sql.Time;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * The persistent class for the CNTNT_MGR database table.
 * 
 */
@Entity
@Table(name = "CNTNT_MGR")
@NamedQuery(name = "CntntMgr.findAll", query = "SELECT c FROM CntntMgr c")

public class CntntMgr extends AuditColumns implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "I_CNTNT_MGR_SEQ")
	private int iCntntMgrSeq;

	@Temporal(TemporalType.DATE)
	@Column(name = "D_CAIR_CREATD")
	private Date dCairCreatd;

	@Temporal(TemporalType.DATE)
	@Column(name = "D_CAPTR")
	private Date dCaptr;

	@Temporal(TemporalType.DATE)
	@Column(name = "D_LTR_REC")
	private Date dLtrRec;

	@Temporal(TemporalType.DATE)
	@Column(name = "D_POST_MRK")
	private Date dPostMrk;

	@Column(name = "I_CAIR")
	private String iCair;

	@Column(name = "I_CAPTR_USER")
	private String iCaptrUser;

	@Column(name = "I_CNTNT_MGR")
	private String iCntntMgr;

	@Column(name = "I_PG_CNT")
	private int iPgCnt;

	@Column(name = "I_VIN_FIRST")
	private String iVinFirst;

	@Column(name = "I_VIN_LAST")
	private String iVinLast;

	@Column(name = "L_UPLD")
	private String lUpld;

	@Column(name = "N_CAPTR_WKSTATN")
	private String nCaptrWkstatn;

	@Column(name = "N_DOCU_TYP")
	private String nDocuTyp;

	@Column(name = "N_FILE")
	private String nFile;

	@Column(name = "N_FIRST")
	private String nFirst;

	@Column(name = "N_LANG_TYP")
	private String nLangTyp;

	@Column(name = "N_MID")
	private String nMid;

	@Column(name = "N_PKG_OTHR")
	private String nPkgOthr;

	@Column(name = "N_SEC")
	private String nSec;

	@Column(name = "N_SRCE_TYP")
	private String nSrceTyp;

	@Column(name = "T_CAPTR")
	private Time tCaptr;

	@Column(name = "T_UPLD")
	private Time tUpld;

	@Column(name = "X_CAPTR_DATE_FORMT")
	private String xCaptrDateFormt;

	@Column(name = "X_FLEX2")
	private String xFlex2;

	@Column(name = "X_WCCS_ITEM_TYPE")
	private String xWccsItemType;

	// bi-directional many-to-one association to Bybk
	@Column(name = "X_FLEX1")
	private Integer buybackId;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_PKG_DOCU_TYP")
	private CodeMaster codeMaster;

	@Column(name = "L_UPLD_STAT")
	private String lUpldStat;

	@Column(name = "X_TEMPRY_LOC")
	private String xTempryLoc;

	public CntntMgr() {
	}

	public String getlUpldStat() {
		return lUpldStat;
	}

	public void setlUpldStat(String lUpldStat) {
		this.lUpldStat = lUpldStat;
	}

	public String getxTempryLoc() {
		return xTempryLoc;
	}

	public void setxTempryLoc(String xTempryLoc) {
		this.xTempryLoc = xTempryLoc;
	}

	public int getICntntMgrSeq() {
		return this.iCntntMgrSeq;
	}

	public void setICntntMgrSeq(int iCntntMgrSeq) {
		this.iCntntMgrSeq = iCntntMgrSeq;
	}

	public Date getDCairCreatd() {
		return this.dCairCreatd;
	}

	public void setDCairCreatd(Date dCairCreatd) {
		this.dCairCreatd = dCairCreatd;
	}

	public Date getDCaptr() {
		return this.dCaptr;
	}

	public void setDCaptr(Date dCaptr) {
		this.dCaptr = dCaptr;
	}

	public Date getDLtrRec() {
		return this.dLtrRec;
	}

	public void setDLtrRec(Date dLtrRec) {
		this.dLtrRec = dLtrRec;
	}

	public Date getDPostMrk() {
		return this.dPostMrk;
	}

	public void setDPostMrk(Date dPostMrk) {
		this.dPostMrk = dPostMrk;
	}

	public String getICair() {
		return this.iCair;
	}

	public void setICair(String iCair) {
		this.iCair = iCair;
	}

	public String getICaptrUser() {
		return this.iCaptrUser;
	}

	public void setICaptrUser(String iCaptrUser) {
		this.iCaptrUser = iCaptrUser;
	}

	public String getICntntMgr() {
		return this.iCntntMgr;
	}

	public void setICntntMgr(String iCntntMgr) {
		this.iCntntMgr = iCntntMgr;
	}

	public int getIPgCnt() {
		return this.iPgCnt;
	}

	public void setIPgCnt(int iPgCnt) {
		this.iPgCnt = iPgCnt;
	}

	public String getIVinFirst() {
		return this.iVinFirst;
	}

	public void setIVinFirst(String iVinFirst) {
		this.iVinFirst = iVinFirst;
	}

	public String getIVinLast() {
		return this.iVinLast;
	}

	public void setIVinLast(String iVinLast) {
		this.iVinLast = iVinLast;
	}

	public String getLUpld() {
		return this.lUpld;
	}

	public void setLUpld(String lUpld) {
		this.lUpld = lUpld;
	}

	public String getNCaptrWkstatn() {
		return this.nCaptrWkstatn;
	}

	public void setNCaptrWkstatn(String nCaptrWkstatn) {
		this.nCaptrWkstatn = nCaptrWkstatn;
	}

	public String getNDocuTyp() {
		return this.nDocuTyp;
	}

	public void setNDocuTyp(String nDocuTyp) {
		this.nDocuTyp = nDocuTyp;
	}

	public String getNFile() {
		return this.nFile;
	}

	public void setNFile(String nFile) {
		this.nFile = nFile;
	}

	public String getNFirst() {
		return this.nFirst;
	}

	public void setNFirst(String nFirst) {
		this.nFirst = nFirst;
	}

	public String getNLangTyp() {
		return this.nLangTyp;
	}

	public void setNLangTyp(String nLangTyp) {
		this.nLangTyp = nLangTyp;
	}

	public String getNMid() {
		return this.nMid;
	}

	public void setNMid(String nMid) {
		this.nMid = nMid;
	}

	public String getNPkgOthr() {
		return this.nPkgOthr;
	}

	public void setNPkgOthr(String nPkgOthr) {
		this.nPkgOthr = nPkgOthr;
	}

	public String getNSec() {
		return this.nSec;
	}

	public void setNSec(String nSec) {
		this.nSec = nSec;
	}

	public String getNSrceTyp() {
		return this.nSrceTyp;
	}

	public void setNSrceTyp(String nSrceTyp) {
		this.nSrceTyp = nSrceTyp;
	}

	public Time getTCaptr() {
		return this.tCaptr;
	}

	public void setTCaptr(Time tCaptr) {
		this.tCaptr = tCaptr;
	}

	public Time getTUpld() {
		return this.tUpld;
	}

	public void setTUpld(Time tUpld) {
		this.tUpld = tUpld;
	}

	public String getXCaptrDateFormt() {
		return this.xCaptrDateFormt;
	}

	public void setXCaptrDateFormt(String xCaptrDateFormt) {
		this.xCaptrDateFormt = xCaptrDateFormt;
	}

	public String getXFlex2() {
		return this.xFlex2;
	}

	public void setXFlex2(String xFlex2) {
		this.xFlex2 = xFlex2;
	}

	public String getXWccsItemType() {
		return this.xWccsItemType;
	}

	public void setXWccsItemType(String xWccsItemType) {
		this.xWccsItemType = xWccsItemType;
	}

	public Integer getBuybackId() {
		return buybackId;
	}

	public void setBuybackId(Integer buybackId) {
		this.buybackId = buybackId;
	}

	public CodeMaster getCodeMaster() {
		return this.codeMaster;
	}

	public void setCodeMaster(CodeMaster codeMaster) {
		this.codeMaster = codeMaster;
	}

}