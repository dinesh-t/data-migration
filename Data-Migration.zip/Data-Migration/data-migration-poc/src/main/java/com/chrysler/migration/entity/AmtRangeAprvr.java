package com.chrysler.migration.entity;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * The persistent class for the AMT_RANGE_APRVR database table.
 * 
 */
@Entity
@Table(name = "AMT_RANGE_APRVR")
@NamedQuery(name = "AmtRangeAprvr.findAll", query = "SELECT a FROM AmtRangeAprvr a")
public class AmtRangeAprvr extends AuditColumns implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "I_AMT_SEQ")
	private Integer iAmtSeq;

	@Column(name = "A_RANGE_FROM")
	private BigDecimal aRangeFrom;

	@Column(name = "A_RANGE_TO")
	private BigDecimal aRangeTo;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_APRVR_STAT")
	private CodeMaster approverStatus;

	// bi-directional many-to-one association to Role
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_FLD_ROLE")
	private TypeMaster fleldRole;

	// bi-directional many-to-one association to Role
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_LEGL_ROLE")
	private TypeMaster legalRole;

	// bi-directional many-to-one association to Role
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_ISG_ROLE")
	private CodeMaster isgRole;

	@Column(name = "L_LEGL_APRVL_STAT")
	private String lLeglAprvlStat;

	@Column(name = "L_LEGL_UNDER_STAT")
	private String lLegalUnderStat;

	@Column(name = "L_LEGL_PEND_STAT")
	private String lLeglPendStat;

	@Column(name = "L_OTHR_APRVL_STAT")
	private String lOthrAprvlStat;

	@Column(name = "L_OTHR_UNDER_STAT")
	private String lOthrUnderStat;

	@Column(name = "L_OTHR_PEND_STAT")
	private String lOthrPend;

	public AmtRangeAprvr() {
		// Constructor
	}

	public int getIAmtSeq() {
		return this.iAmtSeq;
	}

	public void setIAmtSeq(int iAmtSeq) {
		this.iAmtSeq = iAmtSeq;
	}

	public BigDecimal getARangeFrom() {
		return this.aRangeFrom;
	}

	public void setARangeFrom(BigDecimal aRangeFrom) {
		this.aRangeFrom = aRangeFrom;
	}

	public BigDecimal getARangeTo() {
		return this.aRangeTo;
	}

	public void setARangeTo(BigDecimal aRangeTo) {
		this.aRangeTo = aRangeTo;
	}

	public CodeMaster getApproverStatus() {
		return this.approverStatus;
	}

	public void setApproverStatus(CodeMaster approverStatus) {
		this.approverStatus = approverStatus;
	}

	public TypeMaster getFleldRole() {
		return fleldRole;
	}

	public void setFleldRole(TypeMaster fleldRole) {
		this.fleldRole = fleldRole;
	}

	public TypeMaster getLegalRole() {
		return legalRole;
	}

	public void setLegalRole(TypeMaster legalRole) {
		this.legalRole = legalRole;
	}

	public CodeMaster getIsgRole() {
		return isgRole;
	}

	public void setIsgRole(CodeMaster isgRole) {
		this.isgRole = isgRole;
	}

	/**
	 * @return the lLeglAprvlStat
	 */
	public String getlLeglAprvlStat() {
		return lLeglAprvlStat;
	}

	/**
	 * @param lLeglAprvlStat
	 *            the lLeglAprvlStat to set
	 */
	public void setlLeglAprvlStat(String lLeglAprvlStat) {
		this.lLeglAprvlStat = lLeglAprvlStat;
	}

	/**
	 * @return the lLeglPendStat
	 */
	public String getlLeglPendStat() {
		return lLeglPendStat;
	}

	/**
	 * @param lLeglPendStat
	 *            the lLeglPendStat to set
	 */
	public void setlLeglPendStat(String lLeglPendStat) {
		this.lLeglPendStat = lLeglPendStat;
	}

	/**
	 * @return the lOthrAprvlStat
	 */
	public String getlOthrAprvlStat() {
		return lOthrAprvlStat;
	}

	/**
	 * @param lOthrAprvlStat
	 *            the lOthrAprvlStat to set
	 */
	public void setlOthrAprvlStat(String lOthrAprvlStat) {
		this.lOthrAprvlStat = lOthrAprvlStat;
	}

	/**
	 * @return the lOthrUnderStat
	 */
	public String getlOthrUnderStat() {
		return lOthrUnderStat;
	}

	/**
	 * @param lOthrUnderStat
	 *            the lOthrUnderStat to set
	 */
	public void setlOthrUnderStat(String lOthrUnderStat) {
		this.lOthrUnderStat = lOthrUnderStat;
	}

	/**
	 * @return the lLegalUnderStat
	 */
	public String getlLegalUnderStat() {
		return lLegalUnderStat;
	}

	/**
	 * @param lLegalUnderStat
	 *            the lLegalUnderStat to set
	 */
	public void setlLegalUnderStat(String lLegalUnderStat) {
		this.lLegalUnderStat = lLegalUnderStat;
	}

	/**
	 * @return the lOthrPend
	 */
	public String getlOthrPend() {
		return lOthrPend;
	}

	/**
	 * @param lOthrPend
	 *            the lOthrPend to set
	 */
	public void setlOthrPend(String lOthrPend) {
		this.lOthrPend = lOthrPend;
	}

}