package com.chrysler.migration.entity;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The persistent class for the PRIMARY_PROB_MAPPING database table.
 * 
 */
@Entity
@Table(name = "PRIMARY_PROB_MAPG")
@NamedQuery(name = "PrimaryProbMapping.findAll", query = "SELECT p FROM PrimaryProbMapping p")
public class PrimaryProbMapping extends AuditColumns implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "I_PRMRY_PROB_SEQ")
	private Integer iPrmryProbSeq;

	@Column(name = "X_PROB_DESC")
	private String xProbDesc;

	@Column(name = "X_REAS_DESC")
	private String xReasDesc;
	
	// bi-directional many-to-one association to CodeMaster
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "I_PRMRY_PROB_CATGY")
	private CodeMaster primaryProblemCategory;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "I_REAS_PROB")
	private CodeMaster problem;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "I_PRMRY_PROB_TYP")
	private CodeMaster problemType;

	public PrimaryProbMapping() {
		//
	}

	public Integer getiPrmryProbSeq() {
		return iPrmryProbSeq;
	}

	public void setiPrmryProbSeq(Integer iPrmryProbSeq) {
		this.iPrmryProbSeq = iPrmryProbSeq;
	}

	public String getXProbDesc() {
		return this.xProbDesc;
	}

	public void setXProbDesc(String xProbDesc) {
		this.xProbDesc = xProbDesc;
	}

	public String getXReasDesc() {
		return this.xReasDesc;
	}

	public void setXReasDesc(String xReasDesc) {
		this.xReasDesc = xReasDesc;
	}

	public CodeMaster getPrimaryProblemCategory() {
		return primaryProblemCategory;
	}

	public void setPrimaryProblemCategory(CodeMaster primaryProblemCategory) {
		this.primaryProblemCategory = primaryProblemCategory;
	}

	public CodeMaster getProblem() {
		return problem;
	}

	public void setProblem(CodeMaster problem) {
		this.problem = problem;
	}

	public CodeMaster getProblemType() {
		return problemType;
	}

	public void setProblemType(CodeMaster problemType) {
		this.problemType = problemType;
	}

}