package com.chrysler.migration.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedAttributeNode;
import javax.persistence.NamedEntityGraph;
import javax.persistence.NamedQuery;
import javax.persistence.NamedSubgraph;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.LazyToOne;
import org.hibernate.annotations.LazyToOneOption;

/**
 * The persistent class for the BUYBACK database table.
 * 
 */
@Entity
@Table(name = "BYBK")
@NamedQuery(name = "Buyback.findAll", query = "SELECT b FROM Buyback b")
@NamedEntityGraph(name = "buyback.templateSubmittedBy.findEager", attributeNodes = {
		@NamedAttributeNode(value = "templateSubmittedBy", subgraph = "templateSubmittedBy") }, subgraphs = {
				@NamedSubgraph(name = "templateSubmittedBy", attributeNodes = @NamedAttributeNode(value = "bussinessCenterCode")) })
public class Buyback extends AuditColumns implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "I_BYBK_SEQ")
	private Integer iBybkSeq;

	@Column(name = "A_BYBK")
	private BigDecimal aBybk;

	@Column(name = "A_RCVY")
	private BigDecimal aRcvy;

	@Column(name = "I_BYBK_CAIR")
	private String iBybkCair;

	@Column(name = "I_BYBK_CASE")
	private String iBybkCase;

	@Column(name = "I_BYBK_VIN")
	private String iBybkVin;

	@Column(name = "I_LOCKED_BY")
	private String iLockedBy;

	@Column(name = "I_TMPLT_CAIR")
	private String iTmpltCair;

	@Column(name = "T_BYBK_COMPL")
	private Timestamp tBybkCompl;

	@Column(name = "T_LOCKED")
	private Timestamp tLocked;

	@Column(name = "T_TMPLT_APRVL")
	private Timestamp tTmpltAprvl;

	@Column(name = "T_TMPLT_SUBMT")
	private Timestamp tTmpltSubmt;

	@Column(name = "X_APRVR_COMNT")
	private String xAprvrComnt;

	@Column(name = "X_BYBK_APRVL_COMNT")
	private String xBybkAprvlComnt;

	@Column(name = "X_BYBK_COMNT")
	private String xBybkComnt;

	@Column(name = "X_DSPSL_APRV_COMNT")
	private String xDspslAprvComnt;

	@Column(name = "I_BODID")
	private String I_BODID;

	@Column(name = "D_DSPSL_SUBMTD")
	private Timestamp dDspslSubmtd;

	@Column(name = "D_RECAL")
	private Timestamp dRecal;

	@Column(name = "C_RECAL_TYP")
	private String cRecalTyp;

	@Column(name = "I_RECAL_NMBR")
	private String iRecalNmbr;

	@Column(name = "L_RECAL")
	private String lRecal;

	@Column(name = "C_RECAL_STAT")
	private String cRecalStat;

	@Column(name = "D_DSPSL_CREATD")
	private Timestamp dDspslCreatd;

	// bi-directional many-to-one association to AuditTrailField
	@OneToMany(mappedBy = "buyback", fetch = FetchType.LAZY)
	@Cascade({ org.hibernate.annotations.CascadeType.SAVE_UPDATE, org.hibernate.annotations.CascadeType.DELETE,
			org.hibernate.annotations.CascadeType.MERGE, org.hibernate.annotations.CascadeType.PERSIST })
	private Set<AuditTrailField> auditTrailFields;

	// bi-directional many-to-one association to AuditTrailFunction
	@OneToMany(mappedBy = "buyback", fetch = FetchType.LAZY)
	@Cascade({ org.hibernate.annotations.CascadeType.SAVE_UPDATE, org.hibernate.annotations.CascadeType.DELETE,
			org.hibernate.annotations.CascadeType.MERGE, org.hibernate.annotations.CascadeType.PERSIST })
	private Set<AuditTrailFunction> auditTrailFunctions;

	// bi-directional one-to-one association to BusinessCenterInformation
	@OneToOne(mappedBy = "buyback", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@LazyToOne(LazyToOneOption.NO_PROXY)
	private BusinessCenterInformation businessCenterInformation;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_BYBK_TYP")
	private CodeMaster buybackTypeCode;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_BYBK_TMPLT")
	private CodeMaster buybackTemplateCode;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_TMPLT_STAT")
	private CodeMaster buybackTemplateStatusCode;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_BYBK_REAS")
	private CodeMaster buybackReasonCode;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_BYBK_APRVL_REAS")
	private CodeMaster buybackApprovalReasonCode;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_DSPSL_APRVL_REAS")
	private CodeMaster disposalApprovalReasonCode;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_MNR_STAT")
	private CodeMaster minorStatusCode;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_BYBK_PKG_STAT")
	private CodeMaster buybackPackageStatusCode;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_DSPSL_STAT")
	private CodeMaster disposalStatusCode;

	// bi-directional many-to-one association to User
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_TMPLT_APRVL_USER")
	private User templateApprovedBy;

	// bi-directional many-to-one association to User
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_TMPLT_SUBMT_USER")
	private User templateSubmittedBy;

	// bi-directional one-to-one association to BuybackApproval
	@OneToOne(mappedBy = "buyback", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@LazyToOne(LazyToOneOption.NO_PROXY)
	private BuybackApproval buybackApproval;

	// bi-directional many-to-one association to BuybackAttachment
	@OneToMany(mappedBy = "buyback")
	@Cascade({ org.hibernate.annotations.CascadeType.SAVE_UPDATE, org.hibernate.annotations.CascadeType.DELETE,
			org.hibernate.annotations.CascadeType.MERGE, org.hibernate.annotations.CascadeType.PERSIST })
	private Set<BuybackAttachment> buybackAttachments;

	// bi-directional one-to-one association to BuybackDisposal
	@OneToOne(mappedBy = "buyback", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@LazyToOne(LazyToOneOption.NO_PROXY)
	private BuybackDisposal buybackDisposal;

	// bi-directional many-to-one association to BuybackDisposalReason
	@OneToMany(mappedBy = "buyback", cascade = CascadeType.REMOVE, orphanRemoval = true)
	// TODO should work with JPA CascadeType.REMOVE instead of adding hibernate
	// @Cascade
	@Cascade({ org.hibernate.annotations.CascadeType.SAVE_UPDATE, org.hibernate.annotations.CascadeType.DELETE,
			org.hibernate.annotations.CascadeType.MERGE, org.hibernate.annotations.CascadeType.PERSIST })
	private Set<BuybackDisposalReason> buybackDisposalReasons;

	// bi-directional one-to-one association to BuybackEntryLogical
	@OneToOne(mappedBy = "buyback", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@LazyToOne(LazyToOneOption.NO_PROXY)
	private BuybackEntryLogical buybackEntryLogical;

	// bi-directional many-to-one association to BuybackEntryOffset
	@OneToMany(mappedBy = "buyback", cascade = CascadeType.REMOVE, orphanRemoval = true)
	@Cascade({ org.hibernate.annotations.CascadeType.SAVE_UPDATE, org.hibernate.annotations.CascadeType.DELETE,
			org.hibernate.annotations.CascadeType.MERGE, org.hibernate.annotations.CascadeType.PERSIST })
	private Set<BuybackEntryOffset> buybackEntryOffsets;

	// bi-directional one-to-one association to BuybackPackage
	@OneToOne(mappedBy = "buyback", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@LazyToOne(LazyToOneOption.NO_PROXY)
	private BuybackPackage buybackPackage;

	// bi-directional one-to-one association to BuybackPackage
	@OneToOne(mappedBy = "buyback", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@LazyToOne(LazyToOneOption.NO_PROXY)
	private GoodWillPackage goodWillPackage;

	// bi-directional one-to-one association to BuybackReason
	@OneToOne(mappedBy = "buyback", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@LazyToOne(LazyToOneOption.NO_PROXY)
	private BuybackReason buybackReason;

	// bi-directional many-to-one association to BybkCnResaleState
	@OneToMany(mappedBy = "buyback", cascade = CascadeType.REMOVE, orphanRemoval = true)
	@Cascade({ org.hibernate.annotations.CascadeType.SAVE_UPDATE, org.hibernate.annotations.CascadeType.DELETE,
			org.hibernate.annotations.CascadeType.MERGE, org.hibernate.annotations.CascadeType.PERSIST })
	private Set<BybkCnResaleState> bybkCnResaleStates;

	// bi-directional many-to-one association to BybkPagApproval
	@OneToMany(mappedBy = "buyback")
	@Cascade({ org.hibernate.annotations.CascadeType.SAVE_UPDATE, org.hibernate.annotations.CascadeType.DELETE,
			org.hibernate.annotations.CascadeType.MERGE, org.hibernate.annotations.CascadeType.PERSIST })
	private Set<BybkPagApproval> bybkPagApprovals;

	// bi-directional many-to-one association to BybkReasProbMapg
	@OneToMany(mappedBy = "buyback", cascade = CascadeType.REMOVE, orphanRemoval = true)
	@Cascade({ org.hibernate.annotations.CascadeType.SAVE_UPDATE, org.hibernate.annotations.CascadeType.DELETE,
			org.hibernate.annotations.CascadeType.MERGE, org.hibernate.annotations.CascadeType.PERSIST })
	private Set<BybkReasProbMapg> bybkReasProbMapgs;

	// bi-directional one-to-one association to CashAndKeep
	@OneToOne(mappedBy = "buyback", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@LazyToOne(LazyToOneOption.NO_PROXY)
	private CashAndKeep cashAndKeep;

	// bi-directional one-to-one association to CashAndKeepPackage
	@OneToOne(mappedBy = "buyback", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@LazyToOne(LazyToOneOption.NO_PROXY)
	private CashAndKeepPackage cashAndKeepPackage;

	// bi-directional many-to-one association to Check
	@OneToMany(mappedBy = "buyback", cascade = CascadeType.REMOVE, orphanRemoval = true)
	@Cascade({ org.hibernate.annotations.CascadeType.SAVE_UPDATE, org.hibernate.annotations.CascadeType.DELETE,
			org.hibernate.annotations.CascadeType.MERGE, org.hibernate.annotations.CascadeType.PERSIST })
	private Set<Check> checks;

	// bi-directional one-to-one association to CustomerDetail
	@OneToOne(mappedBy = "buyback", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@LazyToOne(LazyToOneOption.NO_PROXY)
	private CustomerDetail customerDetail;

	// bi-directional many-to-one association to DealerDetail
	@OneToMany(mappedBy = "buyback", cascade = CascadeType.REMOVE, orphanRemoval = true)
	@Cascade({ org.hibernate.annotations.CascadeType.SAVE_UPDATE, org.hibernate.annotations.CascadeType.DELETE,
			org.hibernate.annotations.CascadeType.MERGE, org.hibernate.annotations.CascadeType.PERSIST })
	private Set<BuybackDealerDetail> dealerDetails;

	// bi-directional one-to-one association to GoodWillTrade
	@OneToOne(mappedBy = "buyback", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@LazyToOne(LazyToOneOption.NO_PROXY)
	private GoodWillTrade goodWillTrade;

	// bi-directional one-to-one association to LegalEntry
	@OneToOne(mappedBy = "buyback", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@LazyToOne(LazyToOneOption.NO_PROXY)
	private LegalEntry legalEntry;

	// bi-directional many-to-one association to PackageDisposalDocu
	@OneToMany(mappedBy = "bybk", cascade = CascadeType.ALL)
	@Cascade({ org.hibernate.annotations.CascadeType.SAVE_UPDATE, org.hibernate.annotations.CascadeType.DELETE,
			org.hibernate.annotations.CascadeType.MERGE, org.hibernate.annotations.CascadeType.PERSIST })
	private Set<PackageDisposalDocu> packageDisposalDocus;

	// bi-directional one-to-one association to VehicleDetail
	@OneToOne(mappedBy = "buyback", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@LazyToOne(LazyToOneOption.NO_PROXY)
	private VehicleDetail vehicleDetail;

	// bi-directional one-to-one association to Warranty
	@OneToOne(mappedBy = "buyback", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@LazyToOne(LazyToOneOption.NO_PROXY)
	private Warranty warranty;

	// bi-directional many-to-one association to DisclsrVehicleOwner
	@OneToMany(mappedBy = "iBybk", cascade = CascadeType.ALL)
	@Cascade({ org.hibernate.annotations.CascadeType.SAVE_UPDATE, org.hibernate.annotations.CascadeType.DELETE,
			org.hibernate.annotations.CascadeType.MERGE, org.hibernate.annotations.CascadeType.PERSIST })
	private Set<DisclsrVehicleOwner> disclsrVehicleOwners;

	// bi-directional one-to-one association to BybkPkgMilgOffset
	@OneToOne(mappedBy = "bybk", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	private BybkPkgMilgOffset bybkPkgMilgOffset;

	// bi-directional many-to-one association to BybkPkgFinW

	@OneToMany(mappedBy = "bybk", cascade = CascadeType.REMOVE, orphanRemoval = true)
	@Cascade({ org.hibernate.annotations.CascadeType.SAVE_UPDATE, org.hibernate.annotations.CascadeType.DELETE,
			org.hibernate.annotations.CascadeType.MERGE, org.hibernate.annotations.CascadeType.PERSIST })
	private Set<BybkPkgFinW> bybkPkgFinWs;

	@OneToOne(mappedBy = "buyback", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@LazyToOne(LazyToOneOption.NO_PROXY)
	private BuybackDisposalRecovery buybackDisposalRecovery;

	public BuybackDisposalRecovery getBuybackDisposalRecovery() {
		return buybackDisposalRecovery;
	}

	public void setBuybackDisposalRecovery(BuybackDisposalRecovery buybackDisposalRecovery) {
		this.buybackDisposalRecovery = buybackDisposalRecovery;
	}

	@Column(name = "L_REAQ_SYS")
	private String lReaqSys;

	@Column(name = "D_PKG_CREATD")
	private Timestamp dPkgCreatd;

	@Column(name = "D_PKG_SUBMTD")
	private Timestamp dPkgSubmtd;

	@Column(name = "D_PKG_FINAL_APRVD")
	private Timestamp dPkgFinalAprvd;

	@Column(name = "L_CAIR_CREATE_SYS")
	private String lCairCreateSys;

	@Column(name = "C_SOLD_DLR")
	private String cSoldDlr;

	@Column(name = "N_SOLD_CUST")
	private String nSoldCust;

	@Column(name = "I_RLATD_CAIR")
	private String iRlatdCair;

	@Column(name = "I_DISCLSR_TYP")
	private Integer iDisclsrTyp;

	@Column(name = "D_SOLD_DLR")
	private Timestamp dSoldDlr;

	@Column(name = "D_SOLD_CUST")
	private Timestamp dSoldCust;

	public Buyback() {
		// Constructor
	}

	public BybkPkgMilgOffset getBybkPkgMilgOffset() {
		return bybkPkgMilgOffset;
	}

	public void setBybkPkgMilgOffset(BybkPkgMilgOffset bybkPkgMilgOffset) {
		this.bybkPkgMilgOffset = bybkPkgMilgOffset;
	}

	public Set<BybkPkgFinW> getBybkPkgFinWs() {
		return bybkPkgFinWs;
	}

	public void setBybkPkgFinWs(Set<BybkPkgFinW> bybkPkgFinWs) {
		this.bybkPkgFinWs = bybkPkgFinWs;
	}

	public Integer getIBybkSeq() {
		return this.iBybkSeq;
	}

	public void setIBybkSeq(Integer iBybkSeq) {
		this.iBybkSeq = iBybkSeq;
	}

	public BigDecimal getABybk() {
		return this.aBybk;
	}

	public void setABybk(BigDecimal aBybk) {
		this.aBybk = aBybk;
	}

	public BigDecimal getARcvy() {
		return this.aRcvy;
	}

	public void setARcvy(BigDecimal aRcvy) {
		this.aRcvy = aRcvy;
	}

	public String getIBybkCair() {
		return this.iBybkCair;
	}

	public void setIBybkCair(String iBybkCair) {
		this.iBybkCair = iBybkCair;
	}

	public String getIBybkCase() {
		return this.iBybkCase;
	}

	public void setIBybkCase(String iBybkCase) {
		this.iBybkCase = iBybkCase;
	}

	public String getIBybkVin() {
		return this.iBybkVin;
	}

	public void setIBybkVin(String iBybkVin) {
		this.iBybkVin = iBybkVin;
	}

	public String getILockedBy() {
		return this.iLockedBy;
	}

	public void setILockedBy(String iLockedBy) {
		this.iLockedBy = iLockedBy;
	}

	public String getITmpltCair() {
		return this.iTmpltCair;
	}

	public void setITmpltCair(String iTmpltCair) {
		this.iTmpltCair = iTmpltCair;
	}

	public Timestamp getTBybkCompl() {
		return this.tBybkCompl;
	}

	public void setTBybkCompl(Timestamp tBybkCompl) {
		this.tBybkCompl = tBybkCompl;
	}

	public Timestamp getTLocked() {
		return this.tLocked;
	}

	public void setTLocked(Timestamp tLocked) {
		this.tLocked = tLocked;
	}

	public Timestamp getTTmpltAprvl() {
		return this.tTmpltAprvl;
	}

	public void setTTmpltAprvl(Timestamp tTmpltAprvl) {
		this.tTmpltAprvl = tTmpltAprvl;
	}

	public Timestamp getTTmpltSubmt() {
		return this.tTmpltSubmt;
	}

	public void setTTmpltSubmt(Timestamp tTmpltSubmt) {
		this.tTmpltSubmt = tTmpltSubmt;
	}

	public String getXAprvrComnt() {
		return this.xAprvrComnt;
	}

	public void setXAprvrComnt(String xAprvrComnt) {
		this.xAprvrComnt = xAprvrComnt;
	}

	public String getXBybkAprvlComnt() {
		return this.xBybkAprvlComnt;
	}

	public void setXBybkAprvlComnt(String xBybkAprvlComnt) {
		this.xBybkAprvlComnt = xBybkAprvlComnt;
	}

	public String getXBybkComnt() {
		return this.xBybkComnt;
	}

	public void setXBybkComnt(String xBybkComnt) {
		this.xBybkComnt = xBybkComnt;
	}

	public String getXDspslAprvComnt() {
		return this.xDspslAprvComnt;
	}

	public void setXDspslAprvComnt(String xDspslAprvComnt) {
		this.xDspslAprvComnt = xDspslAprvComnt;
	}

	public Set<AuditTrailField> getAuditTrailFields() {
		return this.auditTrailFields;
	}

	public void setAuditTrailFields(Set<AuditTrailField> auditTrailFields) {
		this.auditTrailFields = auditTrailFields;
	}

	public AuditTrailField addAuditTrailField(AuditTrailField auditTrailField) {
		getAuditTrailFields().add(auditTrailField);
		auditTrailField.setBuyback(this);

		return auditTrailField;
	}

	public AuditTrailField removeAuditTrailField(AuditTrailField auditTrailField) {
		getAuditTrailFields().remove(auditTrailField);
		auditTrailField.setBuyback(null);

		return auditTrailField;
	}

	public Set<AuditTrailFunction> getAuditTrailFunctions() {
		return this.auditTrailFunctions;
	}

	public void setAuditTrailFunctions(Set<AuditTrailFunction> auditTrailFunctions) {
		this.auditTrailFunctions = auditTrailFunctions;
	}

	public AuditTrailFunction addAuditTrailFunction(AuditTrailFunction auditTrailFunction) {
		getAuditTrailFunctions().add(auditTrailFunction);
		auditTrailFunction.setBuyback(this);

		return auditTrailFunction;
	}

	public AuditTrailFunction removeAuditTrailFunction(AuditTrailFunction auditTrailFunction) {
		getAuditTrailFunctions().remove(auditTrailFunction);
		auditTrailFunction.setBuyback(null);

		return auditTrailFunction;
	}

	public BusinessCenterInformation getBusinessCenterInformation() {
		return this.businessCenterInformation;
	}

	public void setBusinessCenterInformation(BusinessCenterInformation businessCenterInformation) {
		this.businessCenterInformation = businessCenterInformation;
	}

	public CodeMaster getBuybackTypeCode() {
		return buybackTypeCode;
	}

	public void setBuybackTypeCode(CodeMaster buybackTypeCode) {
		this.buybackTypeCode = buybackTypeCode;
	}

	public CodeMaster getBuybackTemplateCode() {
		return buybackTemplateCode;
	}

	public void setBuybackTemplateCode(CodeMaster buybackTemplateCode) {
		this.buybackTemplateCode = buybackTemplateCode;
	}

	public CodeMaster getBuybackTemplateStatusCode() {
		return buybackTemplateStatusCode;
	}

	public void setBuybackTemplateStatusCode(CodeMaster buybackTemplateStatusCode) {
		this.buybackTemplateStatusCode = buybackTemplateStatusCode;
	}

	public CodeMaster getBuybackReasonCode() {
		return buybackReasonCode;
	}

	public void setBuybackReasonCode(CodeMaster buybackReasonCode) {
		this.buybackReasonCode = buybackReasonCode;
	}

	public CodeMaster getBuybackApprovalReasonCode() {
		return buybackApprovalReasonCode;
	}

	public void setBuybackApprovalReasonCode(CodeMaster buybackApprovalReasonCode) {
		this.buybackApprovalReasonCode = buybackApprovalReasonCode;
	}

	public CodeMaster getDisposalApprovalReasonCode() {
		return disposalApprovalReasonCode;
	}

	public void setDisposalApprovalReasonCode(CodeMaster disposalApprovalReasonCode) {
		this.disposalApprovalReasonCode = disposalApprovalReasonCode;
	}

	public CodeMaster getMinorStatusCode() {
		return minorStatusCode;
	}

	public void setMinorStatusCode(CodeMaster minorStatusCode) {
		this.minorStatusCode = minorStatusCode;
	}

	public CodeMaster getBuybackPackageStatusCode() {
		return buybackPackageStatusCode;
	}

	public void setBuybackPackageStatusCode(CodeMaster buybackPackageStatusCode) {
		this.buybackPackageStatusCode = buybackPackageStatusCode;
	}

	public CodeMaster getDisposalStatusCode() {
		return disposalStatusCode;
	}

	public void setDisposalStatusCode(CodeMaster disposalStatusCode) {
		this.disposalStatusCode = disposalStatusCode;
	}

	public User getTemplateApprovedBy() {
		return templateApprovedBy;
	}

	public void setTemplateApprovedBy(User templateApprovedBy) {
		this.templateApprovedBy = templateApprovedBy;
	}

	public User getTemplateSubmittedBy() {
		return templateSubmittedBy;
	}

	public void setTemplateSubmittedBy(User templateSubmittedBy) {
		this.templateSubmittedBy = templateSubmittedBy;
	}

	public BuybackApproval getBuybackApproval() {
		return this.buybackApproval;
	}

	public void setBuybackApproval(BuybackApproval buybackApproval) {
		this.buybackApproval = buybackApproval;
	}

	public Set<BuybackAttachment> getBuybackAttachments() {
		return this.buybackAttachments;
	}

	public void setBuybackAttachments(Set<BuybackAttachment> buybackAttachments) {
		this.buybackAttachments = buybackAttachments;
	}

	public BuybackAttachment addBuybackAttachment(BuybackAttachment buybackAttachment) {
		getBuybackAttachments().add(buybackAttachment);
		buybackAttachment.setBuyback(this);

		return buybackAttachment;
	}

	public BuybackAttachment removeBuybackAttachment(BuybackAttachment buybackAttachment) {
		getBuybackAttachments().remove(buybackAttachment);
		buybackAttachment.setBuyback(null);

		return buybackAttachment;
	}

	public BuybackDisposal getBuybackDisposal() {
		return this.buybackDisposal;
	}

	public void setBuybackDisposal(BuybackDisposal buybackDisposal) {
		this.buybackDisposal = buybackDisposal;
	}

	public Set<BuybackDisposalReason> getBuybackDisposalReasons() {
		return this.buybackDisposalReasons;
	}

	public void setBuybackDisposalReasons(Set<BuybackDisposalReason> buybackDisposalReasons) {
		this.buybackDisposalReasons = buybackDisposalReasons;
	}

	public BuybackDisposalReason addBuybackDisposalReason(BuybackDisposalReason buybackDisposalReason) {
		getBuybackDisposalReasons().add(buybackDisposalReason);
		buybackDisposalReason.setBuyback(this);

		return buybackDisposalReason;
	}

	public BuybackDisposalReason removeBuybackDisposalReason(BuybackDisposalReason buybackDisposalReason) {
		getBuybackDisposalReasons().remove(buybackDisposalReason);
		buybackDisposalReason.setBuyback(null);

		return buybackDisposalReason;
	}

	public BuybackEntryLogical getBuybackEntryLogical() {
		return this.buybackEntryLogical;
	}

	public void setBuybackEntryLogical(BuybackEntryLogical buybackEntryLogical) {
		this.buybackEntryLogical = buybackEntryLogical;
	}

	public Set<BuybackEntryOffset> getBuybackEntryOffsets() {
		return this.buybackEntryOffsets;
	}

	public void setBuybackEntryOffsets(Set<BuybackEntryOffset> buybackEntryOffsets) {
		this.buybackEntryOffsets = buybackEntryOffsets;
	}

	public BuybackEntryOffset addBuybackEntryOffset(BuybackEntryOffset buybackEntryOffset) {
		getBuybackEntryOffsets().add(buybackEntryOffset);
		buybackEntryOffset.setBuyback(this);

		return buybackEntryOffset;
	}

	public BuybackEntryOffset removeBuybackEntryOffset(BuybackEntryOffset buybackEntryOffset) {
		getBuybackEntryOffsets().remove(buybackEntryOffset);
		buybackEntryOffset.setBuyback(null);

		return buybackEntryOffset;
	}

	public BuybackPackage getBuybackPackage() {
		return this.buybackPackage;
	}

	public void setBuybackPackage(BuybackPackage buybackPackage) {
		this.buybackPackage = buybackPackage;
	}

	public BuybackReason getBuybackReason() {
		return this.buybackReason;
	}

	public void setBuybackReason(BuybackReason buybackReason) {
		this.buybackReason = buybackReason;
	}

	public Set<BybkCnResaleState> getBybkCnResaleStates() {
		return this.bybkCnResaleStates;
	}

	public void setBybkCnResaleStates(Set<BybkCnResaleState> bybkCnResaleStates) {
		this.bybkCnResaleStates = bybkCnResaleStates;
	}

	public BybkCnResaleState addBybkCnResaleState(BybkCnResaleState bybkCnResaleState) {
		getBybkCnResaleStates().add(bybkCnResaleState);
		bybkCnResaleState.setBuyback(this);

		return bybkCnResaleState;
	}

	public BybkCnResaleState removeBybkCnResaleState(BybkCnResaleState bybkCnResaleState) {
		getBybkCnResaleStates().remove(bybkCnResaleState);
		bybkCnResaleState.setBuyback(null);

		return bybkCnResaleState;
	}

	public Set<BybkPagApproval> getBybkPagApprovals() {
		return this.bybkPagApprovals;
	}

	public void setBybkPagApprovals(Set<BybkPagApproval> bybkPagApprovals) {
		this.bybkPagApprovals = bybkPagApprovals;
	}

	public BybkPagApproval addBybkPagApproval(BybkPagApproval bybkPagApproval) {
		getBybkPagApprovals().add(bybkPagApproval);
		bybkPagApproval.setBuyback(this);

		return bybkPagApproval;
	}

	public BybkPagApproval removeBybkPagApproval(BybkPagApproval bybkPagApproval) {
		getBybkPagApprovals().remove(bybkPagApproval);
		bybkPagApproval.setBuyback(null);

		return bybkPagApproval;
	}

	public Set<BybkReasProbMapg> getBybkReasProbMapgs() {
		return this.bybkReasProbMapgs;
	}

	public void setBybkReasProbMapgs(Set<BybkReasProbMapg> bybkReasProbMapgs) {
		this.bybkReasProbMapgs = bybkReasProbMapgs;
	}

	public BybkReasProbMapg addBybkReasProbMapg(BybkReasProbMapg bybkReasProbMapg) {
		getBybkReasProbMapgs().add(bybkReasProbMapg);
		bybkReasProbMapg.setBuyback(this);

		return bybkReasProbMapg;
	}

	public BybkReasProbMapg removeBybkReasProbMapg(BybkReasProbMapg bybkReasProbMapg) {
		getBybkReasProbMapgs().remove(bybkReasProbMapg);
		bybkReasProbMapg.setBuyback(null);

		return bybkReasProbMapg;
	}

	public CashAndKeep getCashAndKeep() {
		return this.cashAndKeep;
	}

	public void setCashAndKeep(CashAndKeep cashAndKeep) {
		this.cashAndKeep = cashAndKeep;
	}

	public CashAndKeepPackage getCashAndKeepPackage() {
		return cashAndKeepPackage;
	}

	public void setCashAndKeepPackage(CashAndKeepPackage cashAndKeepPackage) {
		this.cashAndKeepPackage = cashAndKeepPackage;
	}

	public Set<Check> getChecks() {
		return this.checks;
	}

	public void setChecks(Set<Check> checks) {
		this.checks = checks;
	}

	public Check addCheck(Check check) {
		getChecks().add(check);
		check.setBuyback(this);

		return check;
	}

	public Check removeCheck(Check check) {
		getChecks().remove(check);
		check.setBuyback(null);

		return check;
	}

	public CustomerDetail getCustomerDetail() {
		return this.customerDetail;
	}

	public void setCustomerDetail(CustomerDetail customerDetail) {
		this.customerDetail = customerDetail;
	}

	public Set<BuybackDealerDetail> getDealerDetails() {
		return this.dealerDetails;
	}

	public void setDealerDetails(Set<BuybackDealerDetail> dealerDetails) {
		this.dealerDetails = dealerDetails;
	}

	public BuybackDealerDetail addDealerDetail(BuybackDealerDetail dealerDetail) {
		getDealerDetails().add(dealerDetail);
		dealerDetail.setBuyback(this);

		return dealerDetail;
	}

	public BuybackDealerDetail removeDealerDetail(BuybackDealerDetail dealerDetail) {
		getDealerDetails().remove(dealerDetail);
		dealerDetail.setBuyback(null);

		return dealerDetail;
	}

	public GoodWillTrade getGoodWillTrade() {
		return this.goodWillTrade;
	}

	public void setGoodWillTrade(GoodWillTrade goodWillTrade) {
		this.goodWillTrade = goodWillTrade;
	}

	public LegalEntry getLegalEntry() {
		return this.legalEntry;
	}

	public void setLegalEntry(LegalEntry legalEntry) {
		this.legalEntry = legalEntry;
	}

	public Set<PackageDisposalDocu> getPackageDisposalDocus() {
		return this.packageDisposalDocus;
	}

	public void setPackageDisposalDocus(Set<PackageDisposalDocu> packageDisposalDocus) {
		this.packageDisposalDocus = packageDisposalDocus;
	}

	public PackageDisposalDocu addPackageDisposalDocus(PackageDisposalDocu packageDisposalDocus) {
		getPackageDisposalDocus().add(packageDisposalDocus);
		packageDisposalDocus.setBuyback(this);

		return packageDisposalDocus;
	}

	public PackageDisposalDocu removePackageDisposalDocus(PackageDisposalDocu packageDisposalDocus) {
		getPackageDisposalDocus().remove(packageDisposalDocus);
		packageDisposalDocus.setBuyback(null);

		return packageDisposalDocus;
	}

	public VehicleDetail getVehicleDetail() {
		return this.vehicleDetail;
	}

	public void setVehicleDetail(VehicleDetail vehicleDetail) {
		this.vehicleDetail = vehicleDetail;
	}

	public Warranty getWarranty() {
		return this.warranty;
	}

	public void setWarranty(Warranty warranty) {
		this.warranty = warranty;
	}

	public GoodWillPackage getGoodWillPackage() {
		return goodWillPackage;
	}

	public void setGoodWillPackage(GoodWillPackage goodWillPackage) {
		this.goodWillPackage = goodWillPackage;
	}

	public String getlReaqSys() {
		return lReaqSys;
	}

	public void setlReaqSys(String lReaqSys) {
		this.lReaqSys = lReaqSys;
	}

	public Timestamp getdPkgCreatd() {
		return dPkgCreatd;
	}

	public void setdPkgCreatd(Timestamp dPkgCreatd) {
		this.dPkgCreatd = dPkgCreatd;
	}

	public Timestamp getdPkgSubmtd() {
		return dPkgSubmtd;
	}

	public void setdPkgSubmtd(Timestamp dPkgSubmtd) {
		this.dPkgSubmtd = dPkgSubmtd;
	}

	public Timestamp getdPkgFinalAprvd() {
		return dPkgFinalAprvd;
	}

	public void setdPkgFinalAprvd(Timestamp dPkgFinalAprvd) {
		this.dPkgFinalAprvd = dPkgFinalAprvd;
	}

	public String getlCairCreateSys() {
		return lCairCreateSys;
	}

	public void setlCairCreateSys(String lCairCreateSys) {
		this.lCairCreateSys = lCairCreateSys;
	}

	public String getcSoldDlr() {
		return cSoldDlr;
	}

	public void setcSoldDlr(String cSoldDlr) {
		this.cSoldDlr = cSoldDlr;
	}

	public String getnSoldCust() {
		return nSoldCust;
	}

	public void setnSoldCust(String nSoldCust) {
		this.nSoldCust = nSoldCust;
	}

	public Integer getiDisclsrTyp() {
		return iDisclsrTyp;
	}

	public void setiDisclsrTyp(Integer iDisclsrTyp) {
		this.iDisclsrTyp = iDisclsrTyp;
	}

	public Timestamp getdSoldDlr() {
		return dSoldDlr;
	}

	public void setdSoldDlr(Timestamp dSoldDlr) {
		this.dSoldDlr = dSoldDlr;
	}

	public Timestamp getdSoldCust() {
		return dSoldCust;
	}

	public void setdSoldCust(Timestamp dSoldCust) {
		this.dSoldCust = dSoldCust;
	}

	public String getiRlatdCair() {
		return iRlatdCair;
	}

	public void setiRlatdCair(String iRlatdCair) {
		this.iRlatdCair = iRlatdCair;
	}

	public String getI_BODID() {
		return I_BODID;
	}

	public void setI_BODID(String i_BODID) {
		I_BODID = i_BODID;
	}

	public Timestamp getdDspslSubmtd() {
		return dDspslSubmtd;
	}

	public void setdDspslSubmtd(Timestamp dDspslSubmtd) {
		this.dDspslSubmtd = dDspslSubmtd;
	}

	public Timestamp getdRecal() {
		return dRecal;
	}

	public void setdRecal(Timestamp dRecal) {
		this.dRecal = dRecal;
	}

	public String getcRecalTyp() {
		return cRecalTyp;
	}

	public void setcRecalTyp(String cRecalTyp) {
		this.cRecalTyp = cRecalTyp;
	}

	public String getiRecalNmbr() {
		return iRecalNmbr;
	}

	public void setiRecalNmbr(String iRecalNmbr) {
		this.iRecalNmbr = iRecalNmbr;
	}

	public String getlRecal() {
		return lRecal;
	}

	public void setlRecal(String lRecal) {
		this.lRecal = lRecal;
	}

	public String getcRecalStat() {
		return cRecalStat;
	}

	public void setcRecalStat(String cRecalStat) {
		this.cRecalStat = cRecalStat;
	}

	public Timestamp getdDspslCreatd() {
		return dDspslCreatd;
	}

	public void setdDspslCreatd(Timestamp dDspslCreatd) {
		this.dDspslCreatd = dDspslCreatd;
	}

}