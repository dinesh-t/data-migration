package com.chrysler.migration.entity;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * The persistent class for the RPT_MSTR database table.
 * 
 */
@Entity
@Table(name = "RPT_MSTR")
@NamedQuery(name = "RptMstr.findAll", query = "SELECT r FROM RptMstr r")
public class RptMstr extends AuditColumns implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "I_RPT_SEQ")
	private int iRptSeq;

	@Column(name = "L_RPT_STAT")
	private String lRptStat;

	@Column(name = "N_RPT")
	private String nRpt;

	@Column(name = "X_QUERY")
	private String xQuery;

	@Column(name = "L_BYBK")
	private String lBuyback;

	// bi-directional many-to-one association to RptColmMstr
	@OneToMany(mappedBy = "rptMstr")
	private List<RptColmMstr> rptColmMstrs;

	// bi-directional many-to-one association to RptGrpByHaving
	@OneToMany(mappedBy = "rptMstr")
	private List<RptGrpByHaving> rptGrpByHavings;

	// bi-directional many-to-one association to RptOrdrBy
	@OneToMany(mappedBy = "rptMstr")
	private List<RptOrdrBy> rptOrdrBies;

	// bi-directional many-to-one association to RptWhereCond
	@OneToMany(mappedBy = "rptMstr")
	private List<RptWhereCond> rptWhereConds;

	public RptMstr() {
	}

	public int getIRptSeq() {
		return this.iRptSeq;
	}

	public void setIRptSeq(int iRptSeq) {
		this.iRptSeq = iRptSeq;
	}

	public String getLRptStat() {
		return this.lRptStat;
	}

	public void setLRptStat(String lRptStat) {
		this.lRptStat = lRptStat;
	}

	public String getNRpt() {
		return this.nRpt;
	}

	public void setNRpt(String nRpt) {
		this.nRpt = nRpt;
	}

	public String getlBuyback() {
		return lBuyback;
	}

	public void setlBuyback(String lBuyback) {
		this.lBuyback = lBuyback;
	}

	public String getXQuery() {
		return this.xQuery;
	}

	public void setXQuery(String xQuery) {
		this.xQuery = xQuery;
	}

	public List<RptColmMstr> getRptColmMstrs() {
		return this.rptColmMstrs;
	}

	public void setRptColmMstrs(List<RptColmMstr> rptColmMstrs) {
		this.rptColmMstrs = rptColmMstrs;
	}

	public RptColmMstr addRptColmMstr(RptColmMstr rptColmMstr) {
		getRptColmMstrs().add(rptColmMstr);
		rptColmMstr.setRptMstr(this);

		return rptColmMstr;
	}

	public RptColmMstr removeRptColmMstr(RptColmMstr rptColmMstr) {
		getRptColmMstrs().remove(rptColmMstr);
		rptColmMstr.setRptMstr(null);

		return rptColmMstr;
	}

	public List<RptGrpByHaving> getRptGrpByHavings() {
		return this.rptGrpByHavings;
	}

	public void setRptGrpByHavings(List<RptGrpByHaving> rptGrpByHavings) {
		this.rptGrpByHavings = rptGrpByHavings;
	}

	public RptGrpByHaving addRptGrpByHaving(RptGrpByHaving rptGrpByHaving) {
		getRptGrpByHavings().add(rptGrpByHaving);
		rptGrpByHaving.setRptMstr(this);

		return rptGrpByHaving;
	}

	public RptGrpByHaving removeRptGrpByHaving(RptGrpByHaving rptGrpByHaving) {
		getRptGrpByHavings().remove(rptGrpByHaving);
		rptGrpByHaving.setRptMstr(null);

		return rptGrpByHaving;
	}

	public List<RptOrdrBy> getRptOrdrBies() {
		return this.rptOrdrBies;
	}

	public void setRptOrdrBies(List<RptOrdrBy> rptOrdrBies) {
		this.rptOrdrBies = rptOrdrBies;
	}

	public RptOrdrBy addRptOrdrBy(RptOrdrBy rptOrdrBy) {
		getRptOrdrBies().add(rptOrdrBy);
		rptOrdrBy.setRptMstr(this);

		return rptOrdrBy;
	}

	public RptOrdrBy removeRptOrdrBy(RptOrdrBy rptOrdrBy) {
		getRptOrdrBies().remove(rptOrdrBy);
		rptOrdrBy.setRptMstr(null);

		return rptOrdrBy;
	}

	public List<RptWhereCond> getRptWhereConds() {
		return this.rptWhereConds;
	}

	public void setRptWhereConds(List<RptWhereCond> rptWhereConds) {
		this.rptWhereConds = rptWhereConds;
	}

	public RptWhereCond addRptWhereCond(RptWhereCond rptWhereCond) {
		getRptWhereConds().add(rptWhereCond);
		rptWhereCond.setRptMstr(this);

		return rptWhereCond;
	}

	public RptWhereCond removeRptWhereCond(RptWhereCond rptWhereCond) {
		getRptWhereConds().remove(rptWhereCond);
		rptWhereCond.setRptMstr(null);

		return rptWhereCond;
	}

}