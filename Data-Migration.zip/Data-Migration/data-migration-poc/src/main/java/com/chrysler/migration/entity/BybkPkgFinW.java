package com.chrysler.migration.entity;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;

/**
 * The persistent class for the BYBK_PKG_FIN_WS database table.
 * 
 */
@Entity
@Table(name = "BYBK_PKG_FIN_WS")
@NamedQuery(name = "BybkPkgFinW.findAll", query = "SELECT b FROM BybkPkgFinW b")
public class BybkPkgFinW extends AuditColumns implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "I_FIN_WS_SEQ")
	private Integer iFinWsSeq;

	@Column(name = "A_OWNR_VAL")
	private BigDecimal aOwnrVal;

	@Column(name = "A_PRMRY_OTHR_VAL")
	private BigDecimal aPrmryOthrVal;

	@Column(name = "I_ORDR_NMBR")
	private Integer iOrdrNmbr;

	@Column(name = "L_OTHR_TYP")
	private String lOthrTyp;

	@Column(name = "X_OTHR_TEXT")
	private String xOthrText;

	@Column(name = "X_PRMRY_TEXT")
	private String xPrmryText;

	// bi-directional many-to-one association to Bybk
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_BYBK")
	private Buyback bybk;

	public BybkPkgFinW() {
		//
	}

	public int getIFinWsSeq() {
		return this.iFinWsSeq;
	}

	public void setIFinWsSeq(int iFinWsSeq) {
		this.iFinWsSeq = iFinWsSeq;
	}

	public BigDecimal getAOwnrVal() {
		return this.aOwnrVal;
	}

	public void setAOwnrVal(BigDecimal aOwnrVal) {
		this.aOwnrVal = aOwnrVal;
	}

	public BigDecimal getAPrmryOthrVal() {
		return this.aPrmryOthrVal;
	}

	public void setAPrmryOthrVal(BigDecimal aPrmryOthrVal) {
		this.aPrmryOthrVal = aPrmryOthrVal;
	}

	public Integer getIOrdrNmbr() {
		return this.iOrdrNmbr;
	}

	public void setIOrdrNmbr(Integer iOrdrNmbr) {
		this.iOrdrNmbr = iOrdrNmbr;
	}

	public String getLOthrTyp() {
		return this.lOthrTyp;
	}

	public void setLOthrTyp(String lOthrTyp) {
		this.lOthrTyp = lOthrTyp;
	}

	public String getXOthrText() {
		return this.xOthrText;
	}

	public void setXOthrText(String xOthrText) {
		this.xOthrText = xOthrText;
	}

	public String getXPrmryText() {
		return this.xPrmryText;
	}

	public void setXPrmryText(String xPrmryText) {
		this.xPrmryText = xPrmryText;
	}

	public Buyback getBybk() {
		return this.bybk;
	}

	public void setBybk(Buyback bybk) {
		this.bybk = bybk;
	}

}