package com.chrysler.migration.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * The persistent class for the GOOD_WILL_PACKAGE database table.
 * 
 */
@Entity
@Table(name = "GOOD_WILL_PKG")
@NamedQuery(name = "GoodWillPackage.findAll", query = "SELECT g FROM GoodWillPackage g")
public class GoodWillPackage extends AuditColumns implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "I_PKG_GOOD_SEQ")
	private Integer iPagGoodSeq;

	@Column(name = "A_CERTIF")
	private BigDecimal aCertif;

	@Column(name = "D_REP")
	private Timestamp dRep;

	@Column(name = "I_REP_ORDR")
	private String iRepOrdr;

	@Column(name = "L_GOOD_STAT")
	private String lGoodStat;

	@Column(name = "L_LEMON_LAW")
	private String lLemonLaw;

	@Column(name = "L_SIGN_CERTIF")
	private String lSignCertif;

	@Column(name = "L_SIGN_DISCLSR")
	private String lSignDisclsr;

	@Column(name = "L_VHCL_REP")
	private String lVhclRep;

	@Column(name = "Q_DAYS_DOWN")
	private Integer qDaysDown;

	@Column(name = "Q_PKG_GOOD_REP")
	private Integer qPagGoodRep;

	@Column(name = "X_AREA_REP")
	private String xAreaRep;

	@Column(name = "X_DESC_PROB")
	private String xDescProb;

	// bi-directional many-to-one association to Buyback
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_BYBK")
	private Buyback buyback;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_TI_STATE")
	private CodeMaster titleStateCode;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_PKG_GOOD_REAS")
	private CodeMaster packageReasonCode;

	public GoodWillPackage() {
	}

	public Integer getIPagGoodSeq() {
		return this.iPagGoodSeq;
	}

	public void setIPagGoodSeq(Integer iPagGoodSeq) {
		this.iPagGoodSeq = iPagGoodSeq;
	}

	public BigDecimal getACertif() {
		return this.aCertif;
	}

	public void setACertif(BigDecimal aCertif) {
		this.aCertif = aCertif;
	}

	public Timestamp getDRep() {
		return this.dRep;
	}

	public void setDRep(Timestamp dRep) {
		this.dRep = dRep;
	}

	public String getIRepOrdr() {
		return this.iRepOrdr;
	}

	public void setIRepOrdr(String iRepOrdr) {
		this.iRepOrdr = iRepOrdr;
	}

	public String getLGoodStat() {
		return this.lGoodStat;
	}

	public void setLGoodStat(String lGoodStat) {
		this.lGoodStat = lGoodStat;
	}

	public String getLLemonLaw() {
		return this.lLemonLaw;
	}

	public void setLLemonLaw(String lLemonLaw) {
		this.lLemonLaw = lLemonLaw;
	}

	public String getLSignCertif() {
		return this.lSignCertif;
	}

	public void setLSignCertif(String lSignCertif) {
		this.lSignCertif = lSignCertif;
	}

	public String getLSignDisclsr() {
		return this.lSignDisclsr;
	}

	public void setLSignDisclsr(String lSignDisclsr) {
		this.lSignDisclsr = lSignDisclsr;
	}

	public String getLVhclRep() {
		return this.lVhclRep;
	}

	public void setLVhclRep(String lVhclRep) {
		this.lVhclRep = lVhclRep;
	}

	public Integer getQDaysDown() {
		return this.qDaysDown;
	}

	public void setQDaysDown(Integer qDaysDown) {
		this.qDaysDown = qDaysDown;
	}

	public Integer getQPagGoodRep() {
		return this.qPagGoodRep;
	}

	public void setQPagGoodRep(Integer qPagGoodRep) {
		this.qPagGoodRep = qPagGoodRep;
	}

	public String getXAreaRep() {
		return this.xAreaRep;
	}

	public void setXAreaRep(String xAreaRep) {
		this.xAreaRep = xAreaRep;
	}

	public String getXDescProb() {
		return this.xDescProb;
	}

	public void setXDescProb(String xDescProb) {
		this.xDescProb = xDescProb;
	}

	public Buyback getBuyback() {
		return this.buyback;
	}

	public void setBuyback(Buyback buyback) {
		this.buyback = buyback;
	}

	public CodeMaster getTitleStateCode() {
		return titleStateCode;
	}

	public void setTitleStateCode(CodeMaster titleStateCode) {
		this.titleStateCode = titleStateCode;
	}

	public CodeMaster getPackageReasonCode() {
		return packageReasonCode;
	}

	public void setPackageReasonCode(CodeMaster packageReasonCode) {
		this.packageReasonCode = packageReasonCode;
	}

}
