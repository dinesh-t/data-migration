package com.chrysler.migration.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MapsId;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.LazyToOne;
import org.hibernate.annotations.LazyToOneOption;

/**
 * The persistent class for the BUYBACK_DISPOSAL_RECOVERY database table.
 * 
 */
@Entity
@Table(name = "BYBK_DSPSL_RCVY")
@NamedQuery(name = "BuybackDisposalRecovery.findAll", query = "SELECT b FROM BuybackDisposalRecovery b")
public class BuybackDisposalRecovery extends AuditColumns implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@Id
	private Integer iBybk;

	@Column(name = "A_RCVY")
	private BigDecimal aRcvy;

	@Column(name = "A_TOT_RCVY")
	private BigDecimal aTotRcvy;

	@Column(name = "C_AUCTN")
	private String cAuctn;

	@Column(name = "C_AUCTN_RECVD")
	private String cAuctnRecvd;

	@Temporal(TemporalType.DATE)
	@Column(name = "D_AUCTN_RECVD")
	private Date dAuctnRecvd;

	@Temporal(TemporalType.DATE)
	@Column(name = "D_RCVY")
	private Date dRcvy;

	@Temporal(TemporalType.DATE)
	@Column(name = "D_SERV")
	private Date dServ;

	@Column(name = "I_GRA")
	private String iGra;

	@Column(name = "I_RCVY_TYP")
	private String iRcvyTyp;

	@Column(name = "I_TAX_RFND")
	private int iTaxRfnd;

	@Column(name = "X_COMNT")
	private String xComnt;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "C_DLR")
	private DealerDetail dealer;

	// bi-directional one-to-one association to Buyback
	@OneToOne(fetch = FetchType.LAZY)
	@MapsId
	@LazyToOne(LazyToOneOption.NO_PROXY)
	@JoinColumn(name = "I_BYBK")
	private Buyback buyback;
	
	public Buyback getBuyback() {
		return this.buyback;
	}

	public void setBuyback(Buyback buyback) {
		this.buyback = buyback;
	}

	public BuybackDisposalRecovery() {
	}

	public int getIBybk() {
		return this.iBybk;
	}

	public void setIBybk(int iBybk) {
		this.iBybk = iBybk;
	}

	public BigDecimal getARcvy() {
		return this.aRcvy;
	}

	public void setARcvy(BigDecimal aRcvy) {
		this.aRcvy = aRcvy;
	}

	public BigDecimal getATotRcvy() {
		return this.aTotRcvy;
	}

	public void setATotRcvy(BigDecimal aTotRcvy) {
		this.aTotRcvy = aTotRcvy;
	}

	public String getCAuctn() {
		return this.cAuctn;
	}

	public void setCAuctn(String cAuctn) {
		this.cAuctn = cAuctn;
	}

	public String getCAuctnRecvd() {
		return this.cAuctnRecvd;
	}

	public void setCAuctnRecvd(String cAuctnRecvd) {
		this.cAuctnRecvd = cAuctnRecvd;
	}

	public DealerDetail getDealer() {
		return dealer;
	}

	public void setDealer(DealerDetail dealer) {
		this.dealer = dealer;
	}

	public Date getDAuctnRecvd() {
		return this.dAuctnRecvd;
	}

	public void setDAuctnRecvd(Date dAuctnRecvd) {
		this.dAuctnRecvd = dAuctnRecvd;
	}

	public Date getDRcvy() {
		return this.dRcvy;
	}

	public void setDRcvy(Date dRcvy) {
		this.dRcvy = dRcvy;
	}

	public Date getDServ() {
		return this.dServ;
	}

	public void setDServ(Date dServ) {
		this.dServ = dServ;
	}

	public String getIGra() {
		return this.iGra;
	}

	public void setIGra(String iGra) {
		this.iGra = iGra;
	}

	public String getIRcvyTyp() {
		return this.iRcvyTyp;
	}

	public void setIRcvyTyp(String iRcvyTyp) {
		this.iRcvyTyp = iRcvyTyp;
	}

	public int getITaxRfnd() {
		return this.iTaxRfnd;
	}

	public void setITaxRfnd(int iTaxRfnd) {
		this.iTaxRfnd = iTaxRfnd;
	}

	public String getXComnt() {
		return this.xComnt;
	}

	public void setXComnt(String xComnt) {
		this.xComnt = xComnt;
	}

}