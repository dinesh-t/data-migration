package com.chrysler.migration.entity;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MapsId;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;

/**
 * The persistent class for the BUYBACK_REASON database table.
 * 
 */
@Entity
@Table(name = "BYBK_REAS")
@NamedQuery(name = "BuybackReason.findAll", query = "SELECT b FROM BuybackReason b")
public class BuybackReason extends AuditColumns implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private Integer iBybk;

	@Column(name = "C_BYBK_REAS_DLR")
	private Integer cBybkReasDlr;

	@Column(name = "I_BYBK_REAS_DLR_PH")
	private String iBybkReasDlrPh;

	@Column(name = "L_BEEN_REPAIRED")
	private String lBeenRepaired;

	@Column(name = "Q_BYBK_REAS_REP")
	private Integer qBybkReasRep;

	@Column(name = "I_REP_ORDR")
	private Integer iRepOrdr;

	@Column(name = "X_DAMAGE_DESC ")
	private String xDamageDesc;

	@Column(name = "L_CUST_RESP_REP")
	private String lCustRespRep;

	@Column(name = "L_PHYS_DAMAGE")
	private String lPhysDamage;

	@Column(name = "L_VHCL_CURR_DLR")
	private String lVhclCurrDlr;

	@Column(name = "X_DLR_CNTCT")
	private String xDlrCntct;

	@Column(name = "N_BYBK_REAS_DLR")
	private String nBybkReasDlr;

	@Column(name = "X_ADDL_INFO_REAS")
	private String xAddlInfoReas;

	@Column(name = "X_REP_DESC")
	private String xRepDesc;

	@Column(name = "A_ESTD_DAMGD")
	private BigDecimal aEstdDamgd;

	@Column(name = "X_JUST_BYBK")
	private String xJustBybk;

	@Column(name = "X_NON_CONFMN")
	private String xNonConfmn;

	// bi-directional one-to-one association to Buyback
	@OneToOne(fetch = FetchType.LAZY)
	@MapsId
	@JoinColumn(name = "I_BYBK")
	private Buyback buyback;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_REAS_CATGY")
	private CodeMaster iReasCatgy;

	@Column(name = "L_DLR_CAUS_BYBK")
	private String lDlrCausByBk;

	public BuybackReason() {
		//
	}

	public String getxDlrCntct() {
		return xDlrCntct;
	}

	public void setxDlrCntct(String xDlrCntct) {
		this.xDlrCntct = xDlrCntct;
	}

	public Integer getIBybk() {
		return this.iBybk;
	}

	public void setIBybk(Integer iBybk) {
		this.iBybk = iBybk;
	}

	public Integer getCBybkReasDlr() {
		return this.cBybkReasDlr;
	}

	public void setCBybkReasDlr(Integer cBybkReasDlr) {
		this.cBybkReasDlr = cBybkReasDlr;
	}

	public String getIBybkReasDlrPh() {
		return this.iBybkReasDlrPh;
	}

	public void setIBybkReasDlrPh(String iBybkReasDlrPh) {
		this.iBybkReasDlrPh = iBybkReasDlrPh;
	}

	public String getLBeenRepaired() {
		return this.lBeenRepaired;
	}

	public void setLBeenRepaired(String lBeenRepaired) {
		this.lBeenRepaired = lBeenRepaired;
	}

	public String getLCustRespRep() {
		return this.lCustRespRep;
	}

	public void setLCustRespRep(String lCustRespRep) {
		this.lCustRespRep = lCustRespRep;
	}

	public String getLPhysDamage() {
		return this.lPhysDamage;
	}

	public void setLPhysDamage(String lPhysDamage) {
		this.lPhysDamage = lPhysDamage;
	}

	public String getLVhclCurrDlr() {
		return this.lVhclCurrDlr;
	}

	public void setLVhclCurrDlr(String lVhclCurrDlr) {
		this.lVhclCurrDlr = lVhclCurrDlr;
	}

	public String getNBybkReasDlr() {
		return this.nBybkReasDlr;
	}

	public void setNBybkReasDlr(String nBybkReasDlr) {
		this.nBybkReasDlr = nBybkReasDlr;
	}

	public Integer getQBybkReasRep() {
		return this.qBybkReasRep;
	}

	public void setQBybkReasRep(Integer qBybkReasRep) {
		this.qBybkReasRep = qBybkReasRep;
	}

	public String getXAddlInfoReas() {
		return this.xAddlInfoReas;
	}

	public void setXAddlInfoReas(String xAddlInfoReas) {
		this.xAddlInfoReas = xAddlInfoReas;
	}

	public String getxRepDesc() {
		return xRepDesc;
	}

	public void setxRepDesc(String xRepDesc) {
		this.xRepDesc = xRepDesc;
	}

	public String getXJustBybk() {
		return this.xJustBybk;
	}

	public void setXJustBybk(String xJustBybk) {
		this.xJustBybk = xJustBybk;
	}

	public String getXNonConfmn() {
		return this.xNonConfmn;
	}

	public void setXNonConfmn(String xNonConfmn) {
		this.xNonConfmn = xNonConfmn;
	}

	public Buyback getBuyback() {
		return this.buyback;
	}

	public void setBuyback(Buyback buyback) {
		this.buyback = buyback;
	}

	public Integer getiRepOrdr() {
		return iRepOrdr;
	}

	public void setiRepOrdr(Integer iRepOrdr) {
		this.iRepOrdr = iRepOrdr;
	}

	public String getxDamageDesc() {
		return xDamageDesc;
	}

	public void setxDamageDesc(String xDamageDesc) {
		this.xDamageDesc = xDamageDesc;
	}

	public String getlDlrCausByBk() {
		return lDlrCausByBk;
	}

	public void setlDlrCausByBk(String lDlrCausByBk) {
		this.lDlrCausByBk = lDlrCausByBk;
	}

	public BigDecimal getaEstdDamgd() {
		return aEstdDamgd;
	}

	public void setaEstdDamgd(BigDecimal aEstdDamgd) {
		this.aEstdDamgd = aEstdDamgd;
	}

	public CodeMaster getiReasCatgy() {
		return iReasCatgy;
	}

	public void setiReasCatgy(CodeMaster iReasCatgy) {
		this.iReasCatgy = iReasCatgy;
	}

}