package com.chrysler.migration.entity;

import java.io.Serializable;
import javax.persistence.*;

import org.hibernate.annotations.LazyToOne;
import org.hibernate.annotations.LazyToOneOption;

import java.sql.Timestamp;

/**
 * The persistent class for the DISCLOSURE_TEMPLATE database table.
 * 
 */
@Entity
@Table(name = "DISCLOSURE_TEMPLATE")
@NamedQuery(name = "DisclosureTemplate.findAll", query = "SELECT d FROM DisclosureTemplate d")
public class DisclosureTemplate extends AuditColumns implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "I_TMPLT_SEQ")
	private int iTmpltSeq;

	@Lob
	@Column(name = "X_TMPLT")
	private String xTmplt;

	@Column(name = "X_TMPLT_DESC")
	private String xTmpltDesc;

	@Column(name = "X_TMPLT_TI")
	private String xTmpltTi;

	@OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@LazyToOne(LazyToOneOption.NO_PROXY)
	@JoinColumn(name = "I_TMPLT_STATE")
	private CodeMaster stateInformation;

	@OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@LazyToOne(LazyToOneOption.NO_PROXY)
	@JoinColumn(name = "I_TMPLT_TYP")
	private CodeMaster templateType;

	public DisclosureTemplate() {
		//
	}

	public int getITmpltSeq() {
		return this.iTmpltSeq;
	}

	public void setITmpltSeq(int iTmpltSeq) {
		this.iTmpltSeq = iTmpltSeq;
	}

	public String getXTmplt() {
		return this.xTmplt;
	}

	public void setXTmplt(String xTmplt) {
		this.xTmplt = xTmplt;
	}

	public String getXTmpltDesc() {
		return this.xTmpltDesc;
	}

	public void setXTmpltDesc(String xTmpltDesc) {
		this.xTmpltDesc = xTmpltDesc;
	}

	public String getXTmpltTi() {
		return this.xTmpltTi;
	}

	public void setXTmpltTi(String xTmpltTi) {
		this.xTmpltTi = xTmpltTi;
	}

	public CodeMaster getStateInformation() {
		return stateInformation;
	}

	public void setStateInformation(CodeMaster stateInformation) {
		this.stateInformation = stateInformation;
	}

	public CodeMaster getTemplateType() {
		return templateType;
	}

	public void setTemplateType(CodeMaster templateType) {
		this.templateType = templateType;
	}

}