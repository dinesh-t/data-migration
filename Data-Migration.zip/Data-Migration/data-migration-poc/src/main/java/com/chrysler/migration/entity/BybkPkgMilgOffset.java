package com.chrysler.migration.entity;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MapsId;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.LazyToOne;
import org.hibernate.annotations.LazyToOneOption;

/**
 * The persistent class for the BYBK_PKG_MILG_OFFSET database table.
 * 
 */
@Entity
@Table(name = "BYBK_PKG_MILG_OFFSET")
@NamedQuery(name = "BybkPkgMilgOffset.findAll", query = "SELECT b FROM BybkPkgMilgOffset b")
public class BybkPkgMilgOffset extends AuditColumns implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private Integer iBybk;

	@Column(name = "A_FLAT_USAGE_FEE")
	private BigDecimal aFlatUsageFee;

	@Column(name = "A_IMPARD_PRC")
	private BigDecimal aImpardPrc;

	@Column(name = "A_PUR_PRC")
	private BigDecimal aPurPrc;

	@Column(name = "A_STRGHT_COST")
	private BigDecimal aStrghtCost;

	@Column(name = "I_IMPARD_MILES")
	private Integer iImpardMiles;

	@Column(name = "I_PUR_MILES")
	private Integer iPurMiles;

	@Column(name = "I_STRGHT_MILES")
	private Integer iStrghtMiles;

	// bi-directional one-to-one association to Bybk
	@OneToOne(fetch = FetchType.LAZY)
	@MapsId
	@LazyToOne(LazyToOneOption.NO_PROXY)
	@JoinColumn(name = "I_BYBK")
	private Buyback bybk;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_PUR_DVDND")
	private CodeMaster purchagePriceDividendCode;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_IMPARD_DVDND")
	private CodeMaster impairedMileageDividendCode;

	public BybkPkgMilgOffset() {
		//
	}

	public Integer getIBybk() {
		return this.iBybk;
	}

	public void setIBybk(Integer iBybk) {
		this.iBybk = iBybk;
	}

	public BigDecimal getAFlatUsageFee() {
		return this.aFlatUsageFee;
	}

	public void setAFlatUsageFee(BigDecimal aFlatUsageFee) {
		this.aFlatUsageFee = aFlatUsageFee;
	}

	public BigDecimal getAImpardPrc() {
		return this.aImpardPrc;
	}

	public void setAImpardPrc(BigDecimal aImpardPrc) {
		this.aImpardPrc = aImpardPrc;
	}

	public BigDecimal getAPurPrc() {
		return this.aPurPrc;
	}

	public void setAPurPrc(BigDecimal aPurPrc) {
		this.aPurPrc = aPurPrc;
	}

	public BigDecimal getAStrghtCost() {
		return this.aStrghtCost;
	}

	public void setAStrghtCost(BigDecimal aStrghtCost) {
		this.aStrghtCost = aStrghtCost;
	}

	public Integer getIImpardMiles() {
		return this.iImpardMiles;
	}

	public void setIImpardMiles(Integer iImpardMiles) {
		this.iImpardMiles = iImpardMiles;
	}

	public Integer getIPurMiles() {
		return this.iPurMiles;
	}

	public void setIPurMiles(Integer iPurMiles) {
		this.iPurMiles = iPurMiles;
	}

	public Integer getIStrghtMiles() {
		return this.iStrghtMiles;
	}

	public void setIStrghtMiles(Integer iStrghtMiles) {
		this.iStrghtMiles = iStrghtMiles;
	}

	public Buyback getBybk() {
		return this.bybk;
	}

	public void setBybk(Buyback bybk) {
		this.bybk = bybk;
	}

	public CodeMaster getPurchagePriceDividendCode() {
		return purchagePriceDividendCode;
	}

	public void setPurchagePriceDividendCode(CodeMaster purchagePriceDividendCode) {
		this.purchagePriceDividendCode = purchagePriceDividendCode;
	}

	public CodeMaster getImpairedMileageDividendCode() {
		return impairedMileageDividendCode;
	}

	public void setImpairedMileageDividendCode(CodeMaster impairedMileageDividendCode) {
		this.impairedMileageDividendCode = impairedMileageDividendCode;
	}

}