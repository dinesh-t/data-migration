package com.chrysler.migration.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * The persistent class for the DISCLSR_VEHICLE_OWNER database table.
 * 
 */
@Entity
@Table(name = "DISCLSR_VEHICLE_OWNER")
@NamedQuery(name = "DisclsrVehicleOwner.findAll", query = "SELECT d FROM DisclsrVehicleOwner d")
public class DisclsrVehicleOwner extends AuditColumns implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "I_DISCLSR_VIN")
	private String iDisclsrVin;

	@Column(name = "A_WHSL_PRC")
	private BigDecimal aWhslPrc;

	@Column(name = "C_CSGND_ZIP")
	private String cCsgndZip;

	@Column(name = "C_DEPT")
	private Integer cDept;

	@Column(name = "C_DISCLSR_ZIP")
	private String cDisclsrZip;

	@Column(name = "C_EMISS")
	private String cEmiss;

	@Column(name = "C_INV_ZIP")
	private String cInvZip;

	@Column(name = "C_LOC")
	private Integer cLoc;

	@Column(name = "C_PRNT_DLR")
	private Integer cPrntDlr;

	@Column(name = "C_RE_MKTG_OUTPUT")
	private String cReMktgOutput;

	@Column(name = "C_SEDTRAN_RET")
	private String cSedtranRet;

	@Column(name = "C_VHCL_MOD")
	private String cVhclMod;

	@Column(name = "D_AUCTN_PUR")
	private Timestamp dAuctnPur;

	@Column(name = "D_CSGND")
	private Timestamp dCsgnd;

	@Column(name = "D_CSGND_AUCTN")
	private Timestamp dCsgndAuctn;

	@Column(name = "D_INV_AUCTN")
	private Timestamp dInvAuctn;

	@Column(name = "D_REC_HIST")
	private Timestamp dRecHist;

	@Column(name = "D_REQSTD_AUCTN")
	private Timestamp dReqstdAuctn;

	@Column(name = "D_SOLD")
	private Timestamp dSold;

	@Column(name = "D_SOLD_DLR")
	private Timestamp dSoldDlr;

	@Column(name = "D_VR_PUR")
	private Timestamp dVrPur;

	@Column(name = "I_DISCLSR_CAIR")
	private String iDisclsrCair;

	@Column(name = "I_PRTITN")
	private Integer iPrtitn;

	@Column(name = "I_VHCL_MY")
	private Integer iVhclMy;

	@Column(name = "N_CSGND_AUCTN")
	private String nCsgndAuctn;

	@Column(name = "N_CSGND_CITY")
	private String nCsgndCity;

	@Column(name = "N_DISCLSR_CITY")
	private String nDisclsrCity;

	@Column(name = "N_INV_AUCTN")
	private String nInvAuctn;

	@Column(name = "N_INV_CITY")
	private String nInvCity;

	@Column(name = "N_VHCL_MAKE")
	private String nVhclMake;

	@Column(name = "N_VHCL_MOD")
	private String nVhclMod;

	@Column(name = "Q_CURR_MILG")
	private Integer qCurrMilg;

	@Column(name = "T_SEDTRAN_SEND")
	private Timestamp tSedtranSend;

	@Column(name = "X_CSGND_LINE_1")
	private String xCsgndLine1;

	@Column(name = "X_CSGND_LINE_2")
	private String xCsgndLine2;

	@Column(name = "X_DOCU_READER")
	private String xDocuReader;

	@Column(name = "X_DOCUAUT")
	private String xDocuaut;

	@Column(name = "X_INV_LINE_1")
	private String xInvLine1;

	@Column(name = "X_INV_LINE_2")
	private String xInvLine2;

	@Temporal(TemporalType.DATE)
	@Column(name = "D_PRNT_DLR")
	private Date dPrntDlr;

	@Temporal(TemporalType.DATE)
	@Column(name = "D_PRNT_WSHLD")
	private Date dPrntWshld;

	@Column(name = "C_PRNT_DLR_ZIP")
	private String cPrntDlrZip;

	@Column(name = "N_PRNT_DLR_CITY")
	private String nPrntDlrCity;

	@Column(name = "X_PRNT_DLR_ADDR")
	private String xPrntDlrAddr;

	@Column(name = "N_PRNT_DLR")
	private String nPrntDlr;

	@Column(name = "I_CURR")
	private Integer iCurr;

	@Column(name = "L_VHCL_MSO")
	private String lVhclMso;

	@Column(name = "L_VHCL_TI")
	private String lVhclTi;

	@Column(name = "N_LOC")
	private String nLoc;

	@Column(name = "X_LINE_1")
	private String xLine1;

	@Column(name = "N_CITY")
	private String nCity;

	@Column(name = "C_STATE")
	private String cState;

	@Column(name = "I_ZIP")
	private Integer iZip;

	@Column(name = "N_CNTRY_ABRV")
	private String nCntryAbrv;

	@Column(name = "I_MOD_YR")
	private Integer iModYr;

	@Column(name = "G_MOD_BDY")
	private String gModBdy;

	@Column(name = "N_MOD")
	private String nMod;

	@Column(name = "D_VHCL_STAT")
	private Timestamp dVhclStat;

	@Column(name = "C_VHCL")
	private String cVhcl;

	@Column(name = "N_PERSN_CNTCT")
	private String nPersnCntct;

	@Column(name = "X_COMNT_1")
	private String xComnt1;

	@Column(name = "X_COMNT_2")
	private String xComnt2;

	@Column(name = "X_COMNT_3")
	private String xComnt3;

	@Column(name = "I_CORPLOC")
	private Integer iCorploc;

	@Column(name = "I_INV_PRMRY_PH")
	private String iInvPrmryPh;

	// bi-directional many-to-one association to DisclsrCnResaleState
	@OneToMany(mappedBy = "disclsrVehicleOwner")
	private Set<DisclsrCnResaleState> disclsrCnResaleStates;

	// bi-directional many-to-one association to AuctionDetail
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "C_INV_AUCTN", referencedColumnName = "C_AUCTN_CENTR")
	private AuctionDetail cInvAuction;

	// bi-directional many-to-one association to AuctionDetail
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "C_REQSTD_AUCTN", referencedColumnName = "C_AUCTN_CENTR")
	private AuctionDetail cRequestedAuction;

	// bi-directional many-to-one association to AuctionDetail
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "C_CSGND_AUCTN", referencedColumnName = "C_AUCTN_CENTR")
	private AuctionDetail cCsndAuction;

	// bi-directional many-to-one association to Bybk
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_BYBK")
	private Buyback iBybk;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_CSGNMT_STAT")
	private CodeMaster iCsgmtStatus;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_SEDTRAN_STAT")
	private CodeMaster iSedtranStatus;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_DISCLSR_STATE")
	private CodeMaster iDisclsrState;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_DISCLSR_TYP")
	private CodeMaster iDisclsrType;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_CNTL_FLAG")
	private CodeMaster iCntlFlag;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_TI_STATE")
	private CodeMaster iTitleState;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_VR_DLR_STATE")
	private CodeMaster iVrDlrState;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_AUCTN_DLR_STATE")
	private CodeMaster iAuctionDlrState;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_BYBK_CATGY")
	private CodeMaster iBybkCatgy;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_CSGND_STATE")
	private CodeMaster iCsgndState;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_INV_STATE")
	private CodeMaster iInvState;

	// bi-directional many-to-one association to DealerDetail
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_BUS_DLR_FRNCHZ", referencedColumnName = "C_DLR")
	private DealerDetail iBusDlrFrnchz;

	// bi-directional many-to-one association to DisclsrNonBybk
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_NON_BYBK")
	private DisclsrNonBybk disclsrNonBybk;

	// bi-directional many-to-one association to DealerDetail
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "C_INV_DLR", referencedColumnName = "C_DLR")
	private DealerDetail cInvDlr;

	@Column(name = "N_INV_DLR")
	private String nInvDlr;

	@Column(name = "X_INV_DLR_LINE_1")
	private String xInvDlrLine1;

	@Column(name = "X_INV_DLR_LINE_2")
	private String xInvDlrLine2;

	@Column(name = "X_INV_DLR_CITY")
	private String xInvDlrCity;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_INV_DLR_STATE")
	private CodeMaster iInvDlrState;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_PRNT_DLR_STATE")
	private CodeMaster iPrntDlrState;

	@Column(name = "N_INV_DLR_CNTRY")
	private String nInvDlrCntry;

	@Column(name = "C_INV_DLR_ZIP")
	private String cInvDlrZip;

	// bi-directional many-to-one association to DealerDetail
	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.PERSIST)
	@JoinColumn(name = "C_CSGND_DLR", referencedColumnName = "C_DLR")
	private DealerDetail cCsgndDlr;

	@Column(name = "N_CSGND_DLR")
	private String nCsgndDlr;

	@Column(name = "X_CSGND_DLR_LINE_1")
	private String xCsgndDlrLine1;

	@Column(name = "X_CSGND_DLR_LINE_2")
	private String xCsgndDlrLine2;

	@Column(name = "X_CSGND_DLR_CITY")
	private String xCsgndDlrCity;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_CSGND_DLR_STATE")
	private CodeMaster iCsgndDlrState;

	@Column(name = "N_CSGND_DLR_CNTRY")
	private String nCsgndDlrCntry;

	@Column(name = "C_CSGND_DLR_ZIP")
	private String cCsgndDlrZip;

	@Column(name = "A_AUCTN_NET")
	private BigDecimal aAuctnNet;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_AUCTN_TYP")
	private CodeMaster iAuctnTpe;

	@Column(name = "D_AUCTN_RECV")
	private Timestamp dAuctnRecv;

	@Column(name = "A_AUCTN_GRS")
	private BigDecimal aAuctnGrs;

	public String getiInvPrmryPh() {
		return iInvPrmryPh;
	}

	public void setiInvPrmryPh(String iInvPrmryPh) {
		this.iInvPrmryPh = iInvPrmryPh;
	}

	public String getiDisclsrVin() {
		return iDisclsrVin;
	}

	public void setiDisclsrVin(String iDisclsrVin) {
		this.iDisclsrVin = iDisclsrVin;
	}

	public BigDecimal getaWhslPrc() {
		return aWhslPrc;
	}

	public void setaWhslPrc(BigDecimal aWhslPrc) {
		this.aWhslPrc = aWhslPrc;
	}

	public Integer getcDept() {
		return cDept;
	}

	public void setcDept(Integer cDept) {
		this.cDept = cDept;
	}

	public String getcDisclsrZip() {
		return cDisclsrZip;
	}

	public void setcDisclsrZip(String cDisclsrZip) {
		this.cDisclsrZip = cDisclsrZip;
	}

	public String getcEmiss() {
		return cEmiss;
	}

	public void setcEmiss(String cEmiss) {
		this.cEmiss = cEmiss;
	}

	public Integer getcLoc() {
		return cLoc;
	}

	public void setcLoc(Integer cLoc) {
		this.cLoc = cLoc;
	}

	public Integer getcPrntDlr() {
		return cPrntDlr;
	}

	public void setcPrntDlr(Integer cPrntDlr) {
		this.cPrntDlr = cPrntDlr;
	}

	public String getcVhclMod() {
		return cVhclMod;
	}

	public void setcVhclMod(String cVhclMod) {
		this.cVhclMod = cVhclMod;
	}

	public Timestamp getdAuctnPur() {
		return dAuctnPur;
	}

	public void setdAuctnPur(Timestamp dAuctnPur) {
		this.dAuctnPur = dAuctnPur;
	}

	public Timestamp getdCsgnd() {
		return dCsgnd;
	}

	public void setdCsgnd(Timestamp dCsgnd) {
		this.dCsgnd = dCsgnd;
	}

	public Timestamp getdCsgndAuctn() {
		return dCsgndAuctn;
	}

	public void setdCsgndAuctn(Timestamp dCsgndAuctn) {
		this.dCsgndAuctn = dCsgndAuctn;
	}

	public Timestamp getdSold() {
		return dSold;
	}

	public void setdSold(Timestamp dSold) {
		this.dSold = dSold;
	}

	public Timestamp getdSoldDlr() {
		return dSoldDlr;
	}

	public void setdSoldDlr(Timestamp dSoldDlr) {
		this.dSoldDlr = dSoldDlr;
	}

	public Timestamp getdVrPur() {
		return dVrPur;
	}

	public void setdVrPur(Timestamp dVrPur) {
		this.dVrPur = dVrPur;
	}

	public Buyback getiBybk() {
		return iBybk;
	}

	public void setiBybk(Buyback iBybk) {
		this.iBybk = iBybk;
	}

	public String getiDisclsrCair() {
		return iDisclsrCair;
	}

	public void setiDisclsrCair(String iDisclsrCair) {
		this.iDisclsrCair = iDisclsrCair;
	}

	public Integer getiVhclMy() {
		return iVhclMy;
	}

	public void setiVhclMy(Integer iVhclMy) {
		this.iVhclMy = iVhclMy;
	}

	public String getnDisclsrCity() {
		return nDisclsrCity;
	}

	public void setnDisclsrCity(String nDisclsrCity) {
		this.nDisclsrCity = nDisclsrCity;
	}

	public String getnVhclMake() {
		return nVhclMake;
	}

	public void setnVhclMake(String nVhclMake) {
		this.nVhclMake = nVhclMake;
	}

	public String getnVhclMod() {
		return nVhclMod;
	}

	public void setnVhclMod(String nVhclMod) {
		this.nVhclMod = nVhclMod;
	}

	public Integer getqCurrMilg() {
		return qCurrMilg;
	}

	public void setqCurrMilg(Integer qCurrMilg) {
		this.qCurrMilg = qCurrMilg;
	}

	public Timestamp gettSedtranSend() {
		return tSedtranSend;
	}

	public void settSedtranSend(Timestamp tSedtranSend) {
		this.tSedtranSend = tSedtranSend;
	}

	public String getxDocuReader() {
		return xDocuReader;
	}

	public void setxDocuReader(String xDocuReader) {
		this.xDocuReader = xDocuReader;
	}

	public String getxDocuaut() {
		return xDocuaut;
	}

	public void setxDocuaut(String xDocuaut) {
		this.xDocuaut = xDocuaut;
	}

	public Set<DisclsrCnResaleState> getDisclsrCnResaleStates() {
		return disclsrCnResaleStates;
	}

	public void setDisclsrCnResaleStates(Set<DisclsrCnResaleState> disclsrCnResaleStates) {
		this.disclsrCnResaleStates = disclsrCnResaleStates;
	}

	public AuctionDetail getcInvAuction() {
		return cInvAuction;
	}

	public void setcInvAuction(AuctionDetail cInvAuction) {
		this.cInvAuction = cInvAuction;
	}

	public AuctionDetail getcRequestedAuction() {
		return cRequestedAuction;
	}

	public void setcRequestedAuction(AuctionDetail cRequestedAuction) {
		this.cRequestedAuction = cRequestedAuction;
	}

	public AuctionDetail getcCsndAuction() {
		return cCsndAuction;
	}

	public void setcCsndAuction(AuctionDetail cCsndAuction) {
		this.cCsndAuction = cCsndAuction;
	}

	public CodeMaster getiCsgmtStatus() {
		return iCsgmtStatus;
	}

	public void setiCsgmtStatus(CodeMaster iCsgmtStatus) {
		this.iCsgmtStatus = iCsgmtStatus;
	}

	public CodeMaster getiSedtranStatus() {
		return iSedtranStatus;
	}

	public void setiSedtranStatus(CodeMaster iSedtranStatus) {
		this.iSedtranStatus = iSedtranStatus;
	}

	public CodeMaster getiDisclsrState() {
		return iDisclsrState;
	}

	public void setiDisclsrState(CodeMaster iDisclsrState) {
		this.iDisclsrState = iDisclsrState;
	}

	public CodeMaster getiDisclsrType() {
		return iDisclsrType;
	}

	public void setiDisclsrType(CodeMaster iDisclsrType) {
		this.iDisclsrType = iDisclsrType;
	}

	public CodeMaster getiCntlFlag() {
		return iCntlFlag;
	}

	public void setiCntlFlag(CodeMaster iCntlFlag) {
		this.iCntlFlag = iCntlFlag;
	}

	public CodeMaster getiTitleState() {
		return iTitleState;
	}

	public void setiTitleState(CodeMaster iTitleState) {
		this.iTitleState = iTitleState;
	}

	public CodeMaster getiVrDlrState() {
		return iVrDlrState;
	}

	public void setiVrDlrState(CodeMaster iVrDlrState) {
		this.iVrDlrState = iVrDlrState;
	}

	public CodeMaster getiAuctionDlrState() {
		return iAuctionDlrState;
	}

	public void setiAuctionDlrState(CodeMaster iAuctionDlrState) {
		this.iAuctionDlrState = iAuctionDlrState;
	}

	public CodeMaster getiBybkCatgy() {
		return iBybkCatgy;
	}

	public void setiBybkCatgy(CodeMaster iBybkCatgy) {
		this.iBybkCatgy = iBybkCatgy;
	}

	public DisclsrNonBybk getDisclsrNonBybk() {
		return disclsrNonBybk;
	}

	public void setDisclsrNonBybk(DisclsrNonBybk disclsrNonBybk) {
		this.disclsrNonBybk = disclsrNonBybk;
	}

	public String getcCsgndZip() {
		return cCsgndZip;
	}

	public void setcCsgndZip(String cCsgndZip) {
		this.cCsgndZip = cCsgndZip;
	}

	public String getcInvZip() {
		return cInvZip;
	}

	public void setcInvZip(String cInvZip) {
		this.cInvZip = cInvZip;
	}

	public String getcReMktgOutput() {
		return cReMktgOutput;
	}

	public void setcReMktgOutput(String cReMktgOutput) {
		this.cReMktgOutput = cReMktgOutput;
	}

	public String getcSedtranRet() {
		return cSedtranRet;
	}

	public void setcSedtranRet(String cSedtranRet) {
		this.cSedtranRet = cSedtranRet;
	}

	public Timestamp getdInvAuctn() {
		return dInvAuctn;
	}

	public void setdInvAuctn(Timestamp dInvAuctn) {
		this.dInvAuctn = dInvAuctn;
	}

	public Timestamp getdRecHist() {
		return dRecHist;
	}

	public void setdRecHist(Timestamp dRecHist) {
		this.dRecHist = dRecHist;
	}

	public Timestamp getdReqstdAuctn() {
		return dReqstdAuctn;
	}

	public void setdReqstdAuctn(Timestamp dReqstdAuctn) {
		this.dReqstdAuctn = dReqstdAuctn;
	}

	public Integer getiPrtitn() {
		return iPrtitn;
	}

	public void setiPrtitn(Integer iPrtitn) {
		this.iPrtitn = iPrtitn;
	}

	public String getnCsgndAuctn() {
		return nCsgndAuctn;
	}

	public void setnCsgndAuctn(String nCsgndAuctn) {
		this.nCsgndAuctn = nCsgndAuctn;
	}

	public String getnCsgndCity() {
		return nCsgndCity;
	}

	public void setnCsgndCity(String nCsgndCity) {
		this.nCsgndCity = nCsgndCity;
	}

	public String getnInvAuctn() {
		return nInvAuctn;
	}

	public void setnInvAuctn(String nInvAuctn) {
		this.nInvAuctn = nInvAuctn;
	}

	public String getnInvCity() {
		return nInvCity;
	}

	public void setnInvCity(String nInvCity) {
		this.nInvCity = nInvCity;
	}

	public String getxCsgndLine1() {
		return xCsgndLine1;
	}

	public void setxCsgndLine1(String xCsgndLine1) {
		this.xCsgndLine1 = xCsgndLine1;
	}

	public String getxCsgndLine2() {
		return xCsgndLine2;
	}

	public void setxCsgndLine2(String xCsgndLine2) {
		this.xCsgndLine2 = xCsgndLine2;
	}

	public String getxInvLine1() {
		return xInvLine1;
	}

	public void setxInvLine1(String xInvLine1) {
		this.xInvLine1 = xInvLine1;
	}

	public String getxInvLine2() {
		return xInvLine2;
	}

	public void setxInvLine2(String xInvLine2) {
		this.xInvLine2 = xInvLine2;
	}

	public CodeMaster getiCsgndState() {
		return iCsgndState;
	}

	public void setiCsgndState(CodeMaster iCsgndState) {
		this.iCsgndState = iCsgndState;
	}

	public CodeMaster getiInvState() {
		return iInvState;
	}

	public void setiInvState(CodeMaster iInvState) {
		this.iInvState = iInvState;
	}

	public DealerDetail getiBusDlrFrnchz() {
		return iBusDlrFrnchz;
	}

	public void setiBusDlrFrnchz(DealerDetail iBusDlrFrnchz) {
		this.iBusDlrFrnchz = iBusDlrFrnchz;
	}

	public Date getdPrntDlr() {
		return dPrntDlr;
	}

	public Date getdPrntWshld() {
		return dPrntWshld;
	}

	public String getcPrntDlrZip() {
		return cPrntDlrZip;
	}

	public String getnPrntDlrCity() {
		return nPrntDlrCity;
	}

	public String getxPrntDlrAddr() {
		return xPrntDlrAddr;
	}

	public String getnPrntDlr() {
		return nPrntDlr;
	}

	public void setdPrntDlr(Date dPrntDlr) {
		this.dPrntDlr = dPrntDlr;
	}

	public void setdPrntWshld(Date dPrntWshld) {
		this.dPrntWshld = dPrntWshld;
	}

	public void setcPrntDlrZip(String cPrntDlrZip) {
		this.cPrntDlrZip = cPrntDlrZip;
	}

	public void setnPrntDlrCity(String nPrntDlrCity) {
		this.nPrntDlrCity = nPrntDlrCity;
	}

	public void setxPrntDlrAddr(String xPrntDlrAddr) {
		this.xPrntDlrAddr = xPrntDlrAddr;
	}

	public void setnPrntDlr(String nPrntDlr) {
		this.nPrntDlr = nPrntDlr;
	}

	public Integer getiCurr() {
		return iCurr;
	}

	public void setiCurr(Integer iCurr) {
		this.iCurr = iCurr;
	}

	public String getlVhclMso() {
		return lVhclMso;
	}

	public void setlVhclMso(String lVhclMso) {
		this.lVhclMso = lVhclMso;
	}

	public String getlVhclTi() {
		return lVhclTi;
	}

	public void setlVhclTi(String lVhclTi) {
		this.lVhclTi = lVhclTi;
	}

	public String getnLoc() {
		return nLoc;
	}

	public void setnLoc(String nLoc) {
		this.nLoc = nLoc;
	}

	public String getxLine1() {
		return xLine1;
	}

	public void setxLine1(String xLine1) {
		this.xLine1 = xLine1;
	}

	public String getnCity() {
		return nCity;
	}

	public void setnCity(String nCity) {
		this.nCity = nCity;
	}

	public String getcState() {
		return cState;
	}

	public void setcState(String cState) {
		this.cState = cState;
	}

	public Integer getiZip() {
		return iZip;
	}

	public void setiZip(Integer iZip) {
		this.iZip = iZip;
	}

	public String getnCntryAbrv() {
		return nCntryAbrv;
	}

	public void setnCntryAbrv(String nCntryAbrv) {
		this.nCntryAbrv = nCntryAbrv;
	}

	public Integer getiModYr() {
		return iModYr;
	}

	public void setiModYr(Integer iModYr) {
		this.iModYr = iModYr;
	}

	public String getgModBdy() {
		return gModBdy;
	}

	public void setgModBdy(String gModBdy) {
		this.gModBdy = gModBdy;
	}

	public String getnMod() {
		return nMod;
	}

	public void setnMod(String nMod) {
		this.nMod = nMod;
	}

	public Timestamp getdVhclStat() {
		return dVhclStat;
	}

	public void setdVhclStat(Timestamp dVhclStat) {
		this.dVhclStat = dVhclStat;
	}

	public String getcVhcl() {
		return cVhcl;
	}

	public void setcVhcl(String cVhcl) {
		this.cVhcl = cVhcl;
	}

	public String getnPersnCntct() {
		return nPersnCntct;
	}

	public void setnPersnCntct(String nPersnCntct) {
		this.nPersnCntct = nPersnCntct;
	}

	public String getxComnt1() {
		return xComnt1;
	}

	public void setxComnt1(String xComnt1) {
		this.xComnt1 = xComnt1;
	}

	public String getxComnt2() {
		return xComnt2;
	}

	public void setxComnt2(String xComnt2) {
		this.xComnt2 = xComnt2;
	}

	public String getxComnt3() {
		return xComnt3;
	}

	public void setxComnt3(String xComnt3) {
		this.xComnt3 = xComnt3;
	}

	public Integer getiCorploc() {
		return iCorploc;
	}

	public void setiCorploc(Integer iCorploc) {
		this.iCorploc = iCorploc;
	}

	public DealerDetail getcInvDlr() {
		return cInvDlr;
	}

	public void setcInvDlr(DealerDetail cInvDlr) {
		this.cInvDlr = cInvDlr;
	}

	public String getnInvDlr() {
		return nInvDlr;
	}

	public void setnInvDlr(String nInvDlr) {
		this.nInvDlr = nInvDlr;
	}

	public String getxInvDlrLine1() {
		return xInvDlrLine1;
	}

	public void setxInvDlrLine1(String xInvDlrLine1) {
		this.xInvDlrLine1 = xInvDlrLine1;
	}

	public String getxInvDlrLine2() {
		return xInvDlrLine2;
	}

	public void setxInvDlrLine2(String xInvDlrLine2) {
		this.xInvDlrLine2 = xInvDlrLine2;
	}

	public String getxInvDlrCity() {
		return xInvDlrCity;
	}

	public void setxInvDlrCity(String xInvDlrCity) {
		this.xInvDlrCity = xInvDlrCity;
	}

	public CodeMaster getiInvDlrState() {
		return iInvDlrState;
	}

	public void setiInvDlrState(CodeMaster iInvDlrState) {
		this.iInvDlrState = iInvDlrState;
	}

	public String getnInvDlrCntry() {
		return nInvDlrCntry;
	}

	public void setnInvDlrCntry(String nInvDlrCntry) {
		this.nInvDlrCntry = nInvDlrCntry;
	}

	public String getcInvDlrZip() {
		return cInvDlrZip;
	}

	public void setcInvDlrZip(String cInvDlrZip) {
		this.cInvDlrZip = cInvDlrZip;
	}

	public DealerDetail getcCsgndDlr() {
		return cCsgndDlr;
	}

	public void setcCsgndDlr(DealerDetail cCsgndDlr) {
		this.cCsgndDlr = cCsgndDlr;
	}

	public String getnCsgndDlr() {
		return nCsgndDlr;
	}

	public void setnCsgndDlr(String nCsgndDlr) {
		this.nCsgndDlr = nCsgndDlr;
	}

	public String getxCsgndDlrLine1() {
		return xCsgndDlrLine1;
	}

	public void setxCsgndDlrLine1(String xCsgndDlrLine1) {
		this.xCsgndDlrLine1 = xCsgndDlrLine1;
	}

	public String getxCsgndDlrLine2() {
		return xCsgndDlrLine2;
	}

	public void setxCsgndDlrLine2(String xCsgndDlrLine2) {
		this.xCsgndDlrLine2 = xCsgndDlrLine2;
	}

	public String getxCsgndDlrCity() {
		return xCsgndDlrCity;
	}

	public void setxCsgndDlrCity(String xCsgndDlrCity) {
		this.xCsgndDlrCity = xCsgndDlrCity;
	}

	public CodeMaster getiCsgndDlrState() {
		return iCsgndDlrState;
	}

	public void setiCsgndDlrState(CodeMaster iCsgndDlrState) {
		this.iCsgndDlrState = iCsgndDlrState;
	}

	public String getnCsgndDlrCntry() {
		return nCsgndDlrCntry;
	}

	public void setnCsgndDlrCntry(String nCsgndDlrCntry) {
		this.nCsgndDlrCntry = nCsgndDlrCntry;
	}

	public String getcCsgndDlrZip() {
		return cCsgndDlrZip;
	}

	public void setcCsgndDlrZip(String cCsgndDlrZip) {
		this.cCsgndDlrZip = cCsgndDlrZip;
	}

	public BigDecimal getaAuctnNet() {
		return aAuctnNet;
	}

	public void setaAuctnNet(BigDecimal aAuctnNet) {
		this.aAuctnNet = aAuctnNet;
	}

	public CodeMaster getiAuctnTpe() {
		return iAuctnTpe;
	}

	public void setiAuctnTpe(CodeMaster iAuctnTpe) {
		this.iAuctnTpe = iAuctnTpe;
	}

	public Timestamp getdAuctnRecv() {
		return dAuctnRecv;
	}

	public void setdAuctnRecv(Timestamp dAuctnRecv) {
		this.dAuctnRecv = dAuctnRecv;
	}

	public BigDecimal getaAuctnGrs() {
		return aAuctnGrs;
	}

	public void setaAuctnGrs(BigDecimal aAuctnGrs) {
		this.aAuctnGrs = aAuctnGrs;
	}

	public CodeMaster getiPrntDlrState() {
		return iPrntDlrState;
	}

	public void setiPrntDlrState(CodeMaster iPrntDlrState) {
		this.iPrntDlrState = iPrntDlrState;
	}

}