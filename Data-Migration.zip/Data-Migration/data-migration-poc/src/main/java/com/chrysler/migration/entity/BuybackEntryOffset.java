package com.chrysler.migration.entity;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;


/**
 * The persistent class for the BUYBACK_ENTRY_OFFSET database table.
 * 
 */
@Entity
@Table(name="BYBK_ENTRY_OFFSET")
@NamedQuery(name="BuybackEntryOffset.findAll", query="SELECT b FROM BuybackEntryOffset b")
public class BuybackEntryOffset extends AuditColumns implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="I_BYBK_OFFSET_SEQ")
	private Integer iBybkOffsetSeq;

	@Column(name="A_COST_PER_MILE")
	private BigDecimal aCostPerMile;

	@Column(name="A_FLAT_USAGE_FEE")
	private BigDecimal aFlatUsageFee;

	@Column(name="A_PUR_PRC")
	private BigDecimal aPurPrc;

	@Column(name="I_MILES")
	private Integer iMiles;

	//bi-directional many-to-one association to Buyback
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="I_BYBK")
	private Buyback buyback;

	//bi-directional many-to-one association to CodeMaster
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="I_MSTR")
	private CodeMaster codeMaster1;

	//bi-directional many-to-one association to CodeMaster
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="I_DIVIDED_VAL")
	private CodeMaster codeMaster2;

	public BuybackEntryOffset() {
		//
	}

	public Integer getIBybkOffsetSeq() {
		return this.iBybkOffsetSeq;
	}

	public void setIBybkOffsetSeq(Integer iBybkOffsetSeq) {
		this.iBybkOffsetSeq = iBybkOffsetSeq;
	}

	public BigDecimal getACostPerMile() {
		return this.aCostPerMile;
	}

	public void setACostPerMile(BigDecimal aCostPerMile) {
		this.aCostPerMile = aCostPerMile;
	}

	public BigDecimal getAFlatUsageFee() {
		return this.aFlatUsageFee;
	}

	public void setAFlatUsageFee(BigDecimal aFlatUsageFee) {
		this.aFlatUsageFee = aFlatUsageFee;
	}

	public BigDecimal getAPurPrc() {
		return this.aPurPrc;
	}

	public void setAPurPrc(BigDecimal aPurPrc) {
		this.aPurPrc = aPurPrc;
	}

	public int getIMiles() {
		return this.iMiles;
	}

	public void setIMiles(int iMiles) {
		this.iMiles = iMiles;
	}

	public Buyback getBuyback() {
		return this.buyback;
	}

	public void setBuyback(Buyback buyback) {
		this.buyback = buyback;
	}

	public CodeMaster getCodeMaster1() {
		return this.codeMaster1;
	}

	public void setCodeMaster1(CodeMaster codeMaster1) {
		this.codeMaster1 = codeMaster1;
	}

	public CodeMaster getCodeMaster2() {
		return this.codeMaster2;
	}

	public void setCodeMaster2(CodeMaster codeMaster2) {
		this.codeMaster2 = codeMaster2;
	}

}