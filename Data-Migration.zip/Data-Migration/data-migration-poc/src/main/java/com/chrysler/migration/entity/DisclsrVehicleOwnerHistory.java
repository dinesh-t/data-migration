package com.chrysler.migration.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * The persistent class for the DISCLSR_VEHICLE_OWNER_HISTORY database table.
 * 
 */
@Entity
@Table(name = "DISCLSR_VEHICLE_OWNER_HISTORY")
@NamedQuery(name = "DisclsrVehicleOwnerHistory.findAll", query = "SELECT d FROM DisclsrVehicleOwnerHistory d")
public class DisclsrVehicleOwnerHistory extends AuditColumns implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name = "I_DISCLSR_HIST_SEQ")
	private int iDisclsrHistSeq;

	@Column(name = "A_WHSL_PRC")
	private BigDecimal aWhslPrc;

	@Column(name = "C_CSGND_ZIP")
	private String cCsgndZip;

	@Column(name = "C_DEPT")
	private int cDept;

	@Column(name = "C_DISCLSR_ZIP")
	private String cDisclsrZip;

	@Column(name = "C_EMISS")
	private String cEmiss;

	@Column(name = "C_INV_ZIP")
	private String cInvZip;

	@Column(name = "C_LOC")
	private int cLoc;

	@Column(name = "C_PRNT_DLR")
	private int cPrntDlr;

	@Column(name = "C_RE_MKTG_OUTPUT")
	private String cReMktgOutput;

	@Column(name = "C_SEDTRAN_RET")
	private String cSedtranRet;

	@Column(name = "C_VHCL_MOD")
	private String cVhclMod;

	@Temporal(TemporalType.DATE)
	@Column(name = "D_AUCTN_PUR")
	private Date dAuctnPur;

	@Temporal(TemporalType.DATE)
	@Column(name = "D_CSGND")
	private Date dCsgnd;

	@Temporal(TemporalType.DATE)
	@Column(name = "D_CSGND_AUCTN")
	private Date dCsgndAuctn;

	@Temporal(TemporalType.DATE)
	@Column(name = "D_INV_AUCTN")
	private Date dInvAuctn;

	@Temporal(TemporalType.DATE)
	@Column(name = "D_REC_HIST")
	private Date dRecHist;

	@Temporal(TemporalType.DATE)
	@Column(name = "D_REQSTD_AUCTN")
	private Date dReqstdAuctn;

	@Temporal(TemporalType.DATE)
	@Column(name = "D_SOLD")
	private Date dSold;

	@Temporal(TemporalType.DATE)
	@Column(name = "D_SOLD_DLR")
	private Date dSoldDlr;

	@Temporal(TemporalType.DATE)
	@Column(name = "D_VR_PUR")
	private Date dVrPur;

	@Column(name = "I_DISCLSR_CAIR")
	private String iDisclsrCair;

	@Column(name = "I_PRTITN")
	private int iPrtitn;

	@Column(name = "I_VHCL_MY")
	private int iVhclMy;

	@Column(name = "N_CSGND_AUCTN")
	private String nCsgndAuctn;

	@Column(name = "N_CSGND_CITY")
	private String nCsgndCity;

	@Column(name = "N_DISCLSR_CITY")
	private String nDisclsrCity;

	@Column(name = "N_INV_AUCTN")
	private String nInvAuctn;

	@Column(name = "N_INV_CITY")
	private String nInvCity;

	@Column(name = "N_VHCL_MAKE")
	private String nVhclMake;

	@Column(name = "N_VHCL_MOD")
	private String nVhclMod;

	@Column(name = "Q_CURR_MILG")
	private int qCurrMilg;

	@Column(name = "T_SEDTRAN_SEND")
	private Timestamp tSedtranSend;

	@Column(name = "X_CSGND_LINE_1")
	private String xCsgndLine1;

	@Column(name = "X_CSGND_LINE_2")
	private String xCsgndLine2;

	@Column(name = "X_DOCU_READER")
	private String xDocuReader;

	@Column(name = "X_DOCUAUT")
	private String xDocuaut;

	@Column(name = "X_INV_LINE_1")
	private String xInvLine1;

	@Column(name = "X_INV_LINE_2")
	private String xInvLine2;

	@Column(name = "I_CSGND_PRMRY_PH")
	private String iCsgndPrmryPh;

	@Column(name = "I_CSGND_ALT_PH")
	private String iCsgndAltPh;

	@Column(name = "I_INV_PRMRY_PH")
	private String iInvPrmryPh;

	@Column(name = "I_INV_ALT_PH")
	private String iInvAltPh;

	@Temporal(TemporalType.DATE)
	@Column(name = "D_PRNT_DLR")
	private Date dPrntDlr;

	@Temporal(TemporalType.DATE)
	@Column(name = "D_PRNT_WSHLD")
	private Date dPrntWshld;

	@Column(name = "C_PRNT_DLR_ZIP")
	private String cPrntDlrZip;

	@Column(name = "N_PRNT_DLR_CITY")
	private String nPrntDlrCity;

	@Column(name = "X_PRNT_DLR_ADDR")
	private String xPrntDlrAddr;

	@Column(name = "N_PRNT_DLR")
	private String nPrntDlr;

	@Column(name = "I_CURR")
	private Integer iCurr;

	@Column(name = "L_VHCL_MSO")
	private String lVhclMso;

	@Column(name = "L_VHCL_TI")
	private String lVhclTi;

	@Column(name = "N_LOC")
	private String nLoc;

	@Column(name = "X_LINE_1")
	private String xLine1;

	@Column(name = "N_CITY")
	private String nCity;

	@Column(name = "C_STATE")
	private String cState;

	@Column(name = "I_ZIP")
	private int iZip;

	@Column(name = "N_CNTRY_ABRV")
	private String nCntryAbrv;

	@Column(name = "I_MOD_YR")
	private int iModYr;

	@Column(name = "G_MOD_BDY")
	private String gModBdy;

	@Column(name = "N_MOD")
	private String nMod;

	@Column(name = "D_VHCL_STAT")
	private Timestamp dVhclStat;

	@Column(name = "C_VHCL")
	private String cVhcl;

	@Column(name = "N_PERSN_CNTCT")
	private String nPersnCntct;

	@Column(name = "X_COMNT_1")
	private String xComnt1;

	@Column(name = "X_COMNT_2")
	private String xComnt2;

	@Column(name = "X_COMNT_3")
	private String xComnt3;

	@Column(name = "I_CORPLOC")
	private int iCorploc;

	// bi-directional many-to-one association to AuctionDetail
	@ManyToOne
	@JoinColumn(name = "C_INV_AUCTN", referencedColumnName = "C_AUCTN_CENTR")
	private AuctionDetail auctionDetail1;

	// bi-directional many-to-one association to AuctionDetail
	@ManyToOne
	@JoinColumn(name = "C_REQSTD_AUCTN", referencedColumnName = "C_AUCTN_CENTR")
	private AuctionDetail auctionDetail2;

	// bi-directional many-to-one association to AuctionDetail
	@ManyToOne
	@JoinColumn(name = "C_CSGND_AUCTN", referencedColumnName = "C_AUCTN_CENTR")
	private AuctionDetail auctionDetail3;

	// bi-directional many-to-one association to Bybk
	@ManyToOne
	@JoinColumn(name = "I_BYBK")
	private Buyback bybk;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne
	@JoinColumn(name = "I_CSGNMT_STAT")
	private CodeMaster codeMaster1;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne
	@JoinColumn(name = "I_SEDTRAN_STAT")
	private CodeMaster codeMaster2;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne
	@JoinColumn(name = "I_CSGND_STATE")
	private CodeMaster codeMaster3;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne
	@JoinColumn(name = "I_INV_STATE")
	private CodeMaster codeMaster4;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne
	@JoinColumn(name = "I_DISCLSR_STATE")
	private CodeMaster codeMaster5;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne
	@JoinColumn(name = "I_DISCLSR_TYP")
	private CodeMaster codeMaster6;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne
	@JoinColumn(name = "I_CNTL_FLAG")
	private CodeMaster codeMaster7;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne
	@JoinColumn(name = "I_TI_STATE")
	private CodeMaster codeMaster8;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne
	@JoinColumn(name = "I_VR_DLR_STATE")
	private CodeMaster codeMaster9;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne
	@JoinColumn(name = "I_AUCTN_DLR_STATE")
	private CodeMaster codeMaster10;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne
	@JoinColumn(name = "I_BYBK_CATGY")
	private CodeMaster codeMaster11;

	// bi-directional many-to-one association to DealerDetail
	@ManyToOne
	@JoinColumn(name = "I_BUS_DLR_FRNCHZ", referencedColumnName = "C_DLR")
	private DealerDetail dealerDetail;

	// bi-directional many-to-one association to DisclsrNonBybk
	@ManyToOne
	@JoinColumn(name = "I_NON_BYBK")
	private DisclsrNonBybk disclsrNonBybk;

	// bi-directional many-to-one association to DisclsrVehicleOwner
	@ManyToOne
	@JoinColumn(name = "I_DISCLSR_VIN")
	private DisclsrVehicleOwner disclsrVehicleOwner;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_PRNT_DLR_STATE")
	private CodeMaster iPrintDlrState;

	// bi-directional many-to-one association to DealerDetail
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "C_INV_DLR", referencedColumnName = "C_DLR")
	private DealerDetail cInvDlr;

	@Column(name = "N_INV_DLR")
	private String nInvDlr;

	@Column(name = "X_INV_DLR_LINE_1")
	private String xInvDlrLine1;

	@Column(name = "X_INV_DLR_LINE_2")
	private String xInvDlrLine2;

	@Column(name = "X_INV_DLR_CITY")
	private String xInvDlrCity;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_INV_DLR_STATE")
	private CodeMaster iInvDlrState;

	@Column(name = "N_INV_DLR_CNTRY")
	private String nInvDlrCntry;

	@Column(name = "C_INV_DLR_ZIP")
	private String cInvDlrZip;

	// bi-directional many-to-one association to DealerDetail
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "C_CSGND_DLR", referencedColumnName = "C_DLR")
	private DealerDetail cCsgndDlr;

	@Column(name = "N_CSGND_DLR")
	private String nCsgndDlr;

	@Column(name = "X_CSGND_DLR_LINE_1")
	private String xCsgndDlrLine1;

	@Column(name = "X_CSGND_DLR_LINE_2")
	private String xCsgndDlrLine2;

	@Column(name = "X_CSGND_DLR_CITY")
	private String xCsgndDlrCity;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_CSGND_DLR_STATE")
	private CodeMaster iCsgndDlrState;

	@Column(name = "N_CSGND_DLR_CNTRY")
	private String nCsgndDlrCntry;

	@Column(name = "C_CSGND_DLR_ZIP")
	private String cCsgndDlrZip;

	@Column(name = "A_AUCTN_NET")
	private BigDecimal aAuctnNet;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_AUCTN_TYP")
	private CodeMaster iAuctnTpe;

	@Column(name = "D_AUCTN_RECV")
	private Timestamp dAuctnRecv;

	@Column(name = "A_AUCTN_GRS")
	private BigDecimal aAuctnGrs;

	public Date getdPrntDlr() {
		return dPrntDlr;
	}

	public Date getdPrntWshld() {
		return dPrntWshld;
	}

	public String getcPrntDlrZip() {
		return cPrntDlrZip;
	}

	public String getnPrntDlrCity() {
		return nPrntDlrCity;
	}

	public String getxPrntDlrAddr() {
		return xPrntDlrAddr;
	}

	public String getnPrntDlr() {
		return nPrntDlr;
	}

	public void setdPrntDlr(Date dPrntDlr) {
		this.dPrntDlr = dPrntDlr;
	}

	public void setdPrntWshld(Date dPrntWshld) {
		this.dPrntWshld = dPrntWshld;
	}

	public void setcPrntDlrZip(String cPrntDlrZip) {
		this.cPrntDlrZip = cPrntDlrZip;
	}

	public void setnPrntDlrCity(String nPrntDlrCity) {
		this.nPrntDlrCity = nPrntDlrCity;
	}

	public void setxPrntDlrAddr(String xPrntDlrAddr) {
		this.xPrntDlrAddr = xPrntDlrAddr;
	}

	public void setnPrntDlr(String nPrntDlr) {
		this.nPrntDlr = nPrntDlr;
	}

	public int getIDisclsrHistSeq() {
		return this.iDisclsrHistSeq;
	}

	public void setIDisclsrHistSeq(int iDisclsrHistSeq) {
		this.iDisclsrHistSeq = iDisclsrHistSeq;
	}

	public BigDecimal getAWhslPrc() {
		return this.aWhslPrc;
	}

	public void setAWhslPrc(BigDecimal aWhslPrc) {
		this.aWhslPrc = aWhslPrc;
	}

	public String getCCsgndZip() {
		return this.cCsgndZip;
	}

	public void setCCsgndZip(String cCsgndZip) {
		this.cCsgndZip = cCsgndZip;
	}

	public int getCDept() {
		return this.cDept;
	}

	public void setCDept(int cDept) {
		this.cDept = cDept;
	}

	public String getCDisclsrZip() {
		return this.cDisclsrZip;
	}

	public void setCDisclsrZip(String cDisclsrZip) {
		this.cDisclsrZip = cDisclsrZip;
	}

	public String getCEmiss() {
		return this.cEmiss;
	}

	public void setCEmiss(String cEmiss) {
		this.cEmiss = cEmiss;
	}

	public String getCInvZip() {
		return this.cInvZip;
	}

	public void setCInvZip(String cInvZip) {
		this.cInvZip = cInvZip;
	}

	public int getCLoc() {
		return this.cLoc;
	}

	public void setCLoc(int cLoc) {
		this.cLoc = cLoc;
	}

	public int getCPrntDlr() {
		return this.cPrntDlr;
	}

	public void setCPrntDlr(int cPrntDlr) {
		this.cPrntDlr = cPrntDlr;
	}

	public String getCReMktgOutput() {
		return this.cReMktgOutput;
	}

	public void setCReMktgOutput(String cReMktgOutput) {
		this.cReMktgOutput = cReMktgOutput;
	}

	public String getCSedtranRet() {
		return this.cSedtranRet;
	}

	public void setCSedtranRet(String cSedtranRet) {
		this.cSedtranRet = cSedtranRet;
	}

	public String getCVhclMod() {
		return this.cVhclMod;
	}

	public void setCVhclMod(String cVhclMod) {
		this.cVhclMod = cVhclMod;
	}

	public Date getDAuctnPur() {
		return this.dAuctnPur;
	}

	public void setDAuctnPur(Date dAuctnPur) {
		this.dAuctnPur = dAuctnPur;
	}

	public Date getDCsgnd() {
		return this.dCsgnd;
	}

	public void setDCsgnd(Date dCsgnd) {
		this.dCsgnd = dCsgnd;
	}

	public Date getDCsgndAuctn() {
		return this.dCsgndAuctn;
	}

	public void setDCsgndAuctn(Date dCsgndAuctn) {
		this.dCsgndAuctn = dCsgndAuctn;
	}

	public Date getDInvAuctn() {
		return this.dInvAuctn;
	}

	public void setDInvAuctn(Date dInvAuctn) {
		this.dInvAuctn = dInvAuctn;
	}

	public Date getDRecHist() {
		return this.dRecHist;
	}

	public void setDRecHist(Date dRecHist) {
		this.dRecHist = dRecHist;
	}

	public Date getDReqstdAuctn() {
		return this.dReqstdAuctn;
	}

	public void setDReqstdAuctn(Date dReqstdAuctn) {
		this.dReqstdAuctn = dReqstdAuctn;
	}

	public Date getDSold() {
		return this.dSold;
	}

	public void setDSold(Date dSold) {
		this.dSold = dSold;
	}

	public Date getDSoldDlr() {
		return this.dSoldDlr;
	}

	public void setDSoldDlr(Date dSoldDlr) {
		this.dSoldDlr = dSoldDlr;
	}

	public Date getDVrPur() {
		return this.dVrPur;
	}

	public void setDVrPur(Date dVrPur) {
		this.dVrPur = dVrPur;
	}

	public String getIDisclsrCair() {
		return this.iDisclsrCair;
	}

	public void setIDisclsrCair(String iDisclsrCair) {
		this.iDisclsrCair = iDisclsrCair;
	}

	public int getIPrtitn() {
		return this.iPrtitn;
	}

	public void setIPrtitn(int iPrtitn) {
		this.iPrtitn = iPrtitn;
	}

	public int getIVhclMy() {
		return this.iVhclMy;
	}

	public void setIVhclMy(int iVhclMy) {
		this.iVhclMy = iVhclMy;
	}

	public String getNCsgndAuctn() {
		return this.nCsgndAuctn;
	}

	public void setNCsgndAuctn(String nCsgndAuctn) {
		this.nCsgndAuctn = nCsgndAuctn;
	}

	public String getNCsgndCity() {
		return this.nCsgndCity;
	}

	public void setNCsgndCity(String nCsgndCity) {
		this.nCsgndCity = nCsgndCity;
	}

	public String getNDisclsrCity() {
		return this.nDisclsrCity;
	}

	public void setNDisclsrCity(String nDisclsrCity) {
		this.nDisclsrCity = nDisclsrCity;
	}

	public String getNInvAuctn() {
		return this.nInvAuctn;
	}

	public void setNInvAuctn(String nInvAuctn) {
		this.nInvAuctn = nInvAuctn;
	}

	public String getNInvCity() {
		return this.nInvCity;
	}

	public void setNInvCity(String nInvCity) {
		this.nInvCity = nInvCity;
	}

	public String getNVhclMake() {
		return this.nVhclMake;
	}

	public void setNVhclMake(String nVhclMake) {
		this.nVhclMake = nVhclMake;
	}

	public String getNVhclMod() {
		return this.nVhclMod;
	}

	public void setNVhclMod(String nVhclMod) {
		this.nVhclMod = nVhclMod;
	}

	public int getQCurrMilg() {
		return this.qCurrMilg;
	}

	public void setQCurrMilg(int qCurrMilg) {
		this.qCurrMilg = qCurrMilg;
	}

	public Timestamp getTSedtranSend() {
		return this.tSedtranSend;
	}

	public void setTSedtranSend(Timestamp tSedtranSend) {
		this.tSedtranSend = tSedtranSend;
	}

	public String getXCsgndLine1() {
		return this.xCsgndLine1;
	}

	public void setXCsgndLine1(String xCsgndLine1) {
		this.xCsgndLine1 = xCsgndLine1;
	}

	public String getXCsgndLine2() {
		return this.xCsgndLine2;
	}

	public void setXCsgndLine2(String xCsgndLine2) {
		this.xCsgndLine2 = xCsgndLine2;
	}

	public String getXDocuReader() {
		return this.xDocuReader;
	}

	public void setXDocuReader(String xDocuReader) {
		this.xDocuReader = xDocuReader;
	}

	public String getXDocuaut() {
		return this.xDocuaut;
	}

	public void setXDocuaut(String xDocuaut) {
		this.xDocuaut = xDocuaut;
	}

	public String getXInvLine1() {
		return this.xInvLine1;
	}

	public void setXInvLine1(String xInvLine1) {
		this.xInvLine1 = xInvLine1;
	}

	public String getXInvLine2() {
		return this.xInvLine2;
	}

	public void setXInvLine2(String xInvLine2) {
		this.xInvLine2 = xInvLine2;
	}

	public AuctionDetail getAuctionDetail1() {
		return this.auctionDetail1;
	}

	public void setAuctionDetail1(AuctionDetail auctionDetail1) {
		this.auctionDetail1 = auctionDetail1;
	}

	public AuctionDetail getAuctionDetail2() {
		return this.auctionDetail2;
	}

	public void setAuctionDetail2(AuctionDetail auctionDetail2) {
		this.auctionDetail2 = auctionDetail2;
	}

	public AuctionDetail getAuctionDetail3() {
		return this.auctionDetail3;
	}

	public void setAuctionDetail3(AuctionDetail auctionDetail3) {
		this.auctionDetail3 = auctionDetail3;
	}

	public Buyback getBybk() {
		return this.bybk;
	}

	public void setBybk(Buyback bybk) {
		this.bybk = bybk;
	}

	public CodeMaster getCodeMaster1() {
		return this.codeMaster1;
	}

	public void setCodeMaster1(CodeMaster codeMaster1) {
		this.codeMaster1 = codeMaster1;
	}

	public CodeMaster getCodeMaster2() {
		return this.codeMaster2;
	}

	public void setCodeMaster2(CodeMaster codeMaster2) {
		this.codeMaster2 = codeMaster2;
	}

	public CodeMaster getCodeMaster3() {
		return this.codeMaster3;
	}

	public void setCodeMaster3(CodeMaster codeMaster3) {
		this.codeMaster3 = codeMaster3;
	}

	public CodeMaster getCodeMaster4() {
		return this.codeMaster4;
	}

	public void setCodeMaster4(CodeMaster codeMaster4) {
		this.codeMaster4 = codeMaster4;
	}

	public CodeMaster getCodeMaster5() {
		return this.codeMaster5;
	}

	public void setCodeMaster5(CodeMaster codeMaster5) {
		this.codeMaster5 = codeMaster5;
	}

	public CodeMaster getCodeMaster6() {
		return this.codeMaster6;
	}

	public void setCodeMaster6(CodeMaster codeMaster6) {
		this.codeMaster6 = codeMaster6;
	}

	public CodeMaster getCodeMaster7() {
		return this.codeMaster7;
	}

	public void setCodeMaster7(CodeMaster codeMaster7) {
		this.codeMaster7 = codeMaster7;
	}

	public CodeMaster getCodeMaster8() {
		return this.codeMaster8;
	}

	public void setCodeMaster8(CodeMaster codeMaster8) {
		this.codeMaster8 = codeMaster8;
	}

	public CodeMaster getCodeMaster9() {
		return this.codeMaster9;
	}

	public void setCodeMaster9(CodeMaster codeMaster9) {
		this.codeMaster9 = codeMaster9;
	}

	public CodeMaster getCodeMaster10() {
		return this.codeMaster10;
	}

	public void setCodeMaster10(CodeMaster codeMaster10) {
		this.codeMaster10 = codeMaster10;
	}

	public CodeMaster getCodeMaster11() {
		return this.codeMaster11;
	}

	public void setCodeMaster11(CodeMaster codeMaster11) {
		this.codeMaster11 = codeMaster11;
	}

	public DealerDetail getDealerDetail() {
		return this.dealerDetail;
	}

	public void setDealerDetail(DealerDetail dealerDetail) {
		this.dealerDetail = dealerDetail;
	}

	public DisclsrNonBybk getDisclsrNonBybk() {
		return this.disclsrNonBybk;
	}

	public void setDisclsrNonBybk(DisclsrNonBybk disclsrNonBybk) {
		this.disclsrNonBybk = disclsrNonBybk;
	}

	public DisclsrVehicleOwner getDisclsrVehicleOwner() {
		return this.disclsrVehicleOwner;
	}

	public void setDisclsrVehicleOwner(DisclsrVehicleOwner disclsrVehicleOwner) {
		this.disclsrVehicleOwner = disclsrVehicleOwner;
	}

	public String getiCsgndPrmryPh() {
		return iCsgndPrmryPh;
	}

	public String getiCsgndAltPh() {
		return iCsgndAltPh;
	}

	public String getiInvPrmryPh() {
		return iInvPrmryPh;
	}

	public String getiInvAltPh() {
		return iInvAltPh;
	}

	public void setiCsgndPrmryPh(String iCsgndPrmryPh) {
		this.iCsgndPrmryPh = iCsgndPrmryPh;
	}

	public void setiCsgndAltPh(String iCsgndAltPh) {
		this.iCsgndAltPh = iCsgndAltPh;
	}

	public void setiInvPrmryPh(String iInvPrmryPh) {
		this.iInvPrmryPh = iInvPrmryPh;
	}

	public void setiInvAltPh(String iInvAltPh) {
		this.iInvAltPh = iInvAltPh;
	}

	public CodeMaster getiPrintDlrState() {
		return iPrintDlrState;
	}

	public void setiPrintDlrState(CodeMaster iPrintDlrState) {
		this.iPrintDlrState = iPrintDlrState;
	}

	public Integer getiCurr() {
		return iCurr;
	}

	public void setiCurr(Integer iCurr) {
		this.iCurr = iCurr;
	}

	public String getlVhclMso() {
		return lVhclMso;
	}

	public void setlVhclMso(String lVhclMso) {
		this.lVhclMso = lVhclMso;
	}

	public String getlVhclTi() {
		return lVhclTi;
	}

	public void setlVhclTi(String lVhclTi) {
		this.lVhclTi = lVhclTi;
	}

	public String getnLoc() {
		return nLoc;
	}

	public void setnLoc(String nLoc) {
		this.nLoc = nLoc;
	}

	public String getxLine1() {
		return xLine1;
	}

	public void setxLine1(String xLine1) {
		this.xLine1 = xLine1;
	}

	public String getnCity() {
		return nCity;
	}

	public void setnCity(String nCity) {
		this.nCity = nCity;
	}

	public String getcState() {
		return cState;
	}

	public void setcState(String cState) {
		this.cState = cState;
	}

	public int getiZip() {
		return iZip;
	}

	public void setiZip(int iZip) {
		this.iZip = iZip;
	}

	public String getnCntryAbrv() {
		return nCntryAbrv;
	}

	public void setnCntryAbrv(String nCntryAbrv) {
		this.nCntryAbrv = nCntryAbrv;
	}

	public int getiModYr() {
		return iModYr;
	}

	public void setiModYr(int iModYr) {
		this.iModYr = iModYr;
	}

	public String getgModBdy() {
		return gModBdy;
	}

	public void setgModBdy(String gModBdy) {
		this.gModBdy = gModBdy;
	}

	public String getnMod() {
		return nMod;
	}

	public void setnMod(String nMod) {
		this.nMod = nMod;
	}

	public Timestamp getdVhclStat() {
		return dVhclStat;
	}

	public void setdVhclStat(Timestamp dVhclStat) {
		this.dVhclStat = dVhclStat;
	}

	public String getcVhcl() {
		return cVhcl;
	}

	public void setcVhcl(String cVhcl) {
		this.cVhcl = cVhcl;
	}

	public String getnPersnCntct() {
		return nPersnCntct;
	}

	public void setnPersnCntct(String nPersnCntct) {
		this.nPersnCntct = nPersnCntct;
	}

	public String getxComnt1() {
		return xComnt1;
	}

	public void setxComnt1(String xComnt1) {
		this.xComnt1 = xComnt1;
	}

	public String getxComnt2() {
		return xComnt2;
	}

	public void setxComnt2(String xComnt2) {
		this.xComnt2 = xComnt2;
	}

	public String getxComnt3() {
		return xComnt3;
	}

	public void setxComnt3(String xComnt3) {
		this.xComnt3 = xComnt3;
	}

	public int getiCorploc() {
		return iCorploc;
	}

	public void setiCorploc(int iCorploc) {
		this.iCorploc = iCorploc;
	}

	public DealerDetail getcInvDlr() {
		return cInvDlr;
	}

	public void setcInvDlr(DealerDetail cInvDlr) {
		this.cInvDlr = cInvDlr;
	}

	public String getnInvDlr() {
		return nInvDlr;
	}

	public void setnInvDlr(String nInvDlr) {
		this.nInvDlr = nInvDlr;
	}

	public String getxInvDlrLine1() {
		return xInvDlrLine1;
	}

	public void setxInvDlrLine1(String xInvDlrLine1) {
		this.xInvDlrLine1 = xInvDlrLine1;
	}

	public String getxInvDlrLine2() {
		return xInvDlrLine2;
	}

	public void setxInvDlrLine2(String xInvDlrLine2) {
		this.xInvDlrLine2 = xInvDlrLine2;
	}

	public String getxInvDlrCity() {
		return xInvDlrCity;
	}

	public void setxInvDlrCity(String xInvDlrCity) {
		this.xInvDlrCity = xInvDlrCity;
	}

	public CodeMaster getiInvDlrState() {
		return iInvDlrState;
	}

	public void setiInvDlrState(CodeMaster iInvDlrState) {
		this.iInvDlrState = iInvDlrState;
	}

	public String getnInvDlrCntry() {
		return nInvDlrCntry;
	}

	public void setnInvDlrCntry(String nInvDlrCntry) {
		this.nInvDlrCntry = nInvDlrCntry;
	}

	public String getcInvDlrZip() {
		return cInvDlrZip;
	}

	public void setcInvDlrZip(String cInvDlrZip) {
		this.cInvDlrZip = cInvDlrZip;
	}

	public DealerDetail getcCsgndDlr() {
		return cCsgndDlr;
	}

	public void setcCsgndDlr(DealerDetail cCsgndDlr) {
		this.cCsgndDlr = cCsgndDlr;
	}

	public String getnCsgndDlr() {
		return nCsgndDlr;
	}

	public void setnCsgndDlr(String nCsgndDlr) {
		this.nCsgndDlr = nCsgndDlr;
	}

	public String getxCsgndDlrLine1() {
		return xCsgndDlrLine1;
	}

	public void setxCsgndDlrLine1(String xCsgndDlrLine1) {
		this.xCsgndDlrLine1 = xCsgndDlrLine1;
	}

	public String getxCsgndDlrLine2() {
		return xCsgndDlrLine2;
	}

	public void setxCsgndDlrLine2(String xCsgndDlrLine2) {
		this.xCsgndDlrLine2 = xCsgndDlrLine2;
	}

	public String getxCsgndDlrCity() {
		return xCsgndDlrCity;
	}

	public void setxCsgndDlrCity(String xCsgndDlrCity) {
		this.xCsgndDlrCity = xCsgndDlrCity;
	}

	public CodeMaster getiCsgndDlrState() {
		return iCsgndDlrState;
	}

	public void setiCsgndDlrState(CodeMaster iCsgndDlrState) {
		this.iCsgndDlrState = iCsgndDlrState;
	}

	public String getnCsgndDlrCntry() {
		return nCsgndDlrCntry;
	}

	public void setnCsgndDlrCntry(String nCsgndDlrCntry) {
		this.nCsgndDlrCntry = nCsgndDlrCntry;
	}

	public String getcCsgndDlrZip() {
		return cCsgndDlrZip;
	}

	public void setcCsgndDlrZip(String cCsgndDlrZip) {
		this.cCsgndDlrZip = cCsgndDlrZip;
	}

	public BigDecimal getaAuctnNet() {
		return aAuctnNet;
	}

	public void setaAuctnNet(BigDecimal aAuctnNet) {
		this.aAuctnNet = aAuctnNet;
	}

	public CodeMaster getiAuctnTpe() {
		return iAuctnTpe;
	}

	public void setiAuctnTpe(CodeMaster iAuctnTpe) {
		this.iAuctnTpe = iAuctnTpe;
	}

	public Timestamp getdAuctnRecv() {
		return dAuctnRecv;
	}

	public void setdAuctnRecv(Timestamp dAuctnRecv) {
		this.dAuctnRecv = dAuctnRecv;
	}

	public BigDecimal getaAuctnGrs() {
		return aAuctnGrs;
	}

	public void setaAuctnGrs(BigDecimal aAuctnGrs) {
		this.aAuctnGrs = aAuctnGrs;
	}

}