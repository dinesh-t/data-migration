package com.chrysler.migration.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * The persistent class for the WHERE_COND_MSTR database table.
 * 
 */
@Entity
@Table(name = "WHERE_COND_MSTR")
@NamedQuery(name = "WhereCondMstr.findAll", query = "SELECT w FROM WhereCondMstr w")
public class WhereCondMstr extends AuditColumns implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "I_WHERE_COND_SEQ")
	private int iWhereCondSeq;

	@Column(name = "L_BYBK")
	private String lBuyback;

	@Column(name = "I_WHERE_COND")
	private String iWhereCond;

	// bi-directional many-to-one association to TableMaster
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_FIRST_SLCTD_TBL")
	private TableMaster tableMaster1;

	// bi-directional many-to-one association to TableMaster
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_SEC_SLCTD_TBL")
	private TableMaster tableMaster2;

	public WhereCondMstr() {
	}

	public int getIWhereCondSeq() {
		return this.iWhereCondSeq;
	}

	public void setIWhereCondSeq(int iWhereCondSeq) {
		this.iWhereCondSeq = iWhereCondSeq;
	}

	public String getIWhereCond() {
		return this.iWhereCond;
	}

	public void setIWhereCond(String iWhereCond) {
		this.iWhereCond = iWhereCond;
	}

	public TableMaster getTableMaster1() {
		return this.tableMaster1;
	}

	public void setTableMaster1(TableMaster tableMaster1) {
		this.tableMaster1 = tableMaster1;
	}

	public TableMaster getTableMaster2() {
		return this.tableMaster2;
	}

	public void setTableMaster2(TableMaster tableMaster2) {
		this.tableMaster2 = tableMaster2;
	}

	public String getlBuyback() {
		return lBuyback;
	}

	public void setlBuyback(String lBuyback) {
		this.lBuyback = lBuyback;
	}

}