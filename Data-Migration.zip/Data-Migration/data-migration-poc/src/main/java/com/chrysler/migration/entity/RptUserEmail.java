package com.chrysler.migration.entity;

import java.io.Serializable;
import java.sql.Time;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * The persistent class for the RPT_USER_EMAIL database table.
 * 
 */
@Entity
@Table(name = "RPT_USER_EMAIL")
@NamedQuery(name = "RptUserEmail.findAll", query = "SELECT r FROM RptUserEmail r")
public class RptUserEmail extends AuditColumns implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "I_RPT_EMAIL_SEQ")
	private int iRptEmailSeq;

	@Column(name = "N_SCHD_TYP")
	private String nSchdTyp;

	@Column(name = "T_SCHD")
	private Time tSchd;

	@Column(name = "X_DEFLT_INPT_PARM")
	private String xDefltInptParm;

	@Column(name = "X_USER_EMAIL_ADDR")
	private String xUserEmailAddr;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne
	@JoinColumn(name = "I_RPT")
	private CodeMaster codeMaster;

	public RptUserEmail() {
	}

	public int getIRptEmailSeq() {
		return this.iRptEmailSeq;
	}

	public void setIRptEmailSeq(int iRptEmailSeq) {
		this.iRptEmailSeq = iRptEmailSeq;
	}

	public String getNSchdTyp() {
		return this.nSchdTyp;
	}

	public void setNSchdTyp(String nSchdTyp) {
		this.nSchdTyp = nSchdTyp;
	}

	public Time getTSchd() {
		return this.tSchd;
	}

	public void setTSchd(Time tSchd) {
		this.tSchd = tSchd;
	}

	public String getXDefltInptParm() {
		return this.xDefltInptParm;
	}

	public void setXDefltInptParm(String xDefltInptParm) {
		this.xDefltInptParm = xDefltInptParm;
	}

	public String getXUserEmailAddr() {
		return this.xUserEmailAddr;
	}

	public void setXUserEmailAddr(String xUserEmailAddr) {
		this.xUserEmailAddr = xUserEmailAddr;
	}

	public CodeMaster getCodeMaster() {
		return this.codeMaster;
	}

	public void setCodeMaster(CodeMaster codeMaster) {
		this.codeMaster = codeMaster;
	}

}