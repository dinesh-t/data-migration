package com.chrysler.migration.entity;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.Cascade;

/**
 * The persistent class for the TYPE_MASTER database table.
 * 
 */
@Entity
@Table(name = "TYPE_MASTER")
@NamedQuery(name = "TypeMaster.findAll", query = "SELECT t FROM TypeMaster t")
public class TypeMaster extends AuditColumns implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "C_TYP")
	private String cTyp;

	@Column(name = "L_TYP_EDITBL")
	private String lTypEditbl;

	@Column(name = "L_TYP_STAT")
	private String lTypStat;

	@Column(name = "X_TYP_DESC")
	private String xTypDesc;

	// bi-directional many-to-one association to CodeMaster
	@OneToMany(mappedBy = "typeMaster", cascade = CascadeType.REMOVE, orphanRemoval = true)
	@Cascade({ org.hibernate.annotations.CascadeType.SAVE_UPDATE, org.hibernate.annotations.CascadeType.DELETE,
			org.hibernate.annotations.CascadeType.MERGE, org.hibernate.annotations.CascadeType.PERSIST })
	private Set<CodeMaster> codeMasters;

	// bi-directional many-to-one association to ColumnMaster
	@OneToMany(mappedBy = "typeMaster")
	private Set<ColumnMaster> columnMasters;

	public TypeMaster() {
	}

	public String getCTyp() {
		return this.cTyp;
	}

	public void setCTyp(String cTyp) {
		this.cTyp = cTyp;
	}

	public String getLTypEditbl() {
		return this.lTypEditbl;
	}

	public void setLTypEditbl(String lTypEditbl) {
		this.lTypEditbl = lTypEditbl;
	}

	public String getLTypStat() {
		return this.lTypStat;
	}

	public void setLTypStat(String lTypStat) {
		this.lTypStat = lTypStat;
	}

	public String getXTypDesc() {
		return this.xTypDesc;
	}

	public void setXTypDesc(String xTypDesc) {
		this.xTypDesc = xTypDesc;
	}

	public Set<CodeMaster> getCodeMasters() {
		return this.codeMasters;
	}

	public void setCodeMasters(Set<CodeMaster> codeMasters) {
		this.codeMasters = codeMasters;
	}

	public CodeMaster addCodeMaster(CodeMaster codeMaster) {
		getCodeMasters().add(codeMaster);
		codeMaster.setTypeMaster(this);

		return codeMaster;
	}

	public CodeMaster removeCodeMaster(CodeMaster codeMaster) {
		getCodeMasters().remove(codeMaster);
		codeMaster.setTypeMaster(null);

		return codeMaster;
	}

	public Set<ColumnMaster> getColumnMasters() {
		return this.columnMasters;
	}

	public void setColumnMasters(Set<ColumnMaster> columnMasters) {
		this.columnMasters = columnMasters;
	}

	public ColumnMaster addColumnMaster(ColumnMaster columnMaster) {
		getColumnMasters().add(columnMaster);
		columnMaster.setTypeMaster(this);

		return columnMaster;
	}

	public ColumnMaster removeColumnMaster(ColumnMaster columnMaster) {
		getColumnMasters().remove(columnMaster);
		columnMaster.setTypeMaster(null);

		return columnMaster;
	}

}