package com.chrysler.migration.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * The persistent class for the DEALER_CONTACT database table.
 * 
 */
@Entity
@Table(name = "DEALER_CONTACT")
@NamedQuery(name = "DealerContact.findAll", query = "SELECT d FROM DealerContact d")
public class DealerContact extends AuditColumns implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "I_DLR_CNTCT_SEQ")
	private int iDlrCntctSeq;

	@Column(name = "I_DLR_ALT_PH")
	private String iDlrAltPh;

	@Column(name = "I_DLR_PRMRY_PH")
	private String iDlrPrmryPh;

	@Column(name = "N_DLR_PERSN")
	private String nDlrPersn;

	@Column(name = "N_DLR_TI")
	private String nDlrTi;

	// bi-directional many-to-one association to DealerDetail
	@ManyToOne
	@JoinColumn(name = "I_DLR_DTL")
	private DealerDetail dealerDetail;

	public DealerContact() {
	}

	public int getIDlrCntctSeq() {
		return this.iDlrCntctSeq;
	}

	public void setIDlrCntctSeq(int iDlrCntctSeq) {
		this.iDlrCntctSeq = iDlrCntctSeq;
	}

	public String getIDlrAltPh() {
		return this.iDlrAltPh;
	}

	public void setIDlrAltPh(String iDlrAltPh) {
		this.iDlrAltPh = iDlrAltPh;
	}

	public String getIDlrPrmryPh() {
		return this.iDlrPrmryPh;
	}

	public void setIDlrPrmryPh(String iDlrPrmryPh) {
		this.iDlrPrmryPh = iDlrPrmryPh;
	}

	public String getNDlrPersn() {
		return this.nDlrPersn;
	}

	public void setNDlrPersn(String nDlrPersn) {
		this.nDlrPersn = nDlrPersn;
	}

	public String getNDlrTi() {
		return this.nDlrTi;
	}

	public void setNDlrTi(String nDlrTi) {
		this.nDlrTi = nDlrTi;
	}

	public DealerDetail getDealerDetail() {
		return this.dealerDetail;
	}

	public void setDealerDetail(DealerDetail dealerDetail) {
		this.dealerDetail = dealerDetail;
	}

}