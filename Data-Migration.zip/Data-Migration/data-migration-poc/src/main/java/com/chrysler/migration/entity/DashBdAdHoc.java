package com.chrysler.migration.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * The persistent class for the DASH_BD_AD_HOC database table.
 * 
 */
@Entity
@Table(name = "DASH_BD_AD_HOC")
@NamedQuery(name = "DashBdAdHoc.findAll", query = "SELECT d FROM DashBdAdHoc d")
public class DashBdAdHoc extends AuditColumns implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "I_DASH_HOC_SEQ")
	private int iDashHocSeq;

	@Column(name = "X_LNK_ICON")
	private String xLnkIcon;

	// bi-directional many-to-one association to DashBd
	@ManyToOne
	@JoinColumn(name = "I_DASH_BD")
	private DashBd dashBd;

	// bi-directional many-to-one association to RptMstr
	@ManyToOne
	@JoinColumn(name = "I_AD_HOC")
	private RptMstr rptMstr;

	public DashBdAdHoc() {
	}

	public int getIDashHocSeq() {
		return this.iDashHocSeq;
	}

	public void setIDashHocSeq(int iDashHocSeq) {
		this.iDashHocSeq = iDashHocSeq;
	}

	public String getXLnkIcon() {
		return this.xLnkIcon;
	}

	public void setXLnkIcon(String xLnkIcon) {
		this.xLnkIcon = xLnkIcon;
	}

	public DashBd getDashBd() {
		return this.dashBd;
	}

	public void setDashBd(DashBd dashBd) {
		this.dashBd = dashBd;
	}

	public RptMstr getRptMstr() {
		return this.rptMstr;
	}

	public void setRptMstr(RptMstr rptMstr) {
		this.rptMstr = rptMstr;
	}

}