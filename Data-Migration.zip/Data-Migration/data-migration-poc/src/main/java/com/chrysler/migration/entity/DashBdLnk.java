package com.chrysler.migration.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * The persistent class for the DASH_BD_LNK database table.
 * 
 */
@Entity
@Table(name = "DASH_BD_LNK")
@NamedQuery(name = "DashBdLnk.findAll", query = "SELECT d FROM DashBdLnk d")
public class DashBdLnk extends AuditColumns implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "I_DASH_LNK_SEQ")
	private int iDashLnkSeq;

	@Column(name = "L_LNK_XTRNL")
	private String lLnkXtrnl;

	@Column(name = "N_LNK_LBL")
	private String nLnkLbl;

	@Column(name = "X_LNK_ICON")
	private String xLnkIcon;

	@Column(name = "X_LNK_URL")
	private String xLnkUrl;

	// bi-directional many-to-one association to DashBd
	@ManyToOne
	@JoinColumn(name = "I_DASH_BD")
	private DashBd dashBd;

	public DashBdLnk() {
	}

	public int getIDashLnkSeq() {
		return this.iDashLnkSeq;
	}

	public void setIDashLnkSeq(int iDashLnkSeq) {
		this.iDashLnkSeq = iDashLnkSeq;
	}

	public String getLLnkXtrnl() {
		return this.lLnkXtrnl;
	}

	public void setLLnkXtrnl(String lLnkXtrnl) {
		this.lLnkXtrnl = lLnkXtrnl;
	}

	public String getNLnkLbl() {
		return this.nLnkLbl;
	}

	public void setNLnkLbl(String nLnkLbl) {
		this.nLnkLbl = nLnkLbl;
	}

	public String getXLnkIcon() {
		return this.xLnkIcon;
	}

	public void setXLnkIcon(String xLnkIcon) {
		this.xLnkIcon = xLnkIcon;
	}

	public String getXLnkUrl() {
		return this.xLnkUrl;
	}

	public void setXLnkUrl(String xLnkUrl) {
		this.xLnkUrl = xLnkUrl;
	}

	public DashBd getDashBd() {
		return this.dashBd;
	}

	public void setDashBd(DashBd dashBd) {
		this.dashBd = dashBd;
	}

}