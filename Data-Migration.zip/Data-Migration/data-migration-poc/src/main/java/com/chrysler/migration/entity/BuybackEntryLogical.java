package com.chrysler.migration.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.MapsId;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.LazyToOne;
import org.hibernate.annotations.LazyToOneOption;

/**
 * The persistent class for the BUYBACK_ENTRY_LOGICAL database table.
 * 
 */
@Entity
@Table(name = "BYBK_ENTRY_LOGICAL")
@NamedQuery(name = "BuybackEntryLogical.findAll", query = "SELECT b FROM BuybackEntryLogical b")
public class BuybackEntryLogical extends AuditColumns implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private Integer iBybk;

	@Column(name = "L_LEAS")
	private String lLeas;

	@Column(name = "L_OWNR_MSRP_DIFF")
	private String lOwnrMsrpDiff;

	@Column(name = "L_OWNR_PAY_UPGR")
	private String lOwnrPayUpgr;

	@Column(name = "L_OWNR_SALES_TAX")
	private String lOwnrSalesTax;

	@Column(name = "L_OWNR_TI_FEE")
	private String lOwnrTiFee;

	@Column(name = "L_RFND_DOC_FEE")
	private String lRfndDocFee;

	@Column(name = "L_RFND_DOWN_PAYMT")
	private String lRfndDownPaymt;

	@Column(name = "L_RFND_FEE")
	private String lRfndFee;

	@Column(name = "L_RFND_FINC_CHRG")
	private String lRfndFincChrg;

	@Column(name = "L_RFND_MNTLY_RNTL")
	private String lRfndMntlyRntl;

	@Column(name = "L_RFND_PUR_PRC")
	private String lRfndPurPrc;

	@Column(name = "L_RFND_SALES_TAX")
	private String lRfndSalesTax;

	@Column(name = "L_RFND_SCRTY_DPST")
	private String lRfndScrtyDpst;

	@Column(name = "L_RFND_TI_FEE")
	private String lRfndTiFee;

	@Column(name = "L_MILG_OFFSET")
	private String lMilgOffset;

	@Column(name = "I_TOT_OFFSET")
	private Integer iTotOffset;

	@Column(name = "L_RFND_TRD_ALWNC")
	private String lRfndTrdAlwnc;

	// bi-directional many-to-one association to Buyback
	@OneToOne(fetch = FetchType.LAZY)
	@MapsId
	@LazyToOne(LazyToOneOption.NO_PROXY)
	@JoinColumn(name = "I_BYBK")
	private Buyback buyback;

	public BuybackEntryLogical() {
		//
	}

	public Integer getiBybk() {
		return iBybk;
	}

	public void setiBybk(Integer iBybk) {
		this.iBybk = iBybk;
	}

	public String getLLeas() {
		return this.lLeas;
	}

	public void setLLeas(String lLeas) {
		this.lLeas = lLeas;
	}

	public String getLOwnrMsrpDiff() {
		return this.lOwnrMsrpDiff;
	}

	public void setLOwnrMsrpDiff(String lOwnrMsrpDiff) {
		this.lOwnrMsrpDiff = lOwnrMsrpDiff;
	}

	public String getLOwnrPayUpgr() {
		return this.lOwnrPayUpgr;
	}

	public void setLOwnrPayUpgr(String lOwnrPayUpgr) {
		this.lOwnrPayUpgr = lOwnrPayUpgr;
	}

	public String getLOwnrSalesTax() {
		return this.lOwnrSalesTax;
	}

	public void setLOwnrSalesTax(String lOwnrSalesTax) {
		this.lOwnrSalesTax = lOwnrSalesTax;
	}

	public String getLOwnrTiFee() {
		return this.lOwnrTiFee;
	}

	public void setLOwnrTiFee(String lOwnrTiFee) {
		this.lOwnrTiFee = lOwnrTiFee;
	}

	public String getLRfndDocFee() {
		return this.lRfndDocFee;
	}

	public void setLRfndDocFee(String lRfndDocFee) {
		this.lRfndDocFee = lRfndDocFee;
	}

	public String getLRfndDownPaymt() {
		return this.lRfndDownPaymt;
	}

	public void setLRfndDownPaymt(String lRfndDownPaymt) {
		this.lRfndDownPaymt = lRfndDownPaymt;
	}

	public String getLRfndFee() {
		return this.lRfndFee;
	}

	public void setLRfndFee(String lRfndFee) {
		this.lRfndFee = lRfndFee;
	}

	public String getLRfndFincChrg() {
		return this.lRfndFincChrg;
	}

	public void setLRfndFincChrg(String lRfndFincChrg) {
		this.lRfndFincChrg = lRfndFincChrg;
	}

	public String getLRfndMntlyRntl() {
		return this.lRfndMntlyRntl;
	}

	public void setLRfndMntlyRntl(String lRfndMntlyRntl) {
		this.lRfndMntlyRntl = lRfndMntlyRntl;
	}

	public String getLRfndPurPrc() {
		return this.lRfndPurPrc;
	}

	public void setLRfndPurPrc(String lRfndPurPrc) {
		this.lRfndPurPrc = lRfndPurPrc;
	}

	public String getLRfndSalesTax() {
		return this.lRfndSalesTax;
	}

	public void setLRfndSalesTax(String lRfndSalesTax) {
		this.lRfndSalesTax = lRfndSalesTax;
	}

	public String getLRfndScrtyDpst() {
		return this.lRfndScrtyDpst;
	}

	public void setLRfndScrtyDpst(String lRfndScrtyDpst) {
		this.lRfndScrtyDpst = lRfndScrtyDpst;
	}

	public String getLRfndTiFee() {
		return this.lRfndTiFee;
	}

	public void setLRfndTiFee(String lRfndTiFee) {
		this.lRfndTiFee = lRfndTiFee;
	}

	public String getLRfndTrdAlwnc() {
		return this.lRfndTrdAlwnc;
	}

	public void setLRfndTrdAlwnc(String lRfndTrdAlwnc) {
		this.lRfndTrdAlwnc = lRfndTrdAlwnc;
	}

	public Buyback getBuyback() {
		return this.buyback;
	}

	public void setBuyback(Buyback buyback) {
		this.buyback = buyback;
	}

	public String getlMilgOffset() {
		return lMilgOffset;
	}

	public void setlMilgOffset(String lMilgOffset) {
		this.lMilgOffset = lMilgOffset;
	}

	public Integer getiTotOffset() {
		return iTotOffset;
	}

	public void setiTotOffset(Integer iTotOffset) {
		this.iTotOffset = iTotOffset;
	}

}