package com.chrysler.migration.entity;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MapsId;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.LazyToOne;
import org.hibernate.annotations.LazyToOneOption;

/**
 * The persistent class for the CASH_AND_KEEP database table.
 * 
 */
@Entity
@Table(name = "CASH_AND_KEEP")
@NamedQuery(name = "CashAndKeep.findAll", query = "SELECT c FROM CashAndKeep c")
public class CashAndKeep extends AuditColumns implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private Integer iBybk;

	@Column(name = "A_CASH_KEEP")
	private BigDecimal aCashKeep;

	@Column(name = "L_VHCL_REP")
	private String lVhclRep;

	@Column(name = "X_ADDL_INFO")
	private String xAddlInfo;

	// bi-directional one-to-one association to Buyback
	@OneToOne(fetch = FetchType.LAZY)
	@MapsId
	@LazyToOne(LazyToOneOption.NO_PROXY)
	@JoinColumn(name = "I_BYBK")
	private Buyback buyback;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_REAS_CASH_KEEP")
	private CodeMaster codeMaster;

	public Integer getIBybk() {
		return this.iBybk;
	}

	public void setIBybk(int iBybk) {
		this.iBybk = iBybk;
	}

	public BigDecimal getACashKeep() {
		return this.aCashKeep;
	}

	public void setACashKeep(BigDecimal aCashKeep) {
		this.aCashKeep = aCashKeep;
	}

	public String getLVhclRep() {
		return this.lVhclRep;
	}

	public void setLVhclRep(String lVhclRep) {
		this.lVhclRep = lVhclRep;
	}

	public String getXAddlInfo() {
		return this.xAddlInfo;
	}

	public void setXAddlInfo(String xAddlInfo) {
		this.xAddlInfo = xAddlInfo;
	}

	public Buyback getBuyback() {
		return this.buyback;
	}

	public void setBuyback(Buyback buyback) {
		this.buyback = buyback;
	}

	public CodeMaster getCodeMaster() {
		return this.codeMaster;
	}

	public void setCodeMaster(CodeMaster codeMaster) {
		this.codeMaster = codeMaster;
	}

}