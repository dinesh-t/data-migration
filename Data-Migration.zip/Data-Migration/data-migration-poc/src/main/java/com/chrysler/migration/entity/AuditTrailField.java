package com.chrysler.migration.entity;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * The persistent class for the AUDIT_TRAIL_FIELD database table.
 * 
 */
@Entity
@Table(name = "AUDIT_TRAIL_FIELD")
@NamedQuery(name = "AuditTrailField.findAll", query = "SELECT a FROM AuditTrailField a")
public class AuditTrailField implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "I_AUD_FLD_SEQ")
	private Integer iAudFldSeq;

	@Column(name = "I_LOGON")
	private String iLogon;

	@Column(name = "I_LOGON_UPD")
	private String iLogonUpd;

	@Column(name = "L_TYP")
	private String lTyp;

	@Column(name = "T_STMP_ADD")
	private Timestamp tStmpAdd;

	@Column(name = "T_STMP_UPD")
	private Timestamp tStmpUpd;

	@Column(name = "X_AUD_NEW_VAL")
	private String xAudNewVal;

	@Column(name = "X_AUD_OLD_VAL")
	private String xAudOldVal;

	// bi-directional many-to-one association to auditTrailFunction
	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn(name = "I_AUD_FUNC")
	private AuditTrailFunction auditTrailFunction;

	// bi-directional many-to-one association to Buyback
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_BYBK")
	private Buyback buyback;

	// bi-directional many-to-one association to Buyback
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_NON_BYBK")
	private DisclsrNonBybk disclsrNonBybk;

	// bi-directional many-to-one association to ColumnMaster

	@Column(name = "N_COLM")
	private String nColm;

	@Column(name = "N_USER")
	private String nUser;

	public AuditTrailField() {
	}

	public Integer getIAudFldSeq() {
		return this.iAudFldSeq;
	}

	public void setIAudFldSeq(Integer iAudFldSeq) {
		this.iAudFldSeq = iAudFldSeq;
	}

	public String getILogon() {
		return this.iLogon;
	}

	public void setILogon(String iLogon) {
		this.iLogon = iLogon;
	}

	public String getILogonUpd() {
		return this.iLogonUpd;
	}

	public void setILogonUpd(String iLogonUpd) {
		this.iLogonUpd = iLogonUpd;
	}

	public String getLTyp() {
		return this.lTyp;
	}

	public void setLTyp(String lTyp) {
		this.lTyp = lTyp;
	}

	public Timestamp getTStmpAdd() {
		return this.tStmpAdd;
	}

	public void setTStmpAdd(Timestamp tStmpAdd) {
		this.tStmpAdd = tStmpAdd;
	}

	public Timestamp getTStmpUpd() {
		return this.tStmpUpd;
	}

	public void setTStmpUpd(Timestamp tStmpUpd) {
		this.tStmpUpd = tStmpUpd;
	}

	public String getXAudNewVal() {
		return this.xAudNewVal;
	}

	public void setXAudNewVal(String xAudNewVal) {
		this.xAudNewVal = xAudNewVal;
	}

	public String getXAudOldVal() {
		return this.xAudOldVal;
	}

	public void setXAudOldVal(String xAudOldVal) {
		this.xAudOldVal = xAudOldVal;
	}

	public AuditTrailFunction getAuditTrailFunction() {
		return this.auditTrailFunction;
	}

	public void setAuditTrailFunction(AuditTrailFunction auditTrailFunction) {
		this.auditTrailFunction = auditTrailFunction;
	}

	public Buyback getBuyback() {
		return this.buyback;
	}

	public void setBuyback(Buyback buyback) {
		this.buyback = buyback;
	}

	public String getnColm() {
		return nColm;
	}

	public void setnColm(String nColm) {
		this.nColm = nColm;
	}

	public String getnUser() {
		return nUser;
	}

	public void setnUser(String nUser) {
		this.nUser = nUser;
	}

}
