package com.chrysler.migration.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

/**
 * The persistent class for the RPT_ORDR_BY database table.
 * 
 */
@Entity
@Table(name = "RPT_ORDR_BY")
@NamedQuery(name = "RptOrdrBy.findAll", query = "SELECT r FROM RptOrdrBy r")
public class RptOrdrBy extends AuditColumns implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private RptOrdrByPK id;

	@Column(name = "L_BYBK")
	private String lBuyback;

	@Column(name = "C_ORDR_BY")
	private String cOrdrBy;

	// bi-directional many-to-one association to RptMstr
	@ManyToOne(fetch = FetchType.LAZY)
	@PrimaryKeyJoinColumn(name = "I_RPT", referencedColumnName = "I_RPT")
	private RptMstr rptMstr;

	// bi-directional many-to-one association to ColumnMaster
	@ManyToOne(fetch = FetchType.LAZY)
	@PrimaryKeyJoinColumn(name = "I_COLM", referencedColumnName = "I_COLM")
	private ColumnMaster columnMaster;

	public RptOrdrBy() {
	}

	public RptOrdrByPK getId() {
		return this.id;
	}

	public void setId(RptOrdrByPK id) {
		this.id = id;
	}

	public String getCOrdrBy() {
		return this.cOrdrBy;
	}

	public void setCOrdrBy(String cOrdrBy) {
		this.cOrdrBy = cOrdrBy;
	}

	public RptMstr getRptMstr() {
		return this.rptMstr;
	}

	public void setRptMstr(RptMstr rptMstr) {
		this.rptMstr = rptMstr;
	}

	public ColumnMaster getColumnMaster() {
		return this.columnMaster;
	}

	public void setColumnMaster(ColumnMaster columnMaster) {
		this.columnMaster = columnMaster;
	}

	public String getlBuyback() {
		return lBuyback;
	}

	public void setlBuyback(String lBuyback) {
		this.lBuyback = lBuyback;
	}

}