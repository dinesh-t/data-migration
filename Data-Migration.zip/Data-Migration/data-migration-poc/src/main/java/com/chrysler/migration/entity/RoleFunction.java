package com.chrysler.migration.entity;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import org.hibernate.annotations.LazyToOne;
import org.hibernate.annotations.LazyToOneOption;

/**
 * The persistent class for the ROLE_FUNCTION database table.
 * 
 */
@Entity
@Table(name = "ROLE_FUNCTION")
@NamedQuery(name = "RoleFunction.findAll", query = "SELECT r FROM RoleFunction r")
public class RoleFunction extends AuditColumns implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "I_ROLE_FUNC_SEQ")
	private Integer iRoleFuncSeq;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_FUNC")
	private CodeMaster roleFunctions;

	// bi-directional many-to-one association to Role
	@ManyToOne(fetch = FetchType.LAZY)
	@LazyToOne(LazyToOneOption.NO_PROXY)
	@JoinColumn(name = "I_ROLE")
	private Role role;

	public RoleFunction() {
	}

	public Integer getIRoleFuncSeq() {
		return this.iRoleFuncSeq;
	}

	public void setIRoleFuncSeq(Integer iRoleFuncSeq) {
		this.iRoleFuncSeq = iRoleFuncSeq;
	}

	public CodeMaster getRoleFunctions() {
		return roleFunctions;
	}

	public void setRoleFunctions(CodeMaster roleFunctions) {
		this.roleFunctions = roleFunctions;
	}

	public Role getRole() {
		return this.role;
	}

	public void setRole(Role role) {
		this.role = role;
	}

}