package com.chrysler.migration.entity;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the BUYBACK_REQUIRED_DOCUMENT database table.
 * 
 */
@Entity
@Table(name="BYBK_REQUIRED_DOCUMENT")
@NamedQuery(name="BuybackRequiredDocument.findAll", query="SELECT b FROM BuybackRequiredDocument b")
public class BuybackRequiredDocument extends AuditColumns implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="I_BYBK_REQD_SEQ")
	private int iBybkReqdSeq;

	//bi-directional many-to-one association to CodeMaster
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="I_BYBK_TYP")
	private CodeMaster codeMaster1;

	//bi-directional many-to-one association to CodeMaster
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="I_REQD_DOCU")
	private CodeMaster codeMaster2;

	public BuybackRequiredDocument() {
		//
	}

	public int getIBybkReqdSeq() {
		return this.iBybkReqdSeq;
	}

	public void setIBybkReqdSeq(int iBybkReqdSeq) {
		this.iBybkReqdSeq = iBybkReqdSeq;
	}

	public CodeMaster getCodeMaster1() {
		return this.codeMaster1;
	}

	public void setCodeMaster1(CodeMaster codeMaster1) {
		this.codeMaster1 = codeMaster1;
	}

	public CodeMaster getCodeMaster2() {
		return this.codeMaster2;
	}

	public void setCodeMaster2(CodeMaster codeMaster2) {
		this.codeMaster2 = codeMaster2;
	}

}