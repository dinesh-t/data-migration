package com.chrysler.migration.entity;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the BUYBACK_ATTACHMENT database table.
 * 
 */
@Entity
@Table(name="BYBK_ATTACHMENT")
@NamedQuery(name="BuybackAttachment.findAll", query="SELECT b FROM BuybackAttachment b")
public class BuybackAttachment implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="I_ATCHMT_SEQ")
	private int iAtchmtSeq;

	@Column(name="C_ATCHMT_FILE_TYP")
	private String cAtchmtFileTyp;

	@Column(name="I_ATCHMT_FILE")
	private int iAtchmtFile;

	@Column(name="I_LOGON")
	private String iLogon;

	@Column(name="I_LOGON_UPD")
	private String iLogonUpd;

	@Column(name="N_ATCHMT_FILE")
	private String nAtchmtFile;

	@Column(name="T_STMP_ADD")
	private Timestamp tStmpAdd;

	@Column(name="T_STMP_UPD")
	private Timestamp tStmpUpd;

	@Column(name="X_ATCHMT_FILE_LNK")
	private String xAtchmtFileLnk;

	//bi-directional many-to-one association to Buyback
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="I_BYBK")
	private Buyback buyback;

	public BuybackAttachment() {
	}

	public int getIAtchmtSeq() {
		return this.iAtchmtSeq;
	}

	public void setIAtchmtSeq(int iAtchmtSeq) {
		this.iAtchmtSeq = iAtchmtSeq;
	}

	public String getCAtchmtFileTyp() {
		return this.cAtchmtFileTyp;
	}

	public void setCAtchmtFileTyp(String cAtchmtFileTyp) {
		this.cAtchmtFileTyp = cAtchmtFileTyp;
	}

	public int getIAtchmtFile() {
		return this.iAtchmtFile;
	}

	public void setIAtchmtFile(int iAtchmtFile) {
		this.iAtchmtFile = iAtchmtFile;
	}

	public String getILogon() {
		return this.iLogon;
	}

	public void setILogon(String iLogon) {
		this.iLogon = iLogon;
	}

	public String getILogonUpd() {
		return this.iLogonUpd;
	}

	public void setILogonUpd(String iLogonUpd) {
		this.iLogonUpd = iLogonUpd;
	}

	public String getNAtchmtFile() {
		return this.nAtchmtFile;
	}

	public void setNAtchmtFile(String nAtchmtFile) {
		this.nAtchmtFile = nAtchmtFile;
	}

	public Timestamp getTStmpAdd() {
		return this.tStmpAdd;
	}

	public void setTStmpAdd(Timestamp tStmpAdd) {
		this.tStmpAdd = tStmpAdd;
	}

	public Timestamp getTStmpUpd() {
		return this.tStmpUpd;
	}

	public void setTStmpUpd(Timestamp tStmpUpd) {
		this.tStmpUpd = tStmpUpd;
	}

	public String getXAtchmtFileLnk() {
		return this.xAtchmtFileLnk;
	}

	public void setXAtchmtFileLnk(String xAtchmtFileLnk) {
		this.xAtchmtFileLnk = xAtchmtFileLnk;
	}

	public Buyback getBuyback() {
		return this.buyback;
	}

	public void setBuyback(Buyback buyback) {
		this.buyback = buyback;
	}

}