package com.chrysler.migration.entity;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * The persistent class for the DEALER_DETAIL database table.
 * 
 */
@Entity
@Table(name = "DEALER_DETAIL")
@NamedQuery(name = "DealerDetail.findAll", query = "SELECT d FROM DealerDetail d")
public class DealerDetail extends AuditColumns implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "I_DLR_DTL_SEQ")
	private int iDlrDtlSeq;

	@Column(name = "C_DLR", nullable = false)
	private String cDlr;

	@Column(name = "C_DLR_ZIP")
	private String cDlrZip;

	@Column(name = "I_DLR_ALT_PH")
	private String iDlrAltPh;

	@Column(name = "I_DLR_PRMRY_PH")
	private String iDlrPrmryPh;

	@Column(name = "N_DLR")
	private String nDlr;

	@Column(name = "N_DLR_CITY")
	private String nDlrCity;

	@Column(name = "N_DLR_CNTRY")
	private String nDlrCntry;

	@Column(name = "N_DLR_ZONE")
	private String nDlrZone;

	@Column(name = "X_DLR_ADDR")
	private String xDlrAddr;

	@Column(name = "X_DLR_ZONE")
	private String xDlrZone;

	@Column(name = "L_ACT")
	private String lAct;

	@Column(name = "L_FRNCHZ")
	private String lFrnchz;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_BUS_CENTR")
	private CodeMaster bussinessCenterCode;

	// bi-directional many-to-one association to DealerContact
	@OneToMany(mappedBy = "dealerDetail", fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	private Set<DealerContact> dealerContacts;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne
	@JoinColumn(name = "I_DLR_STATE")
	private CodeMaster dealerStateCode;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne
	@JoinColumn(name = "I_DLR_ZONE_DIST")
	private CodeMaster dealerDistrictCode;

	// bi-directional many-to-one association to DealerRestriction
	@OneToMany(mappedBy = "dealerDetail", fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	private Set<DealerRestriction> dealerRestrictions;

	@Column(name = "X_EMAIL_ADDR")
	private String xEmailAddr;

	@Column(name = "C_ZONE")
	private String cZone;

	@Column(name = "X_DLR_ADDR_1")
	private String xDlrAddr1;

	public DealerDetail() {
	}

	public int getIDlrDtlSeq() {
		return this.iDlrDtlSeq;
	}

	public void setIDlrDtlSeq(int iDlrDtlSeq) {
		this.iDlrDtlSeq = iDlrDtlSeq;
	}

	public String getCDlr() {
		return this.cDlr;
	}

	public void setCDlr(String cDlr) {
		this.cDlr = cDlr;
	}

	public String getCDlrZip() {
		return this.cDlrZip;
	}

	public void setCDlrZip(String cDlrZip) {
		this.cDlrZip = cDlrZip;
	}

	public String getIDlrAltPh() {
		return this.iDlrAltPh;
	}

	public void setIDlrAltPh(String iDlrAltPh) {
		this.iDlrAltPh = iDlrAltPh;
	}

	public String getIDlrPrmryPh() {
		return this.iDlrPrmryPh;
	}

	public void setIDlrPrmryPh(String iDlrPrmryPh) {
		this.iDlrPrmryPh = iDlrPrmryPh;
	}

	public String getNDlr() {
		return this.nDlr;
	}

	public void setNDlr(String nDlr) {
		this.nDlr = nDlr;
	}

	public String getNDlrCity() {
		return this.nDlrCity;
	}

	public void setNDlrCity(String nDlrCity) {
		this.nDlrCity = nDlrCity;
	}

	public String getNDlrCntry() {
		return this.nDlrCntry;
	}

	public void setNDlrCntry(String nDlrCntry) {
		this.nDlrCntry = nDlrCntry;
	}

	public String getNDlrZone() {
		return this.nDlrZone;
	}

	public void setNDlrZone(String nDlrZone) {
		this.nDlrZone = nDlrZone;
	}

	public String getXDlrAddr() {
		return this.xDlrAddr;
	}

	public void setXDlrAddr(String xDlrAddr) {
		this.xDlrAddr = xDlrAddr;
	}

	public String getXDlrZone() {
		return this.xDlrZone;
	}

	public void setXDlrZone(String xDlrZone) {
		this.xDlrZone = xDlrZone;
	}

	public Set<DealerContact> getDealerContacts() {
		return dealerContacts;
	}

	public void setDealerContacts(Set<DealerContact> dealerContacts) {
		this.dealerContacts = dealerContacts;
	}

	public DealerContact addDealerContact(DealerContact dealerContact) {
		getDealerContacts().add(dealerContact);
		dealerContact.setDealerDetail(this);

		return dealerContact;
	}

	public DealerContact removeDealerContact(DealerContact dealerContact) {
		getDealerContacts().remove(dealerContact);
		dealerContact.setDealerDetail(null);

		return dealerContact;
	}

	public CodeMaster getDealerStateCode() {
		return dealerStateCode;
	}

	public void setDealerStateCode(CodeMaster dealerStateCode) {
		this.dealerStateCode = dealerStateCode;
	}

	public CodeMaster getDealerDistrictCode() {
		return dealerDistrictCode;
	}

	public void setDealerDistrictCode(CodeMaster dealerDistrictCode) {
		this.dealerDistrictCode = dealerDistrictCode;
	}

	public CodeMaster getBussinessCenterCode() {
		return bussinessCenterCode;
	}

	public void setBussinessCenterCode(CodeMaster bussinessCenterCode) {
		this.bussinessCenterCode = bussinessCenterCode;
	}

	public Set<DealerRestriction> getDealerRestrictions() {
		return dealerRestrictions;
	}

	public void setDealerRestrictions(Set<DealerRestriction> dealerRestrictions) {
		this.dealerRestrictions = dealerRestrictions;
	}

	public DealerRestriction addDealerRestriction(DealerRestriction dealerRestriction) {
		getDealerRestrictions().add(dealerRestriction);
		dealerRestriction.setDealerDetail(this);

		return dealerRestriction;
	}

	public DealerRestriction removeDealerRestriction(DealerRestriction dealerRestriction) {
		getDealerRestrictions().remove(dealerRestriction);
		dealerRestriction.setDealerDetail(null);

		return dealerRestriction;
	}

	public String getlAct() {
		return lAct;
	}

	public void setlAct(String lAct) {
		this.lAct = lAct;
	}

	public String getlFrnchz() {
		return lFrnchz;
	}

	public void setlFrnchz(String lFrnchz) {
		this.lFrnchz = lFrnchz;
	}

	public String getxEmailAddr() {
		return xEmailAddr;
	}

	public void setxEmailAddr(String xEmailAddr) {
		this.xEmailAddr = xEmailAddr;
	}

	public String getCZone() {
		return this.cZone;
	}

	public void setCZone(String cZone) {
		this.cZone = cZone;
	}

	public String getXDlrAddr1() {
		return this.xDlrAddr1;
	}

	public void setXDlrAddr1(String xDlrAddr1) {
		this.xDlrAddr1 = xDlrAddr1;
	}
}