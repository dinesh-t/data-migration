package com.chrysler.migration;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * 
 * @author STG
 *
 */
@SpringBootApplication
public class DataMigrationPocApplication {

	public static void main(String[] args) {
		SpringApplication.run(DataMigrationPocApplication.class, args);
	}
}
