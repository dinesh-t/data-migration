package com.chrysler.migration.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * The persistent class for the RPT_GRP_BY_HAVING database table.
 * 
 */
@Entity
@Table(name = "RPT_GRP_BY_HAVING")
@NamedQuery(name = "RptGrpByHaving.findAll", query = "SELECT r FROM RptGrpByHaving r")
public class RptGrpByHaving extends AuditColumns implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "I_RPT_GRP_BY_SEQ")
	private int iRptGrpBySeq;

	@Column(name = "L_BYBK")
	private String lBuyback;

	@Column(name = "I_OPTR")
	private String iOptr;

	@Column(name = "I_VAL")
	private String iVal;

	@Column(name = "L_RPT")
	private String lRpt;

	// bi-directional many-to-one association to RptMstr
	@ManyToOne
	@JoinColumn(name = "I_RPT")
	private RptMstr rptMstr;

	// bi-directional many-to-one association to ColumnMaster
	@ManyToOne
	@JoinColumn(name = "I_COLM")
	private ColumnMaster iColmCode;

	// bi-directional many-to-one association to ColumnMaster
	@ManyToOne
	@JoinColumn(name = "I_HAVING")
	private ColumnMaster iHavingCode;

	public ColumnMaster getiColmCode() {
		return iColmCode;
	}

	public void setiColmCode(ColumnMaster iColmCode) {
		this.iColmCode = iColmCode;
	}

	public ColumnMaster getiHavingCode() {
		return iHavingCode;
	}

	public void setiHavingCode(ColumnMaster iHavingCode) {
		this.iHavingCode = iHavingCode;
	}

	public RptGrpByHaving() {
	}

	public int getIRptGrpBySeq() {
		return this.iRptGrpBySeq;
	}

	public void setIRptGrpBySeq(int iRptGrpBySeq) {
		this.iRptGrpBySeq = iRptGrpBySeq;
	}

	public String getIOptr() {
		return this.iOptr;
	}

	public void setIOptr(String iOptr) {
		this.iOptr = iOptr;
	}

	public String getIVal() {
		return this.iVal;
	}

	public void setIVal(String iVal) {
		this.iVal = iVal;
	}

	public RptMstr getRptMstr() {
		return this.rptMstr;
	}

	public void setRptMstr(RptMstr rptMstr) {
		this.rptMstr = rptMstr;
	}

	public String getlBuyback() {
		return lBuyback;
	}

	public void setlBuyback(String lBuyback) {
		this.lBuyback = lBuyback;
	}

	public String getlRpt() {
		return lRpt;
	}

	public void setlRpt(String lRpt) {
		this.lRpt = lRpt;
	}

}