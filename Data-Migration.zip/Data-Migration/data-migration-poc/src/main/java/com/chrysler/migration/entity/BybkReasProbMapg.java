package com.chrysler.migration.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * The persistent class for the BYBK_REAS_PROB_MAPG database table.
 * 
 */
@Entity
@Table(name = "BYBK_REAS_PROB_MAPG")
@NamedQuery(name = "BybkReasProbMapg.findAll", query = "SELECT b FROM BybkReasProbMapg b")
public class BybkReasProbMapg extends AuditColumns implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "I_REAS_PROB_SEQ")
	private Integer iReasProbSeq;

	@Column(name = "X_PROB_DESC")
	private String xProbDesc;

	@Column(name = "I_ORDR")
	private Integer iOrdr;

	// bi-directional many-to-one association to Buyback
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_BYBK")
	private Buyback buyback;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_PROB_PRMRY_CATGY")
	private CodeMaster primaryProblemCategory;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_PROB_CATGY")
	private CodeMaster problem;

	public BybkReasProbMapg() {
		// Default Constructor
	}

	public Integer getIReasProbSeq() {
		return this.iReasProbSeq;
	}

	public void setIReasProbSeq(Integer iReasProbSeq) {
		this.iReasProbSeq = iReasProbSeq;
	}

	public String getXProbDesc() {
		return this.xProbDesc;
	}

	public void setXProbDesc(String xProbDesc) {
		this.xProbDesc = xProbDesc;
	}

	public Buyback getBuyback() {
		return this.buyback;
	}

	public void setBuyback(Buyback buyback) {
		this.buyback = buyback;
	}

	public CodeMaster getPrimaryProblemCategory() {
		return primaryProblemCategory;
	}

	public void setPrimaryProblemCategory(CodeMaster primaryProblemCategory) {
		this.primaryProblemCategory = primaryProblemCategory;
	}

	public CodeMaster getProblem() {
		return problem;
	}

	public void setProblem(CodeMaster problem) {
		this.problem = problem;
	}

	public Integer getiOrdr() {
		return iOrdr;
	}

	public void setiOrdr(Integer iOrdr) {
		this.iOrdr = iOrdr;
	}

}