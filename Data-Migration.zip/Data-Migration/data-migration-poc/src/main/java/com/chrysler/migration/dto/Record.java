package com.chrysler.migration.dto;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import org.eclipse.persistence.oxm.annotations.XmlPath;

@XmlRootElement(name = "record")
@XmlAccessorType(XmlAccessType.FIELD)
public class Record {

	
	@XmlPath("field[@name='doccreated']")
	private Field docCreated;
	@XmlPath("field[@name='docmodified']")
	private Field docModified;	
	@XmlPath("field[@name='ModifiedBy']")
	private FieldArray modifiedBy;
	@XmlPath("field[@name='noteid']")
	private Field noteId;
	@XmlPath("field[@name='unid']")
	private Field unId;
	@XmlPath("field[@name='parentnoteid']")
	private Field parentNoteId;
	@XmlPath("field[@name='parentunid']")
	private Field parentUnId;
	@XmlPath("field[@name='AftermarketAccessories']")
	private Field aftermarketAccessories;
	@XmlPath("field[@name='AribrationDecision']")
	private Field aribrationDecision;
	@XmlPath("field[@name='AttorneyFees']")
	private Field attorneyFees;
	@XmlPath("field[@name='AttorneyFeesNegotiated']")
	private Field attorneyFeesNegotiated;
	@XmlPath("field[@name='AttorneyName']")
	private Field attorneyName;
	@XmlPath("field[@name='AttorneyPhone']")
	private Field attorneyPhone;
	@XmlPath("field[@name='BusinessCenterID']")
	private Field businessCenterID;
	@XmlPath("field[@name='BusinessCenterIDList']")
	private FieldArray businessCenterIDList;
	@XmlPath("field[@name='BusinessCenterNamesList']")
	private FieldArray businessCenterNamesList;
	@XmlPath("field[@name='BusinessCenterRole']")
	private Field businessCenterRole;
	@XmlPath("field[@name='BuybackDamage']")
	private Field buybackDamage;
	@XmlPath("field[@name='BuybackDamageDescription']")
	private Field buybackDamageDescription;
	@XmlPath("field[@name='BuybackDamageResponsible']")
	private Field buybackDamageResponsible;
	@XmlPath("field[@name='BuybackDamageResponsibleWhyNot']")
	private Field buybackDamageResponsibleWhyNot;
	@XmlPath("field[@name='BuybackReasonCategoryAdditional']")
	private FieldArray buybackReasonCategoryAdditional;
	@XmlPath("field[@name='BuybackReasonCategoryInput']")
	private Field buybackReasonCategoryInput;
	@XmlPath("field[@name='BuybackReasonCategoryPrimary']")
	private Field buybackReasonCategoryPrimary;
	@XmlPath("field[@name='BuybackReasonCodeAdditional']")
	private FieldArray buybackReasonCodeAdditional;
	@XmlPath("field[@name='BuybackReasonCodeAdditionalInput']")
	private Field buybackReasonCodeAdditionalInput;
	@XmlPath("field[@name='BuybackReasonCodeDescriptionPrim']")
	private Field buybackReasonCodeDescriptionPrim;
	@XmlPath("field[@name='BuybackReasonCodeOtherList']")
	private FieldArray buybackReasonCodeOtherList;
	@XmlPath("field[@name='BuybackReasonCodePrimary']")
	private Field buybackReasonCodePrimary;
	@XmlPath("field[@name='BuybackReasonDescriptionAdd']")
	private FieldArray buybackReasonDescriptionAdd;
	@XmlPath("field[@name='BuybackReasonDescriptionAddInput']")
	private Field buybackReasonDescriptionAddInput;
	@XmlPath("field[@name='BuybackReasonRepaired']")
	private Field buybackReasonRepaired;
	@XmlPath("field[@name='BuybackReasonRepairedDescription']")
	private Field buybackReasonRepairedDescription;
	@XmlPath("field[@name='BuyBackType']")
	private Field buyBackType;
	@XmlPath("field[@name='CAIR_Number']")
	private Field CAIR_Number;
	@XmlPath("field[@name='CaseLog']")
	private FieldArray caseLog;
	@XmlPath("field[@name='ComplianceDueDate']")
	private Field complianceDueDate;
	@XmlPath("field[@name='computeRespDealerCode']")
	private Field computeRespDealerCode;
	@XmlPath("field[@name='ContactPreference']")
	private Field contactPreference;
	@XmlPath("field[@name='Creator']")
	private Field creator;
	@XmlPath("field[@name='CurrentMileage']")
	private Field currentMileage;
	@XmlPath("field[@name='CustomerDescriptionOfProblem']")
	private Field customerDescriptionOfProblem;
	@XmlPath("field[@name='CustomerHasAttorney']")
	private Field customerHasAttorney;
	@XmlPath("field[@name='CustomerLastName']")
	private Field customerLastName;
	@XmlPath("field[@name='CustomerseMailAddress']")
	private Field customerseMailAddress;
	@XmlPath("field[@name='DealerCausedBuybackYN']")
	private Field dealerCausedBuybackYN;
	@XmlPath("field[@name='DealerCode']")
	private Field dealerCode;
	@XmlPath("field[@name='DealerContactName']")
	private Field dealerContactName;
	@XmlPath("field[@name='DealerPhone']")
	private Field dealerPhone;
	@XmlPath("field[@name='DecisionMaker']")
	private Field decisionMaker;
	@XmlPath("field[@name='DecisionMakerPhone']")
	private Field decisionMakerPhone;
	@XmlPath("field[@name='District']")
	private Field district;
	@XmlPath("field[@name='DocMode']")
	private Field docMode;
	@XmlPath("field[@name='dspResponsibleDealerCode']")
	private Field dspResponsibleDealerCode;
	@XmlPath("field[@name='FlatUsageFee']")
	private Field flatUsageFee;
	@XmlPath("field[@name='ISG_MileageOffset']")
	private Field ISG_MileageOffset;
	@XmlPath("field[@name='MileageOffset_Denominator']")
	private Field mileageOffsetDenominator;
	@XmlPath("field[@name='MileageOffset_NumberOfMiles']")
	private Field mileageOffsetNumberOfMiles;
	@XmlPath("field[@name='MileageOffset_PurchasePrice']")
	private Field mileageOffsetPurchasePrice;
	@XmlPath("field[@name='MileageOffset_UsageFee']")
	private Field mileageOffsetUsageFee;
	@XmlPath("field[@name='Offsett_FlatUsageFee']")
	private FieldArray offsettFlatUsageFee;
	@XmlPath("field[@name='Offsett_MileageOffset']")
	private FieldArray offsettMileageOffset;
	@XmlPath("field[@name='Offsett_PurchasePrice']")
	private FieldArray offsettPurchasePrice;
	@XmlPath("field[@name='Offsett_StraightMileage']")
	private FieldArray offsettStraightMileage;
	@XmlPath("field[@name='Phone1']")
	private Field phone1;
	@XmlPath("field[@name='Phone2']")
	private Field phone2;
	@XmlPath("field[@name='Phone3']")
	private Field phone3;
	@XmlPath("field[@name='PhoneExt1']")
	private Field phoneExt1;
	@XmlPath("field[@name='PhoneExt2']")
	private Field phoneExt2;
	@XmlPath("field[@name='PhoneExt3']")
	private Field phoneExt3;
	@XmlPath("field[@name='PurchasePrice_Demoninator']")
	private Field purchasePriceDemoninator;
	@XmlPath("field[@name='PurchasePrice_NumberOfMiles']")
	private Field purchasePriceNumberOfMiles;
	@XmlPath("field[@name='PurchasePrice_PurchasePrice']")
	private Field purchasePricePurchasePrice;
	@XmlPath("field[@name='PurchasePrice_UsageFee']")
	private Field purchasePriceUsageFee;
	@XmlPath("field[@name='PushedToREAQ']")
	private Field pushedToREAQ;
	@XmlPath("field[@name='RentalProvided']")
	private Field rentalProvided;
	@XmlPath("field[@name='RentalProvidedDate']")
	private Field rentalProvidedDate;
	@XmlPath("field[@name='RepairingDealer']")
	private Field repairingDealer;
	@XmlPath("field[@name='RepairOrderNumber']")
	private Field repairOrderNumber;
	@XmlPath("field[@name='ResponsibleDealerCode']")
	private Field responsibleDealerCode;
	@XmlPath("field[@name='ServiceDealerContactName']")
	private Field serviceDealerContactName;
	@XmlPath("field[@name='ServiceDealerPhone']")
	private Field serviceDealerPhone;
	@XmlPath("field[@name='StateArbitration']")
	private Field stateArbitration;
	@XmlPath("field[@name='StraightMileage_CostPerMile']")
	private Field straightMileage_CostPerMile;
	@XmlPath("field[@name='StraightMileage_NumberOfMiles']")
	private Field straightMileage_NumberOfMiles;
	@XmlPath("field[@name='StraightMileage_UsageFee']")
	private Field straightMileage_UsageFee;
	@XmlPath("field[@name='TotalOffset']")
	private Field totalOffset;
	@XmlPath("field[@name='VehicleAtDealership']")
	private Field vehicleAtDealership;
	@XmlPath("field[@name='VIN']")
	private Field VIN;
	public Field getDocCreated() {
		return docCreated;
	}
	public void setDocCreated(Field docCreated) {
		this.docCreated = docCreated;
	}
	public Field getDocModified() {
		return docModified;
	}
	public void setDocModified(Field docModified) {
		this.docModified = docModified;
	}
	public FieldArray getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(FieldArray modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public Field getNoteId() {
		return noteId;
	}
	public void setNoteId(Field noteId) {
		this.noteId = noteId;
	}
	public Field getUnId() {
		return unId;
	}
	public void setUnId(Field unId) {
		this.unId = unId;
	}
	public Field getParentNoteId() {
		return parentNoteId;
	}
	public void setParentNoteId(Field parentNoteId) {
		this.parentNoteId = parentNoteId;
	}
	public Field getParentUnId() {
		return parentUnId;
	}
	public void setParentUnId(Field parentUnId) {
		this.parentUnId = parentUnId;
	}
	public Field getAftermarketAccessories() {
		return aftermarketAccessories;
	}
	public void setAftermarketAccessories(Field aftermarketAccessories) {
		this.aftermarketAccessories = aftermarketAccessories;
	}
	public Field getAribrationDecision() {
		return aribrationDecision;
	}
	public void setAribrationDecision(Field aribrationDecision) {
		this.aribrationDecision = aribrationDecision;
	}
	public Field getAttorneyFees() {
		return attorneyFees;
	}
	public void setAttorneyFees(Field attorneyFees) {
		this.attorneyFees = attorneyFees;
	}
	public Field getAttorneyFeesNegotiated() {
		return attorneyFeesNegotiated;
	}
	public void setAttorneyFeesNegotiated(Field attorneyFeesNegotiated) {
		this.attorneyFeesNegotiated = attorneyFeesNegotiated;
	}
	public Field getAttorneyName() {
		return attorneyName;
	}
	public void setAttorneyName(Field attorneyName) {
		this.attorneyName = attorneyName;
	}
	public Field getAttorneyPhone() {
		return attorneyPhone;
	}
	public void setAttorneyPhone(Field attorneyPhone) {
		this.attorneyPhone = attorneyPhone;
	}
	public Field getBusinessCenterID() {
		return businessCenterID;
	}
	public void setBusinessCenterID(Field businessCenterID) {
		this.businessCenterID = businessCenterID;
	}
	public FieldArray getBusinessCenterIDList() {
		return businessCenterIDList;
	}
	public void setBusinessCenterIDList(FieldArray businessCenterIDList) {
		this.businessCenterIDList = businessCenterIDList;
	}
	public FieldArray getBusinessCenterNamesList() {
		return businessCenterNamesList;
	}
	public void setBusinessCenterNamesList(FieldArray businessCenterNamesList) {
		this.businessCenterNamesList = businessCenterNamesList;
	}
	public Field getBusinessCenterRole() {
		return businessCenterRole;
	}
	public void setBusinessCenterRole(Field businessCenterRole) {
		this.businessCenterRole = businessCenterRole;
	}
	public Field getBuybackDamage() {
		return buybackDamage;
	}
	public void setBuybackDamage(Field buybackDamage) {
		this.buybackDamage = buybackDamage;
	}
	public Field getBuybackDamageDescription() {
		return buybackDamageDescription;
	}
	public void setBuybackDamageDescription(Field buybackDamageDescription) {
		this.buybackDamageDescription = buybackDamageDescription;
	}
	public Field getBuybackDamageResponsible() {
		return buybackDamageResponsible;
	}
	public void setBuybackDamageResponsible(Field buybackDamageResponsible) {
		this.buybackDamageResponsible = buybackDamageResponsible;
	}
	public Field getBuybackDamageResponsibleWhyNot() {
		return buybackDamageResponsibleWhyNot;
	}
	public void setBuybackDamageResponsibleWhyNot(Field buybackDamageResponsibleWhyNot) {
		this.buybackDamageResponsibleWhyNot = buybackDamageResponsibleWhyNot;
	}
	public FieldArray getBuybackReasonCategoryAdditional() {
		return buybackReasonCategoryAdditional;
	}
	public void setBuybackReasonCategoryAdditional(FieldArray buybackReasonCategoryAdditional) {
		this.buybackReasonCategoryAdditional = buybackReasonCategoryAdditional;
	}
	public Field getBuybackReasonCategoryInput() {
		return buybackReasonCategoryInput;
	}
	public void setBuybackReasonCategoryInput(Field buybackReasonCategoryInput) {
		this.buybackReasonCategoryInput = buybackReasonCategoryInput;
	}
	public Field getBuybackReasonCategoryPrimary() {
		return buybackReasonCategoryPrimary;
	}
	public void setBuybackReasonCategoryPrimary(Field buybackReasonCategoryPrimary) {
		this.buybackReasonCategoryPrimary = buybackReasonCategoryPrimary;
	}
	public FieldArray getBuybackReasonCodeAdditional() {
		return buybackReasonCodeAdditional;
	}
	public void setBuybackReasonCodeAdditional(FieldArray buybackReasonCodeAdditional) {
		this.buybackReasonCodeAdditional = buybackReasonCodeAdditional;
	}
	public Field getBuybackReasonCodeAdditionalInput() {
		return buybackReasonCodeAdditionalInput;
	}
	public void setBuybackReasonCodeAdditionalInput(Field buybackReasonCodeAdditionalInput) {
		this.buybackReasonCodeAdditionalInput = buybackReasonCodeAdditionalInput;
	}
	public Field getBuybackReasonCodeDescriptionPrim() {
		return buybackReasonCodeDescriptionPrim;
	}
	public void setBuybackReasonCodeDescriptionPrim(Field buybackReasonCodeDescriptionPrim) {
		this.buybackReasonCodeDescriptionPrim = buybackReasonCodeDescriptionPrim;
	}
	public FieldArray getBuybackReasonCodeOtherList() {
		return buybackReasonCodeOtherList;
	}
	public void setBuybackReasonCodeOtherList(FieldArray buybackReasonCodeOtherList) {
		this.buybackReasonCodeOtherList = buybackReasonCodeOtherList;
	}
	public Field getBuybackReasonCodePrimary() {
		return buybackReasonCodePrimary;
	}
	public void setBuybackReasonCodePrimary(Field buybackReasonCodePrimary) {
		this.buybackReasonCodePrimary = buybackReasonCodePrimary;
	}
	public FieldArray getBuybackReasonDescriptionAdd() {
		return buybackReasonDescriptionAdd;
	}
	public void setBuybackReasonDescriptionAdd(FieldArray buybackReasonDescriptionAdd) {
		this.buybackReasonDescriptionAdd = buybackReasonDescriptionAdd;
	}
	public Field getBuybackReasonDescriptionAddInput() {
		return buybackReasonDescriptionAddInput;
	}
	public void setBuybackReasonDescriptionAddInput(Field buybackReasonDescriptionAddInput) {
		this.buybackReasonDescriptionAddInput = buybackReasonDescriptionAddInput;
	}
	public Field getBuybackReasonRepaired() {
		return buybackReasonRepaired;
	}
	public void setBuybackReasonRepaired(Field buybackReasonRepaired) {
		this.buybackReasonRepaired = buybackReasonRepaired;
	}
	public Field getBuybackReasonRepairedDescription() {
		return buybackReasonRepairedDescription;
	}
	public void setBuybackReasonRepairedDescription(Field buybackReasonRepairedDescription) {
		this.buybackReasonRepairedDescription = buybackReasonRepairedDescription;
	}
	public Field getBuyBackType() {
		return buyBackType;
	}
	public void setBuyBackType(Field buyBackType) {
		this.buyBackType = buyBackType;
	}
	public Field getCAIR_Number() {
		return CAIR_Number;
	}
	public void setCAIR_Number(Field cAIR_Number) {
		CAIR_Number = cAIR_Number;
	}
	public FieldArray getCaseLog() {
		return caseLog;
	}
	public void setCaseLog(FieldArray caseLog) {
		this.caseLog = caseLog;
	}
	public Field getComplianceDueDate() {
		return complianceDueDate;
	}
	public void setComplianceDueDate(Field complianceDueDate) {
		this.complianceDueDate = complianceDueDate;
	}
	public Field getComputeRespDealerCode() {
		return computeRespDealerCode;
	}
	public void setComputeRespDealerCode(Field computeRespDealerCode) {
		this.computeRespDealerCode = computeRespDealerCode;
	}
	public Field getContactPreference() {
		return contactPreference;
	}
	public void setContactPreference(Field contactPreference) {
		this.contactPreference = contactPreference;
	}
	public Field getCreator() {
		return creator;
	}
	public void setCreator(Field creator) {
		this.creator = creator;
	}
	public Field getCurrentMileage() {
		return currentMileage;
	}
	public void setCurrentMileage(Field currentMileage) {
		this.currentMileage = currentMileage;
	}
	public Field getCustomerDescriptionOfProblem() {
		return customerDescriptionOfProblem;
	}
	public void setCustomerDescriptionOfProblem(Field customerDescriptionOfProblem) {
		this.customerDescriptionOfProblem = customerDescriptionOfProblem;
	}
	public Field getCustomerHasAttorney() {
		return customerHasAttorney;
	}
	public void setCustomerHasAttorney(Field customerHasAttorney) {
		this.customerHasAttorney = customerHasAttorney;
	}
	public Field getCustomerLastName() {
		return customerLastName;
	}
	public void setCustomerLastName(Field customerLastName) {
		this.customerLastName = customerLastName;
	}
	public Field getCustomerseMailAddress() {
		return customerseMailAddress;
	}
	public void setCustomerseMailAddress(Field customerseMailAddress) {
		this.customerseMailAddress = customerseMailAddress;
	}
	public Field getDealerCausedBuybackYN() {
		return dealerCausedBuybackYN;
	}
	public void setDealerCausedBuybackYN(Field dealerCausedBuybackYN) {
		this.dealerCausedBuybackYN = dealerCausedBuybackYN;
	}
	public Field getDealerCode() {
		return dealerCode;
	}
	public void setDealerCode(Field dealerCode) {
		this.dealerCode = dealerCode;
	}
	public Field getDealerContactName() {
		return dealerContactName;
	}
	public void setDealerContactName(Field dealerContactName) {
		this.dealerContactName = dealerContactName;
	}
	public Field getDealerPhone() {
		return dealerPhone;
	}
	public void setDealerPhone(Field dealerPhone) {
		this.dealerPhone = dealerPhone;
	}
	public Field getDecisionMaker() {
		return decisionMaker;
	}
	public void setDecisionMaker(Field decisionMaker) {
		this.decisionMaker = decisionMaker;
	}
	public Field getDecisionMakerPhone() {
		return decisionMakerPhone;
	}
	public void setDecisionMakerPhone(Field decisionMakerPhone) {
		this.decisionMakerPhone = decisionMakerPhone;
	}
	public Field getDistrict() {
		return district;
	}
	public void setDistrict(Field district) {
		this.district = district;
	}
	public Field getDocMode() {
		return docMode;
	}
	public void setDocMode(Field docMode) {
		this.docMode = docMode;
	}
	public Field getDspResponsibleDealerCode() {
		return dspResponsibleDealerCode;
	}
	public void setDspResponsibleDealerCode(Field dspResponsibleDealerCode) {
		this.dspResponsibleDealerCode = dspResponsibleDealerCode;
	}
	public Field getFlatUsageFee() {
		return flatUsageFee;
	}
	public void setFlatUsageFee(Field flatUsageFee) {
		this.flatUsageFee = flatUsageFee;
	}
	public Field getISG_MileageOffset() {
		return ISG_MileageOffset;
	}
	public void setISG_MileageOffset(Field iSG_MileageOffset) {
		ISG_MileageOffset = iSG_MileageOffset;
	}
	public Field getMileageOffsetDenominator() {
		return mileageOffsetDenominator;
	}
	public void setMileageOffsetDenominator(Field mileageOffsetDenominator) {
		this.mileageOffsetDenominator = mileageOffsetDenominator;
	}
	public Field getMileageOffsetNumberOfMiles() {
		return mileageOffsetNumberOfMiles;
	}
	public void setMileageOffsetNumberOfMiles(Field mileageOffsetNumberOfMiles) {
		this.mileageOffsetNumberOfMiles = mileageOffsetNumberOfMiles;
	}
	public Field getMileageOffsetPurchasePrice() {
		return mileageOffsetPurchasePrice;
	}
	public void setMileageOffsetPurchasePrice(Field mileageOffsetPurchasePrice) {
		this.mileageOffsetPurchasePrice = mileageOffsetPurchasePrice;
	}
	public Field getMileageOffsetUsageFee() {
		return mileageOffsetUsageFee;
	}
	public void setMileageOffsetUsageFee(Field mileageOffsetUsageFee) {
		this.mileageOffsetUsageFee = mileageOffsetUsageFee;
	}
	public FieldArray getOffsettFlatUsageFee() {
		return offsettFlatUsageFee;
	}
	public void setOffsettFlatUsageFee(FieldArray offsettFlatUsageFee) {
		this.offsettFlatUsageFee = offsettFlatUsageFee;
	}
	public FieldArray getOffsettMileageOffset() {
		return offsettMileageOffset;
	}
	public void setOffsettMileageOffset(FieldArray offsettMileageOffset) {
		this.offsettMileageOffset = offsettMileageOffset;
	}
	public FieldArray getOffsettPurchasePrice() {
		return offsettPurchasePrice;
	}
	public void setOffsettPurchasePrice(FieldArray offsettPurchasePrice) {
		this.offsettPurchasePrice = offsettPurchasePrice;
	}
	public FieldArray getOffsettStraightMileage() {
		return offsettStraightMileage;
	}
	public void setOffsettStraightMileage(FieldArray offsettStraightMileage) {
		this.offsettStraightMileage = offsettStraightMileage;
	}
	public Field getPhone1() {
		return phone1;
	}
	public void setPhone1(Field phone1) {
		this.phone1 = phone1;
	}
	public Field getPhone2() {
		return phone2;
	}
	public void setPhone2(Field phone2) {
		this.phone2 = phone2;
	}
	public Field getPhone3() {
		return phone3;
	}
	public void setPhone3(Field phone3) {
		this.phone3 = phone3;
	}
	public Field getPhoneExt1() {
		return phoneExt1;
	}
	public void setPhoneExt1(Field phoneExt1) {
		this.phoneExt1 = phoneExt1;
	}
	public Field getPhoneExt2() {
		return phoneExt2;
	}
	public void setPhoneExt2(Field phoneExt2) {
		this.phoneExt2 = phoneExt2;
	}
	public Field getPhoneExt3() {
		return phoneExt3;
	}
	public void setPhoneExt3(Field phoneExt3) {
		this.phoneExt3 = phoneExt3;
	}
	public Field getPurchasePriceDemoninator() {
		return purchasePriceDemoninator;
	}
	public void setPurchasePriceDemoninator(Field purchasePriceDemoninator) {
		this.purchasePriceDemoninator = purchasePriceDemoninator;
	}
	public Field getPurchasePriceNumberOfMiles() {
		return purchasePriceNumberOfMiles;
	}
	public void setPurchasePriceNumberOfMiles(Field purchasePriceNumberOfMiles) {
		this.purchasePriceNumberOfMiles = purchasePriceNumberOfMiles;
	}
	public Field getPurchasePricePurchasePrice() {
		return purchasePricePurchasePrice;
	}
	public void setPurchasePricePurchasePrice(Field purchasePricePurchasePrice) {
		this.purchasePricePurchasePrice = purchasePricePurchasePrice;
	}
	public Field getPurchasePriceUsageFee() {
		return purchasePriceUsageFee;
	}
	public void setPurchasePriceUsageFee(Field purchasePriceUsageFee) {
		this.purchasePriceUsageFee = purchasePriceUsageFee;
	}
	public Field getPushedToREAQ() {
		return pushedToREAQ;
	}
	public void setPushedToREAQ(Field pushedToREAQ) {
		this.pushedToREAQ = pushedToREAQ;
	}
	public Field getRentalProvided() {
		return rentalProvided;
	}
	public void setRentalProvided(Field rentalProvided) {
		this.rentalProvided = rentalProvided;
	}
	public Field getRentalProvidedDate() {
		return rentalProvidedDate;
	}
	public void setRentalProvidedDate(Field rentalProvidedDate) {
		this.rentalProvidedDate = rentalProvidedDate;
	}
	public Field getRepairingDealer() {
		return repairingDealer;
	}
	public void setRepairingDealer(Field repairingDealer) {
		this.repairingDealer = repairingDealer;
	}
	public Field getRepairOrderNumber() {
		return repairOrderNumber;
	}
	public void setRepairOrderNumber(Field repairOrderNumber) {
		this.repairOrderNumber = repairOrderNumber;
	}
	public Field getResponsibleDealerCode() {
		return responsibleDealerCode;
	}
	public void setResponsibleDealerCode(Field responsibleDealerCode) {
		this.responsibleDealerCode = responsibleDealerCode;
	}
	public Field getServiceDealerContactName() {
		return serviceDealerContactName;
	}
	public void setServiceDealerContactName(Field serviceDealerContactName) {
		this.serviceDealerContactName = serviceDealerContactName;
	}
	public Field getServiceDealerPhone() {
		return serviceDealerPhone;
	}
	public void setServiceDealerPhone(Field serviceDealerPhone) {
		this.serviceDealerPhone = serviceDealerPhone;
	}
	public Field getStateArbitration() {
		return stateArbitration;
	}
	public void setStateArbitration(Field stateArbitration) {
		this.stateArbitration = stateArbitration;
	}
	public Field getStraightMileage_CostPerMile() {
		return straightMileage_CostPerMile;
	}
	public void setStraightMileage_CostPerMile(Field straightMileage_CostPerMile) {
		this.straightMileage_CostPerMile = straightMileage_CostPerMile;
	}
	public Field getStraightMileage_NumberOfMiles() {
		return straightMileage_NumberOfMiles;
	}
	public void setStraightMileage_NumberOfMiles(Field straightMileage_NumberOfMiles) {
		this.straightMileage_NumberOfMiles = straightMileage_NumberOfMiles;
	}
	public Field getStraightMileage_UsageFee() {
		return straightMileage_UsageFee;
	}
	public void setStraightMileage_UsageFee(Field straightMileage_UsageFee) {
		this.straightMileage_UsageFee = straightMileage_UsageFee;
	}
	public Field getTotalOffset() {
		return totalOffset;
	}
	public void setTotalOffset(Field totalOffset) {
		this.totalOffset = totalOffset;
	}
	public Field getVehicleAtDealership() {
		return vehicleAtDealership;
	}
	public void setVehicleAtDealership(Field vehicleAtDealership) {
		this.vehicleAtDealership = vehicleAtDealership;
	}
	public Field getVIN() {
		return VIN;
	}
	public void setVIN(Field vIN) {
		VIN = vIN;
	}
	
	
	
	

}
