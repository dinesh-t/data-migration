package com.chrysler.migration.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * The persistent class for the CHECK_HISTORY database table.
 * 
 */
@Entity
@Table(name = "CHECK_HISTORY")
@NamedQuery(name = "CheckHistory.findAll", query = "SELECT c FROM CheckHistory c")
public class CheckHistory extends AuditColumns implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "I_CHECK_HIST_SEQ")
	private Integer iCheckHistSeq;

	@Column(name = "A_CHECK")
	private BigDecimal aCheck;

	@Column(name = "A_REQ_CHEQUE")
	private BigDecimal aReqCheque;

	@Column(name = "A_REQ_DISCT")
	private BigDecimal aReqDisct;

	@Column(name = "A_REQ_DSTRBN")
	private BigDecimal aReqDstrbn;

	@Column(name = "C_REQ_PAYE_ZIP")
	private String cReqPayeZip;

	@Column(name = "C_SEN_COMP")
	private String cSenComp;

	@Temporal(TemporalType.DATE)
	@Column(name = "D_CHECK")
	private Date dCheck;

	@Temporal(TemporalType.DATE)
	@Column(name = "D_CHECK_CAIR")
	private Date dCheckCair;

	@Temporal(TemporalType.DATE)
	@Column(name = "D_INVC")
	private Date dInvc;

	@Temporal(TemporalType.DATE)
	@Column(name = "D_REQ_INVC")
	private Date dReqInvc;

	@Temporal(TemporalType.DATE)
	@Column(name = "D_REQ_PAYMT_DUE")
	private Date dReqPaymtDue;

	@Column(name = "D_REQ_VOID")
	private Timestamp dReqVoid;

	@Temporal(TemporalType.DATE)
	@Column(name = "D_VOID")
	private Date dVoid;

	@Column(name = "I_CHECK")
	private String iCheck;

	@Column(name = "I_CHECK_CAIR")
	private String iCheckCair;

	@Column(name = "I_INVC")
	private String iInvc;

	@Column(name = "I_PAYMT_CURNCY")
	private String iPaymtCurncy;

	@Column(name = "I_REQ_INVC")
	private String iReqInvc;

	@Column(name = "I_REQ_SEQ")
	private Integer iReqSeq;

	@Column(name = "L_CHECK_SRCE")
	private String lCheckSrce;

	@Column(name = "L_PAYMT_METHD")
	private String lPaymtMethd;

	@Column(name = "L_REQ_VOID")
	private String lReqVoid;

	@Column(name = "L_VOID")
	private String lVoid;

	@Column(name = "N_HSE_BANK")
	private String nHseBank;

	@Column(name = "N_REQ_PAYE_CITY")
	private String nReqPayeCity;

	@Column(name = "N_REQ_PAYE_CNTRY")
	private String nReqPayeCntry;

	@Column(name = "N_VNDR")
	private String nVndr;

	@Column(name = "N_VNDR_CITY")
	private String nVndrCity;

	@Column(name = "N_VOID_BY")
	private String nVoidBy;

	@Column(name = "T_REQ_SENT")
	private Timestamp tReqSent;

	@Column(name = "T_RESPS_RECVD_DATE")
	private Timestamp tRespsRecvdDate;

	@Column(name = "X_REAS")
	private String xReas;

	@Column(name = "X_REQ_1099_DATA")
	private String xReq1099Data;

	@Column(name = "X_REQ_PAYE_ADDR1")
	private String xReqPayeAddr1;

	@Column(name = "X_REQ_PAYE_ADDR2")
	private String xReqPayeAddr2;

	@Column(name = "X_REQ_PAYE_LINE1")
	private String xReqPayeLine1;

	@Column(name = "X_REQ_PAYE_LINE2")
	private String xReqPayeLine2;

	@Column(name = "X_REQ_PAYE_LINE3")
	private String xReqPayeLine3;

	@Column(name = "X_REQ_REMIT_ADVCE1")
	private String xReqRemitAdvce1;

	@Column(name = "X_REQ_REMIT_ADVCE2")
	private String xReqRemitAdvce2;

	@Column(name = "X_COMNT")
	private String xComnt;

	@Column(name = "C_PAYE")
	private String cPaye;

	@Column(name = "I_VNDR")
	private String iVndr;

	// bi-directional many-to-one association to Check
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_CHECK_REF")
	private Check check;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "L_SCHD")
	private CodeMaster scheduleFlag;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_REQ_PAYE_STATE")
	private CodeMaster payeeState;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_VNDR_STATE")
	private CodeMaster vendorState;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_CHECK_STAT")
	private CodeMaster checkStatus;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_APRVL_STAT")
	private CodeMaster approvalStatus;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_CHECK_TYP")
	private CodeMaster checkType;

	public CheckHistory() {
	}

	public Integer getICheckHistSeq() {
		return this.iCheckHistSeq;
	}

	public void setICheckHistSeq(Integer iCheckHistSeq) {
		this.iCheckHistSeq = iCheckHistSeq;
	}

	public BigDecimal getACheck() {
		return this.aCheck;
	}

	public void setACheck(BigDecimal aCheck) {
		this.aCheck = aCheck;
	}

	public BigDecimal getAReqCheque() {
		return this.aReqCheque;
	}

	public void setAReqCheque(BigDecimal aReqCheque) {
		this.aReqCheque = aReqCheque;
	}

	public BigDecimal getAReqDisct() {
		return this.aReqDisct;
	}

	public void setAReqDisct(BigDecimal aReqDisct) {
		this.aReqDisct = aReqDisct;
	}

	public BigDecimal getAReqDstrbn() {
		return this.aReqDstrbn;
	}

	public void setAReqDstrbn(BigDecimal aReqDstrbn) {
		this.aReqDstrbn = aReqDstrbn;
	}

	public String getCReqPayeZip() {
		return this.cReqPayeZip;
	}

	public void setCReqPayeZip(String cReqPayeZip) {
		this.cReqPayeZip = cReqPayeZip;
	}

	public String getCSenComp() {
		return this.cSenComp;
	}

	public void setCSenComp(String cSenComp) {
		this.cSenComp = cSenComp;
	}

	public Date getDCheck() {
		return this.dCheck;
	}

	public void setDCheck(Date dCheck) {
		this.dCheck = dCheck;
	}

	public Date getDCheckCair() {
		return this.dCheckCair;
	}

	public void setDCheckCair(Date dCheckCair) {
		this.dCheckCair = dCheckCair;
	}

	public Date getDInvc() {
		return this.dInvc;
	}

	public void setDInvc(Date dInvc) {
		this.dInvc = dInvc;
	}

	public Date getDReqInvc() {
		return this.dReqInvc;
	}

	public void setDReqInvc(Date dReqInvc) {
		this.dReqInvc = dReqInvc;
	}

	public Date getDReqPaymtDue() {
		return this.dReqPaymtDue;
	}

	public void setDReqPaymtDue(Date dReqPaymtDue) {
		this.dReqPaymtDue = dReqPaymtDue;
	}

	public Timestamp getDReqVoid() {
		return this.dReqVoid;
	}

	public void setDReqVoid(Timestamp dReqVoid) {
		this.dReqVoid = dReqVoid;
	}

	public Date getDVoid() {
		return this.dVoid;
	}

	public void setDVoid(Date dVoid) {
		this.dVoid = dVoid;
	}

	public String getICheck() {
		return this.iCheck;
	}

	public void setICheck(String iCheck) {
		this.iCheck = iCheck;
	}

	public String getICheckCair() {
		return this.iCheckCair;
	}

	public void setICheckCair(String iCheckCair) {
		this.iCheckCair = iCheckCair;
	}

	public String getIInvc() {
		return this.iInvc;
	}

	public void setIInvc(String iInvc) {
		this.iInvc = iInvc;
	}

	public String getIPaymtCurncy() {
		return this.iPaymtCurncy;
	}

	public void setIPaymtCurncy(String iPaymtCurncy) {
		this.iPaymtCurncy = iPaymtCurncy;
	}

	public String getIReqInvc() {
		return this.iReqInvc;
	}

	public void setIReqInvc(String iReqInvc) {
		this.iReqInvc = iReqInvc;
	}

	public Integer getIReqSeq() {
		return this.iReqSeq;
	}

	public void setIReqSeq(Integer iReqSeq) {
		this.iReqSeq = iReqSeq;
	}

	public String getLCheckSrce() {
		return this.lCheckSrce;
	}

	public void setLCheckSrce(String lCheckSrce) {
		this.lCheckSrce = lCheckSrce;
	}

	public String getLPaymtMethd() {
		return this.lPaymtMethd;
	}

	public void setLPaymtMethd(String lPaymtMethd) {
		this.lPaymtMethd = lPaymtMethd;
	}

	public String getLReqVoid() {
		return this.lReqVoid;
	}

	public void setLReqVoid(String lReqVoid) {
		this.lReqVoid = lReqVoid;
	}

	public String getLVoid() {
		return this.lVoid;
	}

	public void setLVoid(String lVoid) {
		this.lVoid = lVoid;
	}

	public String getNHseBank() {
		return this.nHseBank;
	}

	public void setNHseBank(String nHseBank) {
		this.nHseBank = nHseBank;
	}

	public String getNReqPayeCity() {
		return this.nReqPayeCity;
	}

	public void setNReqPayeCity(String nReqPayeCity) {
		this.nReqPayeCity = nReqPayeCity;
	}

	public String getNReqPayeCntry() {
		return this.nReqPayeCntry;
	}

	public void setNReqPayeCntry(String nReqPayeCntry) {
		this.nReqPayeCntry = nReqPayeCntry;
	}

	public String getNVndr() {
		return this.nVndr;
	}

	public void setNVndr(String nVndr) {
		this.nVndr = nVndr;
	}

	public String getNVndrCity() {
		return this.nVndrCity;
	}

	public void setNVndrCity(String nVndrCity) {
		this.nVndrCity = nVndrCity;
	}

	public String getNVoidBy() {
		return this.nVoidBy;
	}

	public void setNVoidBy(String nVoidBy) {
		this.nVoidBy = nVoidBy;
	}

	public Timestamp getTReqSent() {
		return this.tReqSent;
	}

	public void setTReqSent(Timestamp tReqSent) {
		this.tReqSent = tReqSent;
	}

	public Timestamp getTRespsRecvdDate() {
		return this.tRespsRecvdDate;
	}

	public void setTRespsRecvdDate(Timestamp tRespsRecvdDate) {
		this.tRespsRecvdDate = tRespsRecvdDate;
	}

	public String getXReas() {
		return this.xReas;
	}

	public void setXReas(String xReas) {
		this.xReas = xReas;
	}

	public String getXReq1099Data() {
		return this.xReq1099Data;
	}

	public void setXReq1099Data(String xReq1099Data) {
		this.xReq1099Data = xReq1099Data;
	}

	public String getXReqPayeAddr1() {
		return this.xReqPayeAddr1;
	}

	public void setXReqPayeAddr1(String xReqPayeAddr1) {
		this.xReqPayeAddr1 = xReqPayeAddr1;
	}

	public String getXReqPayeAddr2() {
		return this.xReqPayeAddr2;
	}

	public void setXReqPayeAddr2(String xReqPayeAddr2) {
		this.xReqPayeAddr2 = xReqPayeAddr2;
	}

	public String getXReqPayeLine1() {
		return this.xReqPayeLine1;
	}

	public void setXReqPayeLine1(String xReqPayeLine1) {
		this.xReqPayeLine1 = xReqPayeLine1;
	}

	public String getXReqPayeLine2() {
		return this.xReqPayeLine2;
	}

	public void setXReqPayeLine2(String xReqPayeLine2) {
		this.xReqPayeLine2 = xReqPayeLine2;
	}

	public String getXReqPayeLine3() {
		return this.xReqPayeLine3;
	}

	public void setXReqPayeLine3(String xReqPayeLine3) {
		this.xReqPayeLine3 = xReqPayeLine3;
	}

	public String getXReqRemitAdvce1() {
		return this.xReqRemitAdvce1;
	}

	public void setXReqRemitAdvce1(String xReqRemitAdvce1) {
		this.xReqRemitAdvce1 = xReqRemitAdvce1;
	}

	public String getXReqRemitAdvce2() {
		return this.xReqRemitAdvce2;
	}

	public void setXReqRemitAdvce2(String xReqRemitAdvce2) {
		this.xReqRemitAdvce2 = xReqRemitAdvce2;
	}

	public String getxComnt() {
		return xComnt;
	}

	public void setxComnt(String xComnt) {
		this.xComnt = xComnt;
	}

	public String getcPaye() {
		return cPaye;
	}

	public void setcPaye(String cPaye) {
		this.cPaye = cPaye;
	}

	public Check getCheck() {
		return this.check;
	}

	public void setCheck(Check check) {
		this.check = check;
	}

	public CodeMaster getScheduleFlag() {
		return scheduleFlag;
	}

	public void setScheduleFlag(CodeMaster scheduleFlag) {
		this.scheduleFlag = scheduleFlag;
	}

	public CodeMaster getPayeeState() {
		return payeeState;
	}

	public void setPayeeState(CodeMaster payeeState) {
		this.payeeState = payeeState;
	}

	public CodeMaster getVendorState() {
		return vendorState;
	}

	public void setVendorState(CodeMaster vendorState) {
		this.vendorState = vendorState;
	}

	public CodeMaster getCheckStatus() {
		return checkStatus;
	}

	public void setCheckStatus(CodeMaster checkStatus) {
		this.checkStatus = checkStatus;
	}

	public CodeMaster getApprovalStatus() {
		return approvalStatus;
	}

	public void setApprovalStatus(CodeMaster approvalStatus) {
		this.approvalStatus = approvalStatus;
	}

	public CodeMaster getCheckType() {
		return checkType;
	}

	public void setCheckType(CodeMaster checkType) {
		this.checkType = checkType;
	}

	public String getiVndr() {
		return iVndr;
	}

	public void setiVndr(String iVndr) {
		this.iVndr = iVndr;
	}

}