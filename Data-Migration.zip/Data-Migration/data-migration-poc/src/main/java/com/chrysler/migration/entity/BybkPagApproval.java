package com.chrysler.migration.entity;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * The persistent class for the BYBK_PKG_APPROVAL database table.
 * 
 */
@Entity
@Table(name = "BYBK_PKG_APPROVAL")
@NamedQuery(name = "BybkPagApproval.findAll", query = "SELECT b FROM BybkPagApproval b")
public class BybkPagApproval extends AuditColumns implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "I_PKG_APRVL_SEQ")
	private int iPagAprvlSeq;

	@Column(name = "I_ORDR_NMBR")
	private int iOrdrNmbr;

	@Column(name = "T_PKG_APRVL")
	private Timestamp tPagAprvl;

	@Column(name = "X_COMMENT")
	private String xComment;
	
	@Column(name = "L_CAIR_UPD_SYS")
	private String lCairUpdSys;
	
	// bi-directional many-to-one association to Buyback
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_BYBK")
	private Buyback buyback;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "L_STAT")
	private CodeMaster approverStatusCode;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_USER_TYP")
	private CodeMaster userTypeCode;

	// bi-directional many-to-one association to User
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_USER")
	private User user;

	// bi-directional many-to-one association to User
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_CHECK")
	private Check check;
	
	@Column(name = "L_PKG_CHECK_TYP")
	private String lPkgCheckTyp;

	public BybkPagApproval() {
	}

	public int getIPagAprvlSeq() {
		return this.iPagAprvlSeq;
	}

	public void setIPagAprvlSeq(int iPagAprvlSeq) {
		this.iPagAprvlSeq = iPagAprvlSeq;
	}

	public int getIOrdrNmbr() {
		return this.iOrdrNmbr;
	}

	public void setIOrdrNmbr(int iOrdrNmbr) {
		this.iOrdrNmbr = iOrdrNmbr;
	}

	public Timestamp getTPagAprvl() {
		return this.tPagAprvl;
	}

	public void setTPagAprvl(Timestamp tPagAprvl) {
		this.tPagAprvl = tPagAprvl;
	}

	public String getXComment() {
		return this.xComment;
	}

	public void setXComment(String xComment) {
		this.xComment = xComment;
	}

	public Buyback getBuyback() {
		return this.buyback;
	}

	public void setBuyback(Buyback buyback) {
		this.buyback = buyback;
	}

	public CodeMaster getApproverStatusCode() {
		return this.approverStatusCode;
	}

	public void setApproverStatusCode(CodeMaster codeMaster) {
		this.approverStatusCode = codeMaster;
	}

	public CodeMaster getUserTypeCode() {
		return userTypeCode;
	}

	public void setUserTypeCode(CodeMaster userTypeCode) {
		this.userTypeCode = userTypeCode;
	}

	public User getUser() {
		return this.user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public String getlPkgCheckTyp() {
		return lPkgCheckTyp;
	}

	public void setlPkgCheckTyp(String lPkgCheckTyp) {
		this.lPkgCheckTyp = lPkgCheckTyp;
	}

	public String getlCairUpdSys() {
		return lCairUpdSys;
	}

	public void setlCairUpdSys(String lCairUpdSys) {
		this.lCairUpdSys = lCairUpdSys;
	}

	public Check getCheck() {
		return check;
	}

	public void setCheck(Check check) {
		this.check = check;
	}

}