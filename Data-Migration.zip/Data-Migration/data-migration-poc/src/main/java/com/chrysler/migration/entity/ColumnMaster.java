package com.chrysler.migration.entity;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * The persistent class for the COLUMN_MASTER database table.
 * 
 */
@Entity
@Table(name = "COLUMN_MASTER")
@NamedQuery(name = "ColumnMaster.findAll", query = "SELECT c FROM ColumnMaster c")
public class ColumnMaster implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "I_COLM_SEQ")
	private int iColmSeq;

	@Column(name = "I_LOGON")
	private String iLogon;

	@Column(name = "I_LOGON_UPD")
	private String iLogonUpd;

	@Column(name = "L_MSTR")
	private String lMstr;

	@Column(name = "N_COLM_BUS")
	private String nColmBus;

	@Column(name = "N_COLM_PHYS")
	private String nColmPhys;

	@Column(name = "T_STMP_ADD")
	private Timestamp tStmpAdd;

	@Column(name = "T_STMP_UPD")
	private Timestamp tStmpUpd;

	@Column(name = "X_DATA_TYP")
	private String xDataTyp;

	// bi-directional many-to-one association to AuditTrailField
	// @OneToMany(mappedBy="columnMaster")
	// private Set<AuditTrailField> auditTrailFields;

	// bi-directional many-to-one association to TableMaster
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_TBL")
	private TableMaster tableMaster;

	// bi-directional many-to-one association to TypeMaster
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "C_MSTR_TYP")
	private TypeMaster typeMaster;

	// bi-directional many-to-one association to RptColmMstr
	@OneToMany(mappedBy = "columnMaster")
	private List<RptColmMstr> rptColmMstrs;

	// bi-directional many-to-one association to RptGrpByHaving
	@OneToMany(mappedBy = "iColmCode")
	private List<RptGrpByHaving> rptGrpByHavingsColumCode;

	// bi-directional many-to-one association to RptGrpByHaving
	@OneToMany(mappedBy = "iHavingCode")
	private List<RptGrpByHaving> rptGrpByHavingsCode;

	// bi-directional many-to-one association to RptOrdrBy
	@OneToMany(mappedBy = "columnMaster")
	private List<RptOrdrBy> rptOrdrBies;

	// bi-directional many-to-one association to RptWhereCond
	@OneToMany(mappedBy = "columnMaster")
	private List<RptWhereCond> rptWhereConds;

	// bi-directional many-to-one association to UserEmail
	@OneToMany(mappedBy = "columnMaster")
	private Set<UserEmail> userEmails;

	@Column(name = "L_BYBK")
	private String lBuyback;

	@Column(name = "L_RPT")
	private String lRpt;

	public ColumnMaster() {
	}

	public int getIColmSeq() {
		return this.iColmSeq;
	}

	public void setIColmSeq(int iColmSeq) {
		this.iColmSeq = iColmSeq;
	}

	public String getILogon() {
		return this.iLogon;
	}

	public void setILogon(String iLogon) {
		this.iLogon = iLogon;
	}

	public String getILogonUpd() {
		return this.iLogonUpd;
	}

	public void setILogonUpd(String iLogonUpd) {
		this.iLogonUpd = iLogonUpd;
	}

	public String getLMstr() {
		return this.lMstr;
	}

	public void setLMstr(String lMstr) {
		this.lMstr = lMstr;
	}

	public String getlBuyback() {
		return lBuyback;
	}

	public void setlBuyback(String lBuyback) {
		this.lBuyback = lBuyback;
	}

	public String getNColmBus() {
		return this.nColmBus;
	}

	public void setNColmBus(String nColmBus) {
		this.nColmBus = nColmBus;
	}

	public String getNColmPhys() {
		return this.nColmPhys;
	}

	public void setNColmPhys(String nColmPhys) {
		this.nColmPhys = nColmPhys;
	}

	public Timestamp getTStmpAdd() {
		return this.tStmpAdd;
	}

	public void setTStmpAdd(Timestamp tStmpAdd) {
		this.tStmpAdd = tStmpAdd;
	}

	public Timestamp getTStmpUpd() {
		return this.tStmpUpd;
	}

	public void setTStmpUpd(Timestamp tStmpUpd) {
		this.tStmpUpd = tStmpUpd;
	}

	public String getXDataTyp() {
		return this.xDataTyp;
	}

	public void setXDataTyp(String xDataTyp) {
		this.xDataTyp = xDataTyp;
	}

	// public Set<AuditTrailField> getAuditTrailFields() {
	// return this.auditTrailFields;
	// }
	//
	// public void setAuditTrailFields(Set<AuditTrailField> auditTrailFields) {
	// this.auditTrailFields = auditTrailFields;
	// }

	public TableMaster getTableMaster() {
		return this.tableMaster;
	}

	public void setTableMaster(TableMaster tableMaster) {
		this.tableMaster = tableMaster;
	}

	public TypeMaster getTypeMaster() {
		return this.typeMaster;
	}

	public void setTypeMaster(TypeMaster typeMaster) {
		this.typeMaster = typeMaster;
	}

	public List<RptColmMstr> getRptColmMstrs() {
		return this.rptColmMstrs;
	}

	public void setRptColmMstrs(List<RptColmMstr> rptColmMstrs) {
		this.rptColmMstrs = rptColmMstrs;
	}

	public RptColmMstr addRptColmMstr(RptColmMstr rptColmMstr) {
		getRptColmMstrs().add(rptColmMstr);
		rptColmMstr.setColumnMaster(this);

		return rptColmMstr;
	}

	public RptColmMstr removeRptColmMstr(RptColmMstr rptColmMstr) {
		getRptColmMstrs().remove(rptColmMstr);
		rptColmMstr.setColumnMaster(null);

		return rptColmMstr;
	}

	public List<RptGrpByHaving> getRptGrpByHavings1() {
		return this.rptGrpByHavingsColumCode;
	}

	public void setRptGrpByHavings1(List<RptGrpByHaving> rptGrpByHavings1) {
		this.rptGrpByHavingsColumCode = rptGrpByHavings1;
	}

	public RptGrpByHaving addRptGrpByHavings1(RptGrpByHaving rptGrpByHavings1) {
		getRptGrpByHavings1().add(rptGrpByHavings1);
		rptGrpByHavings1.setiColmCode(this);

		return rptGrpByHavings1;
	}

	public RptGrpByHaving removeRptGrpByHavings1(RptGrpByHaving rptGrpByHavings1) {
		getRptGrpByHavings1().remove(rptGrpByHavings1);
		rptGrpByHavings1.setiColmCode(this);

		return rptGrpByHavings1;
	}

	public List<RptGrpByHaving> getRptGrpByHavings2() {
		return this.rptGrpByHavingsCode;
	}

	public void setRptGrpByHavings2(List<RptGrpByHaving> rptGrpByHavings2) {
		this.rptGrpByHavingsCode = rptGrpByHavings2;
	}

	public RptGrpByHaving addRptGrpByHavings2(RptGrpByHaving rptGrpByHavings2) {
		getRptGrpByHavings2().add(rptGrpByHavings2);
		rptGrpByHavings2.setiHavingCode(this);

		return rptGrpByHavings2;
	}

	public RptGrpByHaving removeRptGrpByHavings2(RptGrpByHaving rptGrpByHavings2) {
		getRptGrpByHavings2().remove(rptGrpByHavings2);
		rptGrpByHavings2.setiHavingCode(null);

		return rptGrpByHavings2;
	}

	public List<RptOrdrBy> getRptOrdrBies() {
		return this.rptOrdrBies;
	}

	public void setRptOrdrBies(List<RptOrdrBy> rptOrdrBies) {
		this.rptOrdrBies = rptOrdrBies;
	}

	public RptOrdrBy addRptOrdrBy(RptOrdrBy rptOrdrBy) {
		getRptOrdrBies().add(rptOrdrBy);
		rptOrdrBy.setColumnMaster(this);

		return rptOrdrBy;
	}

	public RptOrdrBy removeRptOrdrBy(RptOrdrBy rptOrdrBy) {
		getRptOrdrBies().remove(rptOrdrBy);
		rptOrdrBy.setColumnMaster(null);

		return rptOrdrBy;
	}

	public List<RptWhereCond> getRptWhereConds() {
		return this.rptWhereConds;
	}

	public void setRptWhereConds(List<RptWhereCond> rptWhereConds) {
		this.rptWhereConds = rptWhereConds;
	}

	public RptWhereCond addRptWhereCond(RptWhereCond rptWhereCond) {
		getRptWhereConds().add(rptWhereCond);
		rptWhereCond.setColumnMaster(this);

		return rptWhereCond;
	}

	public RptWhereCond removeRptWhereCond(RptWhereCond rptWhereCond) {
		getRptWhereConds().remove(rptWhereCond);
		rptWhereCond.setColumnMaster(null);

		return rptWhereCond;
	}

	public Set<UserEmail> getUserEmails() {
		return this.userEmails;
	}

	public void setUserEmails(Set<UserEmail> userEmails) {
		this.userEmails = userEmails;
	}

	public String getlRpt() {
		return lRpt;
	}

	public void setlRpt(String lRpt) {
		this.lRpt = lRpt;
	}

	// public UserEmail addUserEmail(UserEmail userEmail) {
	// getUserEmails().add(userEmail);
	// userEmail.setColumnMaster(this);
	//
	// return userEmail;
	// }
	//
	// public UserEmail removeUserEmail(UserEmail userEmail) {
	// getUserEmails().remove(userEmail);
	// userEmail.setColumnMaster(null);
	//
	// return userEmail;
	// }

}