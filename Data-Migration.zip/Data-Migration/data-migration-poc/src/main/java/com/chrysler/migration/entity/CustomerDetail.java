package com.chrysler.migration.entity;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MapsId;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.LazyToOne;
import org.hibernate.annotations.LazyToOneOption;

/**
 * The persistent class for the CUSTOMER_DETAIL database table.
 * 
 */
@Entity
@Table(name = "CUSTOMER_DETAIL")
@NamedQuery(name = "CustomerDetail.findAll", query = "SELECT c FROM CustomerDetail c")
public class CustomerDetail extends AuditColumns implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private Integer iBybk;

	@Column(name = "C_CUST_ZIP")
	private String cCustZip;

	@Column(name = "I_CUST_ALT_PH_1")
	private String iCustAltPh1;

	@Column(name = "I_CUST_ALT_PH_2")
	private String iCustAltPh2;

	@Column(name = "I_CUST_PRMRY_PH")
	private String iCustPrmryPh;

	@Column(name = "L_RNTL")
	private String lRntl;

	@Column(name = "N_CUST_CITY")
	private String nCustCity;

	@Column(name = "N_CUST_SUFF")
	private String nCustSuff;

	@Column(name = "N_CUST_FIRST")
	private String nCustFirst;

	@Column(name = "N_CUST_MID")
	private String nCustMid;

	@Column(name = "N_CUST_SEC")
	private String nCustSec;

	@Column(name = "T_RNTL_STRT")
	private Timestamp tRntlStrt;

	@Column(name = "X_BEST_TIME_CALL")
	private String xBestTimeCall;

	@Column(name = "X_CUST_EMAIL_ADDR")
	private String xCustEmailAddr;

	@Column(name = "X_CUST_LINE_1")
	private String xCustLine1;

	@Column(name = "X_CUST_LINE_2")
	private String xCustLine2;

	@Column(name = "X_DLR_CNTCT")
	private String xDlrCntct;

	// bi-directional one-to-one association to Buyback
	@OneToOne(fetch = FetchType.LAZY)
	@MapsId
	@LazyToOne(LazyToOneOption.NO_PROXY)
	@JoinColumn(name = "I_BYBK")
	private Buyback buyback;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_CUST_STATE")
	private CodeMaster stateCode;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_CNTCT_PREFCE")
	private CodeMaster contactPreferenceCode;

	public CustomerDetail() {
		//
	}

	public Integer getIBybk() {
		return this.iBybk;
	}

	public void setIBybk(Integer iBybk) {
		this.iBybk = iBybk;
	}

	public String getCCustZip() {
		return this.cCustZip;
	}

	public void setCCustZip(String cCustZip) {
		this.cCustZip = cCustZip;
	}

	public String getICustAltPh1() {
		return this.iCustAltPh1;
	}

	public void setICustAltPh1(String iCustAltPh1) {
		this.iCustAltPh1 = iCustAltPh1;
	}

	public String getICustAltPh2() {
		return this.iCustAltPh2;
	}

	public void setICustAltPh2(String iCustAltPh2) {
		this.iCustAltPh2 = iCustAltPh2;
	}

	public String getICustPrmryPh() {
		return this.iCustPrmryPh;
	}

	public void setICustPrmryPh(String iCustPrmryPh) {
		this.iCustPrmryPh = iCustPrmryPh;
	}

	public String getLRntl() {
		return this.lRntl;
	}

	public void setLRntl(String lRntl) {
		this.lRntl = lRntl;
	}

	public String getNCustCity() {
		return this.nCustCity;
	}

	public void setNCustCity(String nCustCity) {
		this.nCustCity = nCustCity;
	}

	public String getNCustFirst() {
		return this.nCustFirst;
	}

	public void setNCustFirst(String nCustFirst) {
		this.nCustFirst = nCustFirst;
	}

	public String getNCustSec() {
		return this.nCustSec;
	}

	public void setNCustSec(String nCustSec) {
		this.nCustSec = nCustSec;
	}

	public Timestamp getTRntlStrt() {
		return this.tRntlStrt;
	}

	public void setTRntlStrt(Timestamp tRntlStrt) {
		this.tRntlStrt = tRntlStrt;
	}

	public String getXBestTimeCall() {
		return this.xBestTimeCall;
	}

	public void setXBestTimeCall(String xBestTimeCall) {
		this.xBestTimeCall = xBestTimeCall;
	}

	public String getXCustEmailAddr() {
		return this.xCustEmailAddr;
	}

	public void setXCustEmailAddr(String xCustEmailAddr) {
		this.xCustEmailAddr = xCustEmailAddr;
	}

	public String getXCustLine1() {
		return this.xCustLine1;
	}

	public void setXCustLine1(String xCustLine1) {
		this.xCustLine1 = xCustLine1;
	}

	public String getXCustLine2() {
		return this.xCustLine2;
	}

	public void setXCustLine2(String xCustLine2) {
		this.xCustLine2 = xCustLine2;
	}

	public Buyback getBuyback() {
		return this.buyback;
	}

	public void setBuyback(Buyback buyback) {
		this.buyback = buyback;
	}

	public CodeMaster getStateCode() {
		return stateCode;
	}

	public void setStateCode(CodeMaster stateCode) {
		this.stateCode = stateCode;
	}

	public CodeMaster getContactPreferenceCode() {
		return contactPreferenceCode;
	}

	public void setContactPreferenceCode(CodeMaster contactPreferenceCode) {
		this.contactPreferenceCode = contactPreferenceCode;
	}

	public String getxDlrCntct() {
		return xDlrCntct;
	}

	public void setxDlrCntct(String xDlrCntct) {
		this.xDlrCntct = xDlrCntct;
	}

	public String getnCustSuff() {
		return nCustSuff;
	}

	public void setnCustSuff(String nCustSuff) {
		this.nCustSuff = nCustSuff;
	}

	public String getnCustMid() {
		return nCustMid;
	}

	public void setnCustMid(String nCustMid) {
		this.nCustMid = nCustMid;
	}

}