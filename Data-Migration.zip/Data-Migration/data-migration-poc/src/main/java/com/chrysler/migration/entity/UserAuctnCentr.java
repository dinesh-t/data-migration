package com.chrysler.migration.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * The persistent class for the USER_AUCTN_CENTR database table.
 * 
 */
@Entity
@Table(name = "USER_AUCTN_CENTR")
@NamedQuery(name = "UserAuctnCentr.findAll", query = "SELECT u FROM UserAuctnCentr u")
public class UserAuctnCentr extends AuditColumns implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "I_USER_AUCTN_SEQ")
	private int iUserAuctnSeq;

	// bi-directional many-to-one association to User
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_USER")
	private User user;

	// bi-directional many-to-one association to AuctionDetail
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "C_AUCTN_CENTR", referencedColumnName = "C_AUCTN_CENTR")
	private AuctionDetail auctionDetail;

	public int getIUserAuctnSeq() {
		return this.iUserAuctnSeq;
	}

	public void setIUserAuctnSeq(int iUserAuctnSeq) {
		this.iUserAuctnSeq = iUserAuctnSeq;
	}

	public User getUser() {
		return this.user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public AuctionDetail getAuctionDetail() {
		return this.auctionDetail;
	}

	public void setAuctionDetail(AuctionDetail auctionDetail) {
		this.auctionDetail = auctionDetail;
	}

}