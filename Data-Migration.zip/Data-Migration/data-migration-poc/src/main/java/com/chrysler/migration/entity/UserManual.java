package com.chrysler.migration.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * The persistent class for the USER_MANUAL database table.
 * 
 */
@Entity
@Table(name = "USER_MANUAL")
@NamedQuery(name = "UserManual.findAll", query = "SELECT u FROM UserManual u")
public class UserManual extends AuditColumns implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "I_USER_MNUL_SEQ")
	private Integer iUserMnulSeq;

	@Column(name = "L_MNUL_PUBL")
	private String lMnulPubl;

	@Column(name = "L_MNUL_STAT")
	private String lMnulStat;

	@Lob
	@Column(name = "X_MNUL")
	private String xMnul;

	@Column(name = "X_MNUL_DESC")
	private String xMnulDesc;

	@Column(name = "X_MNUL_TI")
	private String xMnulTi;

	public UserManual() {
	}

	public Integer getIUserMnulSeq() {
		return this.iUserMnulSeq;
	}

	public void setIUserMnulSeq(Integer iUserMnulSeq) {
		this.iUserMnulSeq = iUserMnulSeq;
	}

	public String getLMnulPubl() {
		return this.lMnulPubl;
	}

	public void setLMnulPubl(String lMnulPubl) {
		this.lMnulPubl = lMnulPubl;
	}

	public String getLMnulStat() {
		return this.lMnulStat;
	}

	public void setLMnulStat(String lMnulStat) {
		this.lMnulStat = lMnulStat;
	}

	public String getXMnul() {
		return this.xMnul;
	}

	public void setXMnul(String xMnul) {
		this.xMnul = xMnul;
	}

	public String getXMnulDesc() {
		return this.xMnulDesc;
	}

	public void setXMnulDesc(String xMnulDesc) {
		this.xMnulDesc = xMnulDesc;
	}

	public String getXMnulTi() {
		return this.xMnulTi;
	}

	public void setXMnulTi(String xMnulTi) {
		this.xMnulTi = xMnulTi;
	}

}
