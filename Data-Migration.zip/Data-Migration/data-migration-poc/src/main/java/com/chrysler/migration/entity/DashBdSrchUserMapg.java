package com.chrysler.migration.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * The persistent class for the DASH_BD_SRCH_USER_MAPG database table.
 * 
 */
@Entity
@Table(name = "DASH_BD_SRCH_USER_MAPG")
@NamedQuery(name = "DashBdSrchUserMapg.findAll", query = "SELECT d FROM DashBdSrchUserMapg d")
public class DashBdSrchUserMapg extends AuditColumns implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "I_DASH_BD_SR_U_SEQ")
	private int iDashBdSrUSeq;

	@Column(name = "L_SLCT")
	private String lSlct;

	// bi-directional many-to-one association to DashBd
	@ManyToOne
	@JoinColumn(name = "I_DASH_BD")
	private DashBd dashBd;

	// bi-directional many-to-one association to DashBdSrch
	@ManyToOne
	@JoinColumn(name = "I_DASH_BD_SRCH")
	private DashBdSrch dashBdSrch;

	// bi-directional many-to-one association to User
	@ManyToOne
	@JoinColumn(name = "I_USER")
	private User user;

	public DashBdSrchUserMapg() {
	}

	public int getIDashBdSrUSeq() {
		return this.iDashBdSrUSeq;
	}

	public void setIDashBdSrUSeq(int iDashBdSrUSeq) {
		this.iDashBdSrUSeq = iDashBdSrUSeq;
	}

	public String getLSlct() {
		return this.lSlct;
	}

	public void setLSlct(String lSlct) {
		this.lSlct = lSlct;
	}

	public DashBd getDashBd() {
		return this.dashBd;
	}

	public void setDashBd(DashBd dashBd) {
		this.dashBd = dashBd;
	}

	public DashBdSrch getDashBdSrch() {
		return this.dashBdSrch;
	}

	public void setDashBdSrch(DashBdSrch dashBdSrch) {
		this.dashBdSrch = dashBdSrch;
	}

	public User getUser() {
		return this.user;
	}

	public void setUser(User user) {
		this.user = user;
	}

}