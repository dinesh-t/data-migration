package com.chrysler.migration.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * The persistent class for the DASH_BD_LNK_USER_MAPG database table.
 * 
 */
@Entity
@Table(name = "DASH_BD_LNK_USER_MAPG")
@NamedQuery(name = "DashBdLnkUserMapg.findAll", query = "SELECT d FROM DashBdLnkUserMapg d")
public class DashBdLnkUserMapg extends AuditColumns implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "I_DASH_LNK_US_SEQ")
	private int iDashLnkUsSeq;

	@Column(name = "L_SLCT")
	private String lSlct;

	// bi-directional many-to-one association to DashBd
	@ManyToOne
	@JoinColumn(name = "I_DASH_BD")
	private DashBd dashBd;

	// bi-directional many-to-one association to DashBdLnk
	@ManyToOne
	@JoinColumn(name = "I_DASH_LNK")
	private DashBdLnk dashBdLnk;

	// bi-directional many-to-one association to User
	@ManyToOne
	@JoinColumn(name = "I_USER")
	private User user;

	public DashBdLnkUserMapg() {
	}

	public int getIDashLnkUsSeq() {
		return this.iDashLnkUsSeq;
	}

	public void setIDashLnkUsSeq(int iDashLnkUsSeq) {
		this.iDashLnkUsSeq = iDashLnkUsSeq;
	}

	public String getLSlct() {
		return this.lSlct;
	}

	public void setLSlct(String lSlct) {
		this.lSlct = lSlct;
	}

	public DashBd getDashBd() {
		return this.dashBd;
	}

	public void setDashBd(DashBd dashBd) {
		this.dashBd = dashBd;
	}

	public DashBdLnk getDashBdLnk() {
		return this.dashBdLnk;
	}

	public void setDashBdLnk(DashBdLnk dashBdLnk) {
		this.dashBdLnk = dashBdLnk;
	}

	public User getUser() {
		return this.user;
	}

	public void setUser(User user) {
		this.user = user;
	}

}