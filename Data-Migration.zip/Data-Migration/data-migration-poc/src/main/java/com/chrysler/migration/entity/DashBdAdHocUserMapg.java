package com.chrysler.migration.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * The persistent class for the DASH_BD_AD_HOC_USER_MAPG database table.
 * 
 */
@Entity
@Table(name = "DASH_BD_AD_HOC_USER_MAPG")
@NamedQuery(name = "DashBdAdHocUserMapg.findAll", query = "SELECT d FROM DashBdAdHocUserMapg d")
public class DashBdAdHocUserMapg extends AuditColumns implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "I_DASH_HOC_US_SEQ")
	private int iDashHocUsSeq;

	@Column(name = "L_SLCT")
	private String lSlct;

	// bi-directional many-to-one association to DashBd
	@ManyToOne
	@JoinColumn(name = "I_DASH_BD")
	private DashBd dashBd;

	// bi-directional many-to-one association to DashBdAdHoc
	@ManyToOne
	@JoinColumn(name = "I_DASH_HOC")
	private DashBdAdHoc dashBdAdHoc;

	// bi-directional many-to-one association to User
	@ManyToOne
	@JoinColumn(name = "I_USER")
	private User user;

	public DashBdAdHocUserMapg() {
	}

	public int getIDashHocUsSeq() {
		return this.iDashHocUsSeq;
	}

	public void setIDashHocUsSeq(int iDashHocUsSeq) {
		this.iDashHocUsSeq = iDashHocUsSeq;
	}

	public String getLSlct() {
		return this.lSlct;
	}

	public void setLSlct(String lSlct) {
		this.lSlct = lSlct;
	}

	public DashBd getDashBd() {
		return this.dashBd;
	}

	public void setDashBd(DashBd dashBd) {
		this.dashBd = dashBd;
	}

	public DashBdAdHoc getDashBdAdHoc() {
		return this.dashBdAdHoc;
	}

	public void setDashBdAdHoc(DashBdAdHoc dashBdAdHoc) {
		this.dashBdAdHoc = dashBdAdHoc;
	}

	public User getUser() {
		return this.user;
	}

	public void setUser(User user) {
		this.user = user;
	}

}