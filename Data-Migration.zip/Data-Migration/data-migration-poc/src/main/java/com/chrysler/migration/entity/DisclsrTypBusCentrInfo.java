package com.chrysler.migration.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * The persistent class for the DISCLSR_TYP_BUS_CENTR_INFO database table.
 * 
 */
@Entity
@Table(name = "DISCLSR_TYP_BUS_CENTR_INFO")
@NamedQuery(name = "DisclsrTypBusCentrInfo.findAll", query = "SELECT d FROM DisclsrTypBusCentrInfo d")
public class DisclsrTypBusCentrInfo extends AuditColumns implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "I_DISCLSR_BUS_SEQ")
	private Integer iDisclsrBusSeq;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_DISCLSR_TYP")
	private CodeMaster disclosureType;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_BUS_CENTR")
	private CodeMaster businessCenter;

	public DisclsrTypBusCentrInfo() {
	}

	public Integer getIDisclsrBusSeq() {
		return this.iDisclsrBusSeq;
	}

	public void setIDisclsrBusSeq(Integer iDisclsrBusSeq) {
		this.iDisclsrBusSeq = iDisclsrBusSeq;
	}

	public CodeMaster getDisclosureType() {
		return disclosureType;
	}

	public void setDisclosureType(CodeMaster disclosureType) {
		this.disclosureType = disclosureType;
	}

	public CodeMaster getBusinessCenter() {
		return businessCenter;
	}

	public void setBusinessCenter(CodeMaster businessCenter) {
		this.businessCenter = businessCenter;
	}

}