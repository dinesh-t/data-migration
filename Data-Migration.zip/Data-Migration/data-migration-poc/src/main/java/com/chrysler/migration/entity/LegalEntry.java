package com.chrysler.migration.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MapsId;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.LazyToOne;
import org.hibernate.annotations.LazyToOneOption;

/**
 * The persistent class for the LEGAL_ENTRY database table.
 * 
 */
@Entity
@Table(name = "LEGAL_ENTRY")
@NamedQuery(name = "LegalEntry.findAll", query = "SELECT l FROM LegalEntry l")
public class LegalEntry extends AuditColumns implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private Integer iBybk;

	@Column(name = "A_ATTY_FEE")
	private BigDecimal aAttyFee;

	@Column(name = "A_DECS_ON_SETLMT")
	private BigDecimal aDecsOnSetlmt;

	@Column(name = "I_ATTY_PH")
	private String iAttyPh;

	@Column(name = "L_AFT_MKT_ACCRY")
	private String lAftMktAccry;

	@Column(name = "L_ATTY")
	private String lAtty;

	@Column(name = "L_DCIBS")
	private String lDcibs;

	@Column(name = "L_FTBN")
	private String lFtbn;

	@Column(name = "N_ATTY")
	private String nAtty;

	@Column(name = "T_CMPLNC_DUE")
	private Timestamp tCmplncDue;

	@Column(name = "X_AFT_MKT_ACCRY")
	private String xAftMktAccry;

	// bi-directional one-to-one association to Buyback
	@OneToOne(fetch = FetchType.LAZY)
	@MapsId
	@LazyToOne(LazyToOneOption.NO_PROXY)
	@JoinColumn(name = "I_BYBK")
	private Buyback buyback;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_DECS_SETLMT_TYP")
	private CodeMaster decisionSettlementTypeCode;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_NEGOT_TERMS")
	private CodeMaster negotiationTermsCode;

	public LegalEntry() {
		//
	}

	public Integer getIBybk() {
		return this.iBybk;
	}

	public void setIBybk(Integer iBybk) {
		this.iBybk = iBybk;
	}

	public BigDecimal getAAttyFee() {
		return this.aAttyFee;
	}

	public void setAAttyFee(BigDecimal aAttyFee) {
		this.aAttyFee = aAttyFee;
	}

	public BigDecimal getADecsOnSetlmt() {
		return this.aDecsOnSetlmt;
	}

	public void setADecsOnSetlmt(BigDecimal aDecsOnSetlmt) {
		this.aDecsOnSetlmt = aDecsOnSetlmt;
	}

	public String getIAttyPh() {
		return this.iAttyPh;
	}

	public void setIAttyPh(String iAttyPh) {
		this.iAttyPh = iAttyPh;
	}

	public String getLAftMktAccry() {
		return this.lAftMktAccry;
	}

	public void setLAftMktAccry(String lAftMktAccry) {
		this.lAftMktAccry = lAftMktAccry;
	}

	public String getLAtty() {
		return this.lAtty;
	}

	public void setLAtty(String lAtty) {
		this.lAtty = lAtty;
	}

	public String getLDcibs() {
		return this.lDcibs;
	}

	public void setLDcibs(String lDcibs) {
		this.lDcibs = lDcibs;
	}

	public String getLFtbn() {
		return this.lFtbn;
	}

	public void setLFtbn(String lFtbn) {
		this.lFtbn = lFtbn;
	}

	public String getNAtty() {
		return this.nAtty;
	}

	public void setNAtty(String nAtty) {
		this.nAtty = nAtty;
	}

	public Timestamp getTCmplncDue() {
		return this.tCmplncDue;
	}

	public void setTCmplncDue(Timestamp tCmplncDue) {
		this.tCmplncDue = tCmplncDue;
	}

	public String getXAftMktAccry() {
		return this.xAftMktAccry;
	}

	public void setXAftMktAccry(String xAftMktAccry) {
		this.xAftMktAccry = xAftMktAccry;
	}

	public Buyback getBuyback() {
		return this.buyback;
	}

	public void setBuyback(Buyback buyback) {
		this.buyback = buyback;
	}

	public CodeMaster getDecisionSettlementTypeCode() {
		return decisionSettlementTypeCode;
	}

	public void setDecisionSettlementTypeCode(CodeMaster decisionSettlementTypeCode) {
		this.decisionSettlementTypeCode = decisionSettlementTypeCode;
	}

	public CodeMaster getNegotiationTermsCode() {
		return negotiationTermsCode;
	}

	public void setNegotiationTermsCode(CodeMaster negotiationTermsCode) {
		this.negotiationTermsCode = negotiationTermsCode;
	}

}