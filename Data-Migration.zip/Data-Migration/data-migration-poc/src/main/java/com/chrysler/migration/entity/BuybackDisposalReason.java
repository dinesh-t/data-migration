package com.chrysler.migration.entity;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * The persistent class for the BUYBACK_DISPOSAL_REASON database table.
 * 
 */
@Entity
@Table(name = "BYBK_DSPSL_REAS")
@NamedQuery(name = "BuybackDisposalReason.findAll", query = "SELECT b FROM BuybackDisposalReason b")
public class BuybackDisposalReason extends AuditColumns implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "I_DSPSL_SEQ")
	// @FieldMapper(name = "id")
	private int iDspslSeq;

	@Column(name = "T_REPAIRED")
	private Timestamp tRepaired;

	@Column(name = "X_DSPSL_COMNT")
	private String xDspslComnt;

	@Column(name = "X_NON_CONFIRMITIES")
	private String xNonConfirmities;

	// bi-directional many-to-one association to Buyback
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_BYBK")
	private Buyback buyback;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_DSPSL_REAS")
	private CodeMaster disposalReason;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_REAS_STAT")
	private CodeMaster reasonStatus;

	public BuybackDisposalReason() {
	}

	public int getIDspslSeq() {
		return this.iDspslSeq;
	}

	public void setIDspslSeq(int iDspslSeq) {
		this.iDspslSeq = iDspslSeq;
	}

	public Timestamp getTRepaired() {
		return this.tRepaired;
	}

	public void setTRepaired(Timestamp tRepaired) {
		this.tRepaired = tRepaired;
	}

	public String getXDspslComnt() {
		return this.xDspslComnt;
	}

	public void setXDspslComnt(String xDspslComnt) {
		this.xDspslComnt = xDspslComnt;
	}

	public String getXNonConfirmities() {
		return this.xNonConfirmities;
	}

	public void setXNonConfirmities(String xNonConfirmities) {
		this.xNonConfirmities = xNonConfirmities;
	}

	public Buyback getBuyback() {
		return this.buyback;
	}

	public void setBuyback(Buyback buyback) {
		this.buyback = buyback;
	}

	public CodeMaster getDisposalReson() {
		return this.disposalReason;
	}

	public void setDisposalReason(CodeMaster codeMaster1) {
		this.disposalReason = codeMaster1;
	}

	public CodeMaster getReasonStatus() {
		return this.reasonStatus;
	}

	public void setReasonStatus(CodeMaster codeMaster2) {
		this.reasonStatus = codeMaster2;
	}

}