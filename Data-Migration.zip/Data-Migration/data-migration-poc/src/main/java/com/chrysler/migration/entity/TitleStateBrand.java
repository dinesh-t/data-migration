package com.chrysler.migration.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;


/**
 * The persistent class for the TITLE_STATE_BRAND database table.
 * 
 */
@Entity
@Table(name="TITLE_STATE_BRAND")
@NamedQuery(name="TitleStateBrand.findAll", query="SELECT t FROM TitleStateBrand t")
public class TitleStateBrand extends AuditColumns implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="I_TI_BRND_SEQ")
	private Integer iTiBrndSeq;

	//bi-directional many-to-one association to CodeMaster
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="I_CATGY_TYP")
	private CodeMaster packageCategoryCode;

	//bi-directional many-to-one association to CodeMaster
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="I_CATGY")
	private CodeMaster categoryCode;

	//bi-directional many-to-one association to CodeMaster
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="I_TI_STATE")
	private CodeMaster titleStateCode;

	public TitleStateBrand() {
	}

	public Integer getITiBrndSeq() {
		return this.iTiBrndSeq;
	}

	public void setITiBrndSeq(Integer iTiBrndSeq) {
		this.iTiBrndSeq = iTiBrndSeq;
	}

	public CodeMaster getPackageCategoryCode() {
		return this.packageCategoryCode;
	}

	public void setPackageCategoryCode(CodeMaster packageCategoryCode) {
		this.packageCategoryCode = packageCategoryCode;
	}

	public CodeMaster getCategoryCode() {
		return this.categoryCode;
	}

	public void setCategoryCode(CodeMaster categoryCode) {
		this.categoryCode = categoryCode;
	}

	public CodeMaster getTitleStateCode() {
		return this.titleStateCode;
	}

	public void setTitleStateCode(CodeMaster titleStateCode) {
		this.titleStateCode = titleStateCode;
	}

}