package com.chrysler.migration.entity;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.MapsId;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;

import org.hibernate.annotations.LazyToOne;
import org.hibernate.annotations.LazyToOneOption;

/**
 * The persistent class for the WARRANTY database table.
 * 
 */
@Entity
@NamedQuery(name = "Warranty.findAll", query = "SELECT w FROM Warranty w")
public class Warranty extends AuditColumns implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private int iBybk;

	@Column(name = "A_WARR_EXP")
	private BigDecimal aWarrExp;

	@Column(name = "I_VHCL_MY")
	private Integer iVhclMy;

	@Column(name = "L_WARR_STAT")
	private String lWarrStat;

	@Column(name = "Q_VHCL_CURR_MILG")
	private Integer qVhclCurrMilg;

	// bi-directional one-to-one association to Buyback
	@OneToOne(fetch = FetchType.LAZY)
	@MapsId
	@LazyToOne(LazyToOneOption.NO_PROXY)
	@JoinColumn(name = "I_BYBK")
	private Buyback buyback;

	public Warranty() {
		//
	}

	public Integer getIBybk() {
		return this.iBybk;
	}

	public void setIBybk(Integer iBybk) {
		this.iBybk = iBybk;
	}

	public BigDecimal getAWarrExp() {
		return this.aWarrExp;
	}

	public void setAWarrExp(BigDecimal aWarrExp) {
		this.aWarrExp = aWarrExp;
	}

	public Integer getIVhclMy() {
		return this.iVhclMy;
	}

	public void setIVhclMy(Integer iVhclMy) {
		this.iVhclMy = iVhclMy;
	}

	public String getLWarrStat() {
		return this.lWarrStat;
	}

	public void setLWarrStat(String lWarrStat) {
		this.lWarrStat = lWarrStat;
	}

	public Integer getQVhclCurrMilg() {
		return this.qVhclCurrMilg;
	}

	public void setQVhclCurrMilg(Integer qVhclCurrMilg) {
		this.qVhclCurrMilg = qVhclCurrMilg;
	}

	public Buyback getBuyback() {
		return this.buyback;
	}

	public void setBuyback(Buyback buyback) {
		this.buyback = buyback;
	}

}