package com.chrysler.migration.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import org.hibernate.annotations.LazyToOne;
import org.hibernate.annotations.LazyToOneOption;

/**
 * The persistent class for the AUCTION_CONTACT database table.
 * 
 */
@Entity
@Table(name = "AUCTION_CONTACT")
@NamedQuery(name = "AuctionContact.findAll", query = "SELECT a FROM AuctionContact a")
public class AuctionContact extends AuditColumns implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "I_AUCTN_CNTCT_SEQ")
	private int iAuctnCntctSeq;

	@Column(name = "I_PERSN_ALT_PH")
	private String iPersnAltPh;

	@Column(name = "I_PERSN_PRMRY_PH")
	private String iPersnPrmryPh;

	@Column(name = "N_AUCTN_PERSN")
	private String nAuctnPersn;

	@Column(name = "N_AUCTN_TI")
	private String nAuctnTi;

	@Column(name = "N_AUCTN_VR")
	private String nAuctnVr;

	@Column(name = "N_AUCTN_VRM")
	private String nAuctnVrm;

	@ManyToOne(fetch = FetchType.LAZY)
	@LazyToOne(LazyToOneOption.NO_PROXY)
	@JoinColumn(name = "I_AUCTN_DTL")
	private AuctionDetail auctionDetail;

	public AuctionContact() {
	}

	public int getIAuctnCntctSeq() {
		return this.iAuctnCntctSeq;
	}

	public void setIAuctnCntctSeq(int iAuctnCntctSeq) {
		this.iAuctnCntctSeq = iAuctnCntctSeq;
	}

	public String getIPersnAltPh() {
		return this.iPersnAltPh;
	}

	public void setIPersnAltPh(String iPersnAltPh) {
		this.iPersnAltPh = iPersnAltPh;
	}

	public String getIPersnPrmryPh() {
		return this.iPersnPrmryPh;
	}

	public void setIPersnPrmryPh(String iPersnPrmryPh) {
		this.iPersnPrmryPh = iPersnPrmryPh;
	}

	public String getNAuctnPersn() {
		return this.nAuctnPersn;
	}

	public void setNAuctnPersn(String nAuctnPersn) {
		this.nAuctnPersn = nAuctnPersn;
	}

	public String getNAuctnTi() {
		return this.nAuctnTi;
	}

	public void setNAuctnTi(String nAuctnTi) {
		this.nAuctnTi = nAuctnTi;
	}

	public String getNAuctnVr() {
		return this.nAuctnVr;
	}

	public void setNAuctnVr(String nAuctnVr) {
		this.nAuctnVr = nAuctnVr;
	}

	public String getNAuctnVrm() {
		return this.nAuctnVrm;
	}

	public void setNAuctnVrm(String nAuctnVrm) {
		this.nAuctnVrm = nAuctnVrm;
	}

	public AuctionDetail getAuctionDetail() {
		return this.auctionDetail;
	}

	public void setAuctionDetail(AuctionDetail auctionDetail) {
		this.auctionDetail = auctionDetail;
	}

}