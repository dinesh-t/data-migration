package com.chrysler.migration.entity;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedAttributeNode;
import javax.persistence.NamedEntityGraph;
import javax.persistence.NamedSubgraph;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * The persistent class for the "USER" database table.
 * 
 */
@Entity
@Table(name = "USER")
@NamedEntityGraph(name = "user.findEager", attributeNodes = {
		@NamedAttributeNode(value = "iUserTyp", subgraph = "iUserTyp"),
		@NamedAttributeNode(value = "statusCode", subgraph = "statusCode"),
		@NamedAttributeNode(value = "bussinessCenterCode", subgraph = "bussinessCenterCode"),
		@NamedAttributeNode(value = "districtCode", subgraph = "districtCode"),
		@NamedAttributeNode(value = "userRoles2", subgraph = "userRoles2"),
		@NamedAttributeNode(value = "userEmails", subgraph = "userEmails") }, subgraphs = {
				@NamedSubgraph(name = "userEmails", attributeNodes = @NamedAttributeNode(value = "columnMaster")),
				@NamedSubgraph(name = "iUserTyp", attributeNodes = @NamedAttributeNode(value = "typeMaster")),
				@NamedSubgraph(name = "statusCode", attributeNodes = @NamedAttributeNode(value = "typeMaster")),
				@NamedSubgraph(name = "bussinessCenterCode", attributeNodes = @NamedAttributeNode(value = "typeMaster")),
				@NamedSubgraph(name = "districtCode", attributeNodes = @NamedAttributeNode(value = "typeMaster")),
				@NamedSubgraph(name = "userRoles2", attributeNodes = @NamedAttributeNode(value = "role", subgraph = "role")),
				@NamedSubgraph(name = "role", attributeNodes = @NamedAttributeNode(value = "roleFunctions", subgraph = "roleFunctions")),
				@NamedSubgraph(name = "roleFunctions", attributeNodes = @NamedAttributeNode(value = "roleFunctions", subgraph = "typeMaster")),
				@NamedSubgraph(name = "typeMaster", attributeNodes = @NamedAttributeNode(value = "typeMaster")) })
public class User extends AuditColumns implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "I_USER")
	private String iUser;

	@Column(name = "I_CID")
	private String iCid;

	@Column(name = "I_DECN_MKR")
	private String iDecnMkr;

	@Column(name = "I_NIC")
	private String iNic;

	@Column(name = "L_AUCTN_CENTR")
	private String lAuctnCentr;

	@Column(name = "L_EMAIL")
	private String lEmail;

	@Column(name = "N_CO")
	private String nCo;

	@Column(name = "N_FIRST")
	private String nFirst;

	@Column(name = "N_LAST")
	private String nLast;

	@Column(name = "N_MID")
	private String nMid;

	@Column(name = "X_EMAIL_ADDR")
	private String xEmailAddr;

	@Column(name = "X_EXTSN")
	private String xExtsn;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_USER_TYP")
	private CodeMaster iUserTyp;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_STAT")
	private CodeMaster statusCode;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_BUS_CENTR")
	private CodeMaster bussinessCenterCode;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_DIST")
	private CodeMaster districtCode;

	// bi-directional many-to-one association to UserRole
	@OneToMany(mappedBy = "user2", fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	private Set<UserRole> userRoles2;

	// bi-directional many-to-one association to UserEmail
	@OneToMany(mappedBy = "user", fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	private Set<UserEmail> userEmails;

	// bi-directional many-to-one association to DealerDetail
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "C_DLR", referencedColumnName = "C_DLR")
	private DealerDetail cDlr;

	public String getIUser() {
		return this.iUser;
	}

	public void setIUser(String iUser) {
		this.iUser = iUser;
	}

	public DealerDetail getcDlr() {
		return cDlr;
	}

	public void setcDlr(DealerDetail cDlr) {
		this.cDlr = cDlr;
	}

	public CodeMaster getUserTyp() {
		return iUserTyp;
	}

	public void setUserTyp(CodeMaster iUserTyp) {
		this.iUserTyp = iUserTyp;
	}

	public String getICid() {
		return this.iCid;
	}

	public void setICid(String iCid) {
		this.iCid = iCid;
	}

	public String getIDecnMkr() {
		return this.iDecnMkr;
	}

	public void setIDecnMkr(String iDecnMkr) {
		this.iDecnMkr = iDecnMkr;
	}

	public String getINic() {
		return this.iNic;
	}

	public void setINic(String iNic) {
		this.iNic = iNic;
	}

	public String getLEmail() {
		return this.lEmail;
	}

	public void setLEmail(String lEmail) {
		this.lEmail = lEmail;
	}

	public String getNCo() {
		return this.nCo;
	}

	public void setNCo(String nCo) {
		this.nCo = nCo;
	}

	public String getNFirst() {
		return this.nFirst;
	}

	public void setNFirst(String nFirst) {
		this.nFirst = nFirst;
	}

	public String getNLast() {
		return this.nLast;
	}

	public void setNLast(String nLast) {
		this.nLast = nLast;
	}

	public String getNMid() {
		return this.nMid;
	}

	public void setNMid(String nMid) {
		this.nMid = nMid;
	}

	public String getXEmailAddr() {
		return this.xEmailAddr;
	}

	public void setXEmailAddr(String xEmailAddr) {
		this.xEmailAddr = xEmailAddr;
	}

	public String getXExtsn() {
		return this.xExtsn;
	}

	public void setXExtsn(String xExtsn) {
		this.xExtsn = xExtsn;
	}

	public CodeMaster getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(CodeMaster statusCode) {
		this.statusCode = statusCode;
	}

	public CodeMaster getBussinessCenterCode() {
		return bussinessCenterCode;
	}

	public void setBussinessCenterCode(CodeMaster bussinessCenterCode) {
		this.bussinessCenterCode = bussinessCenterCode;
	}

	public CodeMaster getDistrictCode() {
		return districtCode;
	}

	public void setDistrictCode(CodeMaster districtCode) {
		this.districtCode = districtCode;
	}

	public Set<UserRole> getUserRoles2() {
		return this.userRoles2;
	}

	public void setUserRoles2(Set<UserRole> userRoles2) {
		this.userRoles2 = userRoles2;
	}

	public UserRole addUserRoles2(UserRole userRoles2) {
		getUserRoles2().add(userRoles2);
		userRoles2.setUser2(this);
		return userRoles2;
	}

	public UserRole removeUserRoles2(UserRole userRoles2) {
		getUserRoles2().remove(userRoles2);
		userRoles2.setUser2(null);

		return userRoles2;
	}

	public Set<UserEmail> getUserEmails() {
		return this.userEmails;
	}

	public void setUserEmails(Set<UserEmail> userEmails) {
		this.userEmails = userEmails;
	}

	public UserEmail addUserEmail(UserEmail userEmail) {
		getUserEmails().add(userEmail);
		userEmail.setUser(this);

		return userEmail;
	}

	public UserEmail removeUserEmail(UserEmail userEmail) {
		getUserEmails().remove(userEmail);
		userEmail.setUser(null);

		return userEmail;
	}

	public String getlAuctnCentr() {
		return lAuctnCentr;
	}

	public void setlAuctnCentr(String lAuctnCentr) {
		this.lAuctnCentr = lAuctnCentr;
	}
}