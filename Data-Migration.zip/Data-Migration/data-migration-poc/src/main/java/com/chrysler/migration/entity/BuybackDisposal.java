package com.chrysler.migration.entity;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MapsId;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.LazyToOne;
import org.hibernate.annotations.LazyToOneOption;

/**
 * The persistent class for the BUYBACK_DISPOSAL database table.
 * 
 */
@Entity
@Table(name = "BYBK_DSPSL")
@NamedQuery(name = "BuybackDisposal.findAll", query = "SELECT b FROM BuybackDisposal b")
public class BuybackDisposal extends AuditColumns implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private int iBybk;

	@Column(name = "C_DSPSL_ZIP")
	private String cDspslZip;

	@Column(name = "I_DSPSL_PH")
	private String iDspslPh;

	@Column(name = "I_DSPSL_TI")
	private String iDspslTi;

	@Column(name = "L_BRND_REQD")
	private String lBrndReqd;

	@Column(name = "L_MULTI_ATTMPT")
	private String lMultiAttmpt;

	@Column(name = "L_NON_CONFMN")
	private String lNonConfmn;

	@Column(name = "L_PRIOR_DAM")
	private String lPriorDam;

	@Column(name = "L_VHCL_OUT_SERV")
	private String lVhclOutServ;

	@Column(name = "N_DSPSL_CITY")
	private String nDspslCity;

	@Column(name = "N_DSPSL_CNTCT")
	private String nDspslCntct;

	@Column(name = "Q_NMBR_DAYS")
	private Integer qNmbrDays;

	@Column(name = "X_COST_REP_DESC")
	private String xCostRepDesc;

	@Column(name = "X_DSPSL_LINE_1")
	private String xDspslLine1;

	@Column(name = "X_DSPSL_LINE_2")
	private String xDspslLine2;

	@Column(name = "L_VHCL_LOC_TYP")
	private String lVhclLocTyp;

	@Column(name = "N_VHCL_LOC")
	private String nVhclLoc;

	@Column(name = "D_DSPSL_APRVL")
	public Timestamp dDspspAprvl;

	@Column(name = "I_DSPSL_APRVL_BY")
	private String iDspslAprvlBy;

	@Column(name = "L_DSPSL_APRVL")
	private String lDspslAprvl;

	// bi-directional one-to-one association to Buyback
	@OneToOne(fetch = FetchType.LAZY)
	@MapsId
	@LazyToOne(LazyToOneOption.NO_PROXY)
	@JoinColumn(name = "I_BYBK")
	private Buyback buyback;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_DSPSL_TYP")
	private CodeMaster disposalType;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_DSPSL_STAT")
	private CodeMaster disposalStatus;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_DSPSL_TI_STATE")
	private CodeMaster titleState;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_DSPSL_STATE")
	private CodeMaster disposalState;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "C_ASSGN_AUCTN", referencedColumnName = "C_AUCTN_CENTR")
	private AuctionDetail assgnAuction;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "C_CSGND_AUCTN", referencedColumnName = "C_AUCTN_CENTR")
	private AuctionDetail csgndAuction;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "C_INV_AUCTN", referencedColumnName = "C_AUCTN_CENTR")
	private AuctionDetail invAuction;

	@Column(name = "D_ASSGN_AUCTN")
	public Timestamp dAssgnAuctn;

	@Column(name = "I_AUCTN_BY")
	private String iAuctnBy;

	@Column(name = "D_DLR_PUR")
	public Timestamp dDlrPur;

	@Column(name = "N_DLR_PUR_BY")
	private String nDlrPurBy;

	@Column(name = "L_DLR_SIGN_DISCLSR")
	private String lDlrSignDisclsr;

	@Column(name = "L_CUST_SIGN_DISCLSR")
	private String lCustSignDisclsr;

	public BuybackDisposal() {
	}

	public Integer getIBybk() {
		return this.iBybk;
	}

	public void setIBybk(Integer iBybk) {
		this.iBybk = iBybk;
	}

	public String getCDspslZip() {
		return this.cDspslZip;
	}

	public void setCDspslZip(String cDspslZip) {
		this.cDspslZip = cDspslZip;
	}

	public String getIDspslPh() {
		return this.iDspslPh;
	}

	public void setIDspslPh(String iDspslPh) {
		this.iDspslPh = iDspslPh;
	}

	public String getIDspslTi() {
		return this.iDspslTi;
	}

	public void setIDspslTi(String iDspslTi) {
		this.iDspslTi = iDspslTi;
	}

	public String getLBrndReqd() {
		return this.lBrndReqd;
	}

	public void setLBrndReqd(String lBrndReqd) {
		this.lBrndReqd = lBrndReqd;
	}

	public String getLMultiAttmpt() {
		return this.lMultiAttmpt;
	}

	public void setLMultiAttmpt(String lMultiAttmpt) {
		this.lMultiAttmpt = lMultiAttmpt;
	}

	public String getLNonConfmn() {
		return this.lNonConfmn;
	}

	public void setLNonConfmn(String lNonConfmn) {
		this.lNonConfmn = lNonConfmn;
	}

	public String getLPriorDam() {
		return this.lPriorDam;
	}

	public void setLPriorDam(String lPriorDam) {
		this.lPriorDam = lPriorDam;
	}

	public String getLVhclOutServ() {
		return this.lVhclOutServ;
	}

	public void setLVhclOutServ(String lVhclOutServ) {
		this.lVhclOutServ = lVhclOutServ;
	}

	public String getNDspslCity() {
		return this.nDspslCity;
	}

	public void setNDspslCity(String nDspslCity) {
		this.nDspslCity = nDspslCity;
	}

	public String getNDspslCntct() {
		return this.nDspslCntct;
	}

	public void setNDspslCntct(String nDspslCntct) {
		this.nDspslCntct = nDspslCntct;
	}

	public Integer getQNmbrDays() {
		return this.qNmbrDays;
	}

	public void setQNmbrDays(Integer qNmbrDays) {
		this.qNmbrDays = qNmbrDays;
	}

	public String getXCostRepDesc() {
		return this.xCostRepDesc;
	}

	public void setXCostRepDesc(String xCostRepDesc) {
		this.xCostRepDesc = xCostRepDesc;
	}

	public String getXDspslLine1() {
		return this.xDspslLine1;
	}

	public void setXDspslLine1(String xDspslLine1) {
		this.xDspslLine1 = xDspslLine1;
	}

	public String getXDspslLine2() {
		return this.xDspslLine2;
	}

	public void setXDspslLine2(String xDspslLine2) {
		this.xDspslLine2 = xDspslLine2;
	}

	public Buyback getBuyback() {
		return this.buyback;
	}

	public void setBuyback(Buyback buyback) {
		this.buyback = buyback;
	}

	public CodeMaster getDisposalType() {
		return this.disposalType;
	}

	public void setDisposalType(CodeMaster disposalType) {
		this.disposalType = disposalType;
	}

	public CodeMaster getDisposalStatus() {
		return this.disposalStatus;
	}

	public void setDisposalStatus(CodeMaster disposalStatus) {
		this.disposalStatus = disposalStatus;
	}

	public CodeMaster getTitleState() {
		return this.titleState;
	}

	public void setTitleState(CodeMaster titleState) {
		this.titleState = titleState;
	}

	public CodeMaster getDisposalState() {
		return this.disposalState;
	}

	public void setDisposalState(CodeMaster disposalState) {
		this.disposalState = disposalState;
	}

	public AuctionDetail getAssgnAuction() {
		return assgnAuction;
	}

	public void setAssgnAuction(AuctionDetail assgnAuction) {
		this.assgnAuction = assgnAuction;
	}

	public AuctionDetail getCsgndAuction() {
		return csgndAuction;
	}

	public void setCsgndAuction(AuctionDetail csgndAuction) {
		this.csgndAuction = csgndAuction;
	}

	public AuctionDetail getInvAuction() {
		return invAuction;
	}

	public void setInvAuction(AuctionDetail invAuction) {
		this.invAuction = invAuction;
	}

	public Timestamp getdAssgnAuctn() {
		return dAssgnAuctn;
	}

	public void setdAssgnAuctn(Timestamp dAssgnAuctn) {
		this.dAssgnAuctn = dAssgnAuctn;
	}

	public String getiAuctnBy() {
		return iAuctnBy;
	}

	public void setiAuctnBy(String iAuctnBy) {
		this.iAuctnBy = iAuctnBy;
	}

	public Timestamp getdDlrPur() {
		return dDlrPur;
	}

	public void setdDlrPur(Timestamp dDlrPur) {
		this.dDlrPur = dDlrPur;
	}

	public String getnDlrPurBy() {
		return nDlrPurBy;
	}

	public void setnDlrPurBy(String nDlrPurBy) {
		this.nDlrPurBy = nDlrPurBy;
	}

	public String getlDlrSignDisclsr() {
		return lDlrSignDisclsr;
	}

	public void setlDlrSignDisclsr(String lDlrSignDisclsr) {
		this.lDlrSignDisclsr = lDlrSignDisclsr;
	}

	public String getlCustSignDisclsr() {
		return lCustSignDisclsr;
	}

	public void setlCustSignDisclsr(String lCustSignDisclsr) {
		this.lCustSignDisclsr = lCustSignDisclsr;
	}

	public String getlVhclLocTyp() {
		return lVhclLocTyp;
	}

	public void setlVhclLocTyp(String lVhclLocTyp) {
		this.lVhclLocTyp = lVhclLocTyp;
	}

	public String getnVhclLoc() {
		return nVhclLoc;
	}

	public void setnVhclLoc(String nVhclLoc) {
		this.nVhclLoc = nVhclLoc;
	}

	public Timestamp getdDspspAprvl() {
		return dDspspAprvl;
	}

	public void setdDspspAprvl(Timestamp dDspspAprvl) {
		this.dDspspAprvl = dDspspAprvl;
	}

	public String getiDspslAprvlBy() {
		return iDspslAprvlBy;
	}

	public void setiDspslAprvlBy(String iDspslAprvlBy) {
		this.iDspslAprvlBy = iDspslAprvlBy;
	}

	public String getlDspslAprvl() {
		return lDspslAprvl;
	}

	public void setlDspslAprvl(String lDspslAprvl) {
		this.lDspslAprvl = lDspslAprvl;
	}

}