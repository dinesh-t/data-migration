package com.chrysler.migration.entity;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * The persistent class for the AUDIT_TRAIL_FUNCTION database table.
 * 
 */
@Entity
@Table(name = "AUDIT_TRAIL_FUNCTION")
@NamedQuery(name = "AuditTrailFunction.findAll", query = "SELECT a FROM AuditTrailFunction a")
public class AuditTrailFunction extends AuditColumns implements Serializable, Cloneable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "I_AUD_FUNC_SEQ")
	private Integer iAudFuncSeq;

	@Column(name = "X_AUD_FUNC_COMNT")
	private String xAudFuncComnt;

	// bi-directional many-to-one association to auditTrailField
	@OneToMany(mappedBy = "auditTrailFunction", cascade = CascadeType.ALL)
	private Set<AuditTrailField> auditTrailFields;

	// bi-directional many-to-one association to Buyback
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_BYBK")
	private Buyback buyback;

	// bi-directional many-to-one association to Buyback
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_NON_BYBK")
	private DisclsrNonBybk disclsrNonBybk;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_OPER")
	private CodeMaster screenOperation;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_AUD_FUNC_STAT")
	private CodeMaster iAuditFuncStat;

	@Column(name = "N_USER")
	private String nUser;

	public Integer getIAudFuncSeq() {
		return this.iAudFuncSeq;
	}

	public void setIAudFuncSeq(Integer iAudFuncSeq) {
		this.iAudFuncSeq = iAudFuncSeq;
	}

	public String getXAudFuncComnt() {
		return this.xAudFuncComnt;
	}

	public void setXAudFuncComnt(String xAudFuncComnt) {
		this.xAudFuncComnt = xAudFuncComnt;
	}

	public Set<AuditTrailField> getAuditTrailFields() {
		return this.auditTrailFields;
	}

	public void setAuditTrailFields(Set<AuditTrailField> auditTrailFields) {
		this.auditTrailFields = auditTrailFields;
	}

	public AuditTrailField addAuditTrailField(AuditTrailField auditTrailField) {
		getAuditTrailFields().add(auditTrailField);
		auditTrailField.setAuditTrailFunction(this);

		return auditTrailField;
	}

	public AuditTrailField removeAuditTrailField(AuditTrailField auditTrailField) {
		getAuditTrailFields().remove(auditTrailField);
		auditTrailField.setAuditTrailFunction(null);

		return auditTrailField;
	}

	public Buyback getBuyback() {
		return this.buyback;
	}

	public void setBuyback(Buyback buyback) {
		this.buyback = buyback;
	}

	public CodeMaster getScreenOperation() {
		return screenOperation;
	}

	public void setScreenOperation(CodeMaster screenOperation) {
		this.screenOperation = screenOperation;
	}

	public CodeMaster getiAuditFuncStat() {
		return iAuditFuncStat;
	}

	public void setiAuditFuncStat(CodeMaster iAuditFuncStat) {
		this.iAuditFuncStat = iAuditFuncStat;
	}

	public String getnUser() {
		return nUser;
	}

	public void setnUser(String nUser) {
		this.nUser = nUser;
	}

	@Override
	public Object clone() {
		AuditTrailFunction clonedObject = new AuditTrailFunction();
		clonedObject.setAuditTrailFields(this.auditTrailFields);
		clonedObject.setBuyback(this.buyback);
		clonedObject.setiAuditFuncStat(this.iAuditFuncStat);
		clonedObject.setiLogon(this.getiLogon());
		clonedObject.setiLogonUpd(this.iLogonUpd);
		clonedObject.settStmpAdd(this.gettStmpAdd());
		clonedObject.settStmpUpd(this.gettStmpUpd());
		clonedObject.setXAudFuncComnt(this.xAudFuncComnt);
		clonedObject.setnUser(this.nUser);
		return clonedObject;

	}

}
