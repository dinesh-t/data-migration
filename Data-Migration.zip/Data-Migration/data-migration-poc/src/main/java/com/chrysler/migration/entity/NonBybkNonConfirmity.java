package com.chrysler.migration.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * The persistent class for the NON_BYBK_NON_CONFIRMITY database table.
 * 
 */
@Entity
@Table(name = "NON_BYBK_NON_CONFIRMITY")
@NamedQuery(name = "NonBybkNonConfirmity.findAll", query = "SELECT n FROM NonBybkNonConfirmity n")
public class NonBybkNonConfirmity extends AuditColumns implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "I_NON_CONF_SEQ")
	private int iNonConfSeq;

	@Column(name = "X_NON_CONF")
	private String xNonConf;

	@Column(name = "X_OTHR_COMNT")
	private String xOthrComnt;

	// bi-directional many-to-one association to DisclsrNonBybk
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_NON_BYBK")
	private DisclsrNonBybk disclsrNonBybk;

	public NonBybkNonConfirmity() {
		//
	}

	public int getINonConfSeq() {
		return this.iNonConfSeq;
	}

	public void setINonConfSeq(int iNonConfSeq) {
		this.iNonConfSeq = iNonConfSeq;
	}

	public String getXNonConf() {
		return this.xNonConf;
	}

	public void setXNonConf(String xNonConf) {
		this.xNonConf = xNonConf;
	}

	public String getXOthrComnt() {
		return this.xOthrComnt;
	}

	public void setXOthrComnt(String xOthrComnt) {
		this.xOthrComnt = xOthrComnt;
	}

	public DisclsrNonBybk getDisclsrNonBybk() {
		return this.disclsrNonBybk;
	}

	public void setDisclsrNonBybk(DisclsrNonBybk disclsrNonBybk) {
		this.disclsrNonBybk = disclsrNonBybk;
	}

}