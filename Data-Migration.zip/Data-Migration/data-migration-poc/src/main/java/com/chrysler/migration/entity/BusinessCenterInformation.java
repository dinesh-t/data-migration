package com.chrysler.migration.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MapsId;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.LazyToOne;
import org.hibernate.annotations.LazyToOneOption;

/**
 * The persistent class for the BUSINESS_CENTER_INFORMATION database table.
 * 
 */
@Entity
@Table(name = "BYBK_BUS_CENTR_INFO")
@NamedQuery(name = "BusinessCenterInformation.findAll", query = "SELECT b FROM BusinessCenterInformation b")
public class BusinessCenterInformation extends AuditColumns implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private Integer iBybk;

	@Column(name = "C_BUS_CENTR_DLR")
	private Integer cBusCentrDlr;

	@Column(name = "I_DECN_MKR")
	private String iDecnMkr;

	@Column(name = "I_DECN_MKR_PH")
	private String iDecnMkrPh;

	@Column(name = "N_DECN_MKR")
	private String nDecnMkr;

	@Column(name = "X_BUS_CENTR_COMNT")
	private String xBusCentrComnt;

	@Column(name = "X_EMAIL_ADDR")
	private String xEmailAddr;

	// bi-directional one-to-one association to Buyback
	@OneToOne(fetch = FetchType.LAZY)
	@MapsId
	@LazyToOne(LazyToOneOption.NO_PROXY)
	@JoinColumn(name = "I_BYBK")
	private Buyback buyback;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_BUS_CENTR")
	private CodeMaster codeMaster1;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_BUS_CENTR_DIST")
	private CodeMaster codeMaster2;

	public BusinessCenterInformation() {
		//
	}

	public Integer getIBybk() {
		return this.iBybk;
	}

	public void setIBybk(Integer iBybk) {
		this.iBybk = iBybk;
	}

	public Integer getCBusCentrDlr() {
		return this.cBusCentrDlr;
	}

	public void setCBusCentrDlr(Integer cBusCentrDlr) {
		this.cBusCentrDlr = cBusCentrDlr;
	}

	public String getIDecnMkr() {
		return this.iDecnMkr;
	}

	public void setIDecnMkr(String iDecnMkr) {
		this.iDecnMkr = iDecnMkr;
	}

	public String getIDecnMkrPh() {
		return this.iDecnMkrPh;
	}

	public void setIDecnMkrPh(String iDecnMkrPh) {
		this.iDecnMkrPh = iDecnMkrPh;
	}

	public String getNDecnMkr() {
		return this.nDecnMkr;
	}

	public void setNDecnMkr(String nDecnMkr) {
		this.nDecnMkr = nDecnMkr;
	}

	public String getXBusCentrComnt() {
		return this.xBusCentrComnt;
	}

	public void setXBusCentrComnt(String xBusCentrComnt) {
		this.xBusCentrComnt = xBusCentrComnt;
	}

	public String getXEmailAddr() {
		return this.xEmailAddr;
	}

	public void setXEmailAddr(String xEmailAddr) {
		this.xEmailAddr = xEmailAddr;
	}

	public Buyback getBuyback() {
		return this.buyback;
	}

	public void setBuyback(Buyback buyback) {
		this.buyback = buyback;
	}

	public CodeMaster getCodeMaster1() {
		return this.codeMaster1;
	}

	public void setCodeMaster1(CodeMaster codeMaster1) {
		this.codeMaster1 = codeMaster1;
	}

	public CodeMaster getCodeMaster2() {
		return this.codeMaster2;
	}

	public void setCodeMaster2(CodeMaster codeMaster2) {
		this.codeMaster2 = codeMaster2;
	}

}