package com.chrysler.migration.entity;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * The persistent class for the DASH_BD_SRCH database table.
 * 
 */
@Entity
@Table(name = "DASH_BD_SRCH")
@NamedQuery(name = "DashBdSrch.findAll", query = "SELECT d FROM DashBdSrch d")
public class DashBdSrch extends AuditColumns implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "I_DASH_BD_SRCH_SEQ")
	private int iDashBdSrchSeq;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne
	@JoinColumn(name = "I_SRCH_NAME")
	private CodeMaster searchName;

	// bi-directional many-to-one association to DashBd
	@ManyToOne
	@JoinColumn(name = "I_DASH_BD")
	private DashBd dashBd;

	// bi-directional many-to-one association to Role
	@ManyToOne
	@JoinColumn(name = "I_ROLE")
	private Role role;

	// bi-directional many-to-one association to DashBdSrchUserMapg
	@OneToMany(mappedBy = "dashBdSrch")
	private List<DashBdSrchUserMapg> dashBdSrchUserMapgs;

	public DashBdSrch() {
	}

	public int getIDashBdSrchSeq() {
		return this.iDashBdSrchSeq;
	}

	public void setIDashBdSrchSeq(int iDashBdSrchSeq) {
		this.iDashBdSrchSeq = iDashBdSrchSeq;
	}

	public CodeMaster getSearchName() {
		return searchName;
	}

	public void setSearchName(CodeMaster searchName) {
		this.searchName = searchName;
	}

	public DashBd getDashBd() {
		return this.dashBd;
	}

	public void setDashBd(DashBd dashBd) {
		this.dashBd = dashBd;
	}

	public Role getRole() {
		return this.role;
	}

	public void setRole(Role role) {
		this.role = role;
	}

	public List<DashBdSrchUserMapg> getDashBdSrchUserMapgs() {
		return this.dashBdSrchUserMapgs;
	}

	public void setDashBdSrchUserMapgs(List<DashBdSrchUserMapg> dashBdSrchUserMapgs) {
		this.dashBdSrchUserMapgs = dashBdSrchUserMapgs;
	}

	public DashBdSrchUserMapg addDashBdSrchUserMapg(DashBdSrchUserMapg dashBdSrchUserMapg) {
		getDashBdSrchUserMapgs().add(dashBdSrchUserMapg);
		dashBdSrchUserMapg.setDashBdSrch(this);

		return dashBdSrchUserMapg;
	}

	public DashBdSrchUserMapg removeDashBdSrchUserMapg(DashBdSrchUserMapg dashBdSrchUserMapg) {
		getDashBdSrchUserMapgs().remove(dashBdSrchUserMapg);
		dashBdSrchUserMapg.setDashBdSrch(null);

		return dashBdSrchUserMapg;
	}

}