package com.chrysler.migration.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * The persistent class for the PACKAGE_DISPOSAL_DOCU database table.
 * 
 */
@Entity
@Table(name = "PKG_DSPSL_DOCU")
@NamedQuery(name = "PackageDisposalDocu.findAll", query = "SELECT p FROM PackageDisposalDocu p")
public class PackageDisposalDocu extends AuditColumns implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "I_DOCU_SEQ")
	private Integer iDocuSeq;

	@Column(name = "I_DOCU")
	private Integer iDocu;

	@Column(name = "N_OTHR_DOCU")
	private String nOthrDocu;

	@Column(name = "X_DOCU_LNK")
	private String xDocuLnk;

	// bi-directional many-to-one association to Buyback
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_BYBK")
	private Buyback bybk;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_DOCU_REF")
	private CodeMaster docuRefCode;

	public PackageDisposalDocu() {
		//
	}

	public Integer getIDocuSeq() {
		return this.iDocuSeq;
	}

	public void setIDocuSeq(Integer iDocuSeq) {
		this.iDocuSeq = iDocuSeq;
	}

	public Integer getIDocu() {
		return this.iDocu;
	}

	public void setIDocu(Integer iDocu) {
		this.iDocu = iDocu;
	}

	public String getNOthrDocu() {
		return this.nOthrDocu;
	}

	public void setNOthrDocu(String nOthrDocu) {
		this.nOthrDocu = nOthrDocu;
	}

	public String getXDocuLnk() {
		return this.xDocuLnk;
	}

	public void setXDocuLnk(String xDocuLnk) {
		this.xDocuLnk = xDocuLnk;
	}

	public Buyback getBuyback() {
		return this.bybk;
	}

	public void setBuyback(Buyback bybk) {
		this.bybk = bybk;
	}

	public CodeMaster getDocuRefCode() {
		return this.docuRefCode;
	}

	public void setDocuRefCode(CodeMaster codeMaster) {
		this.docuRefCode = codeMaster;
	}

}