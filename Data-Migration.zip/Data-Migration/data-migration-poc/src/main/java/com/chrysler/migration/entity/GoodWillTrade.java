package com.chrysler.migration.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MapsId;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.LazyToOne;
import org.hibernate.annotations.LazyToOneOption;

/**
 * The persistent class for the GOOD_WILL_TRADE database table.
 * 
 */
@Entity
@Table(name = "GOOD_WILL_TRADE")
@NamedQuery(name = "GoodWillTrade.findAll", query = "SELECT g FROM GoodWillTrade g")
public class GoodWillTrade extends AuditColumns implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private Integer iBybk;

	@Column(name = "A_CERTIF")
	private BigDecimal aCertif;

	@Column(name = "A_FINAL_PAYMT_APRVD")
	private BigDecimal aFinalPaymtAprvd;

	@Column(name = "A_INIT_PAYMT_APRVD")
	private BigDecimal aInitPaymtAprvd;

	@Column(name = "I_NEW_VHCL_MY")
	private Integer iNewVhclMy;

	@Column(name = "I_NEW_VHCL_ORDR")
	private Integer iNewVhclOrdr;

	@Column(name = "I_NEW_VHCL_VIN")
	private String iNewVhclVin;

	@Column(name = "I_REP_ORDR")
	private String iRepOrdr;

	@Column(name = "L_CERTIF_RECVD")
	private String lCertifRecvd;

	@Column(name = "L_DISCLSR_RECVD")
	private String lDisclsrRecvd;

	@Column(name = "L_LEMON_LAW")
	private String lLemonLaw;

	@Column(name = "L_VHCL_REP")
	private String lVhclRep;

	@Column(name = "N_NEW_VHCL_MAKE")
	private String nNewVhclMake;

	@Column(name = "N_NEW_VHCL_MOD")
	private String nNewVhclMod;

	@Column(name = "Q_DAYS_DOWN")
	private Integer qDaysDown;

	@Column(name = "Q_VHCL_REP")
	private Integer qVhclRep;

	@Column(name = "T_FINAL_APRVD")
	private Timestamp tFinalAprvd;

	@Column(name = "T_FINAL_CHECK")
	private Timestamp tFinalCheck;

	@Column(name = "T_FINAL_PAYMT")
	private Timestamp tFinalPaymt;

	@Column(name = "T_INIT_APRVD")
	private Timestamp tInitAprvd;

	@Column(name = "T_INIT_CHECK")
	private Timestamp tInitCheck;

	@Column(name = "T_INIT_PAYMT")
	private Timestamp tInitPaymt;

	@Column(name = "T_NEW_IN_SERV")
	private Timestamp tNewInServ;

	@Column(name = "T_VHCL_REP")
	private Timestamp tVhclRep;

	@Column(name = "X_CUST_PROB_DESC")
	private String xCustProbDesc;

	@Column(name = "X_FINAL_CHECK_DTL")
	private String xFinalCheckDtl;

	@Column(name = "X_INIT_CHECK_DTL")
	private String xInitCheckDtl;

	@Column(name = "X_REP_COMNT")
	private String xRepComnt;

	@Column(name = "X_REP_DESC")
	private String xRepDesc;

	// bi-directional one-to-one association to Buyback
	@OneToOne(fetch = FetchType.LAZY)
	@MapsId
	@LazyToOne(LazyToOneOption.NO_PROXY)
	@JoinColumn(name = "I_BYBK")
	private Buyback buyback;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_GOOD_TRD_STAT")
	private CodeMaster goodwillStatusCode;

	public GoodWillTrade() {
		//
	}

	public Integer getIBybk() {
		return this.iBybk;
	}

	public void setIBybk(Integer iBybk) {
		this.iBybk = iBybk;
	}

	public BigDecimal getACertif() {
		return this.aCertif;
	}

	public void setACertif(BigDecimal aCertif) {
		this.aCertif = aCertif;
	}

	public BigDecimal getAFinalPaymtAprvd() {
		return this.aFinalPaymtAprvd;
	}

	public void setAFinalPaymtAprvd(BigDecimal aFinalPaymtAprvd) {
		this.aFinalPaymtAprvd = aFinalPaymtAprvd;
	}

	public BigDecimal getAInitPaymtAprvd() {
		return this.aInitPaymtAprvd;
	}

	public void setAInitPaymtAprvd(BigDecimal aInitPaymtAprvd) {
		this.aInitPaymtAprvd = aInitPaymtAprvd;
	}

	public Integer getINewVhclMy() {
		return this.iNewVhclMy;
	}

	public void setINewVhclMy(Integer iNewVhclMy) {
		this.iNewVhclMy = iNewVhclMy;
	}

	public Integer getINewVhclOrdr() {
		return this.iNewVhclOrdr;
	}

	public void setINewVhclOrdr(Integer iNewVhclOrdr) {
		this.iNewVhclOrdr = iNewVhclOrdr;
	}

	public String getINewVhclVin() {
		return this.iNewVhclVin;
	}

	public void setINewVhclVin(String iNewVhclVin) {
		this.iNewVhclVin = iNewVhclVin;
	}

	public String getIRepOrdr() {
		return this.iRepOrdr;
	}

	public void setIRepOrdr(String iRepOrdr) {
		this.iRepOrdr = iRepOrdr;
	}

	public String getLCertifRecvd() {
		return this.lCertifRecvd;
	}

	public void setLCertifRecvd(String lCertifRecvd) {
		this.lCertifRecvd = lCertifRecvd;
	}

	public String getLDisclsrRecvd() {
		return this.lDisclsrRecvd;
	}

	public void setLDisclsrRecvd(String lDisclsrRecvd) {
		this.lDisclsrRecvd = lDisclsrRecvd;
	}

	public String getLLemonLaw() {
		return this.lLemonLaw;
	}

	public void setLLemonLaw(String lLemonLaw) {
		this.lLemonLaw = lLemonLaw;
	}

	public String getLVhclRep() {
		return this.lVhclRep;
	}

	public void setLVhclRep(String lVhclRep) {
		this.lVhclRep = lVhclRep;
	}

	public String getNNewVhclMake() {
		return this.nNewVhclMake;
	}

	public void setNNewVhclMake(String nNewVhclMake) {
		this.nNewVhclMake = nNewVhclMake;
	}

	public String getNNewVhclMod() {
		return this.nNewVhclMod;
	}

	public void setNNewVhclMod(String nNewVhclMod) {
		this.nNewVhclMod = nNewVhclMod;
	}

	public Integer getQDaysDown() {
		return this.qDaysDown;
	}

	public void setQDaysDown(Integer qDaysDown) {
		this.qDaysDown = qDaysDown;
	}

	public Integer getQVhclRep() {
		return this.qVhclRep;
	}

	public void setQVhclRep(Integer qVhclRep) {
		this.qVhclRep = qVhclRep;
	}

	public Timestamp getTFinalAprvd() {
		return this.tFinalAprvd;
	}

	public void setTFinalAprvd(Timestamp tFinalAprvd) {
		this.tFinalAprvd = tFinalAprvd;
	}

	public Timestamp getTFinalCheck() {
		return this.tFinalCheck;
	}

	public void setTFinalCheck(Timestamp tFinalCheck) {
		this.tFinalCheck = tFinalCheck;
	}

	public Timestamp getTFinalPaymt() {
		return this.tFinalPaymt;
	}

	public void setTFinalPaymt(Timestamp tFinalPaymt) {
		this.tFinalPaymt = tFinalPaymt;
	}

	public Timestamp getTInitAprvd() {
		return this.tInitAprvd;
	}

	public void setTInitAprvd(Timestamp tInitAprvd) {
		this.tInitAprvd = tInitAprvd;
	}

	public Timestamp getTInitCheck() {
		return this.tInitCheck;
	}

	public void setTInitCheck(Timestamp tInitCheck) {
		this.tInitCheck = tInitCheck;
	}

	public Timestamp getTInitPaymt() {
		return this.tInitPaymt;
	}

	public void setTInitPaymt(Timestamp tInitPaymt) {
		this.tInitPaymt = tInitPaymt;
	}

	public Timestamp getTNewInServ() {
		return this.tNewInServ;
	}

	public void setTNewInServ(Timestamp tNewInServ) {
		this.tNewInServ = tNewInServ;
	}

	public Timestamp getTVhclRep() {
		return this.tVhclRep;
	}

	public void setTVhclRep(Timestamp tVhclRep) {
		this.tVhclRep = tVhclRep;
	}

	public String getXCustProbDesc() {
		return this.xCustProbDesc;
	}

	public void setXCustProbDesc(String xCustProbDesc) {
		this.xCustProbDesc = xCustProbDesc;
	}

	public String getXFinalCheckDtl() {
		return this.xFinalCheckDtl;
	}

	public void setXFinalCheckDtl(String xFinalCheckDtl) {
		this.xFinalCheckDtl = xFinalCheckDtl;
	}

	public String getXInitCheckDtl() {
		return this.xInitCheckDtl;
	}

	public void setXInitCheckDtl(String xInitCheckDtl) {
		this.xInitCheckDtl = xInitCheckDtl;
	}

	public String getXRepComnt() {
		return this.xRepComnt;
	}

	public void setXRepComnt(String xRepComnt) {
		this.xRepComnt = xRepComnt;
	}

	public String getXRepDesc() {
		return this.xRepDesc;
	}

	public void setXRepDesc(String xRepDesc) {
		this.xRepDesc = xRepDesc;
	}

	public Buyback getBuyback() {
		return this.buyback;
	}

	public void setBuyback(Buyback buyback) {
		this.buyback = buyback;
	}

	public CodeMaster getGoodwillStatusCode() {
		return goodwillStatusCode;
	}

	public void setGoodwillStatusCode(CodeMaster goodwillStatusCode) {
		this.goodwillStatusCode = goodwillStatusCode;
	}

}
