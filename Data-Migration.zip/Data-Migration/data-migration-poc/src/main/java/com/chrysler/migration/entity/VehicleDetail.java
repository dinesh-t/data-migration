package com.chrysler.migration.entity;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.MapsId;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.LazyToOne;
import org.hibernate.annotations.LazyToOneOption;

/**
 * The persistent class for the VEHICLE_DETAIL database table.
 * 
 */
@Entity
@Table(name = "VEHICLE_DETAIL")
@NamedQuery(name = "VehicleDetail.findAll", query = "SELECT v FROM VehicleDetail v")
public class VehicleDetail extends AuditColumns implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private Integer iBybk;

	@Column(name = "I_BYBK_VIN")
	private String iBybkVin;

	@Column(name = "I_VHCL_MY")
	private Integer iVhclMy;

	@Column(name = "N_VHCL_MAKE")
	private String nVhclMake;

	@Column(name = "N_VHCL_MOD")
	private String nVhclMod;

	@Column(name = "C_VHCL_MOD")
	private String cVhclMod;

	@Column(name = "T_VHCL_IN_SERV")
	private Timestamp tVhclInServ;

	@Column(name = "X_VHCL_MAKE_DESC")
	private String xVhclMakeDesc;

	@Column(name = "C_EMISS")
	private String cEmiss;

	@Column(name = "X_EMISS_DESC")
	private String xEmissDesc;

	// bi-directional one-to-one association to Buyback
	@OneToOne(fetch = FetchType.LAZY)
	@MapsId
	@LazyToOne(LazyToOneOption.NO_PROXY)
	@JoinColumn(name = "I_BYBK")
	private Buyback buyback;

	public VehicleDetail() {
		//
	}

	public Integer getIBybk() {
		return this.iBybk;
	}

	public void setIBybk(Integer iBybk) {
		this.iBybk = iBybk;
	}

	public String getIBybkVin() {
		return this.iBybkVin;
	}

	public void setIBybkVin(String iBybkVin) {
		this.iBybkVin = iBybkVin;
	}

	public int getIVhclMy() {
		return this.iVhclMy;
	}

	public void setIVhclMy(int iVhclMy) {
		this.iVhclMy = iVhclMy;
	}

	public String getNVhclMake() {
		return this.nVhclMake;
	}

	public void setNVhclMake(String nVhclMake) {
		this.nVhclMake = nVhclMake;
	}

	public String getNVhclMod() {
		return this.nVhclMod;
	}

	public void setNVhclMod(String nVhclMod) {
		this.nVhclMod = nVhclMod;
	}

	public Timestamp getTVhclInServ() {
		return this.tVhclInServ;
	}

	public void setTVhclInServ(Timestamp tVhclInServ) {
		this.tVhclInServ = tVhclInServ;
	}

	public String getXVhclMakeDesc() {
		return this.xVhclMakeDesc;
	}

	public void setXVhclMakeDesc(String xVhclMakeDesc) {
		this.xVhclMakeDesc = xVhclMakeDesc;
	}

	public Buyback getBuyback() {
		return this.buyback;
	}

	public void setBuyback(Buyback buyback) {
		this.buyback = buyback;
	}

	public String getcVhclMod() {
		return cVhclMod;
	}

	public void setcVhclMod(String cVhclMod) {
		this.cVhclMod = cVhclMod;
	}

	public String getcEmiss() {
		return cEmiss;
	}

	public void setcEmiss(String cEmiss) {
		this.cEmiss = cEmiss;
	}

	public String getxEmissDesc() {
		return xEmissDesc;
	}

	public void setxEmissDesc(String xEmissDesc) {
		this.xEmissDesc = xEmissDesc;
	}

}