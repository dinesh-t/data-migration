package com.chrysler.migration.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.Cascade;

/**
 * The persistent class for the DISCLSR_NON_BYBK database table.
 * 
 */
@Entity
@Table(name = "DISCLSR_NON_BYBK")
@NamedQuery(name = "DisclsrNonBybk.findAll", query = "SELECT d FROM DisclsrNonBybk d")
public class DisclsrNonBybk extends AuditColumns implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "I_NON_BYBK_SEQ")
	private Integer iNonBybkSeq;

	@Column(name = "A_INTRST_APPROX")
	private BigDecimal aIntrstApprox;

	@Column(name = "A_REP")
	private BigDecimal aRep;

	@Column(name = "A_WARR")
	private BigDecimal aWarr;

	@Column(name = "C_EMISS")
	private String cEmiss;

	@Column(name = "C_VHCL_MOD")
	private String cVhclMod;

	@Temporal(TemporalType.DATE)
	@Column(name = "D_BLD")
	private Date dBld;

	@Temporal(TemporalType.DATE)
	@Column(name = "D_INTRST_ACTL_CPLN")
	private Date dIntrstActlCpln;

	@Column(name = "I_NON_BYBK_VIN")
	private String iNonBybkVin;

	@Column(name = "I_PH")
	private String iPh;

	@Column(name = "I_VHCL_MY")
	private Integer iVhclMy;

	@Column(name = "L_INTRST_OTHR")
	private String lIntrstOthr;

	@Column(name = "L_INTRST_REP_DAM")
	private String lIntrstRepDam;

	@Column(name = "L_INTRST_TRANSP")
	private String lIntrstTransp;

	@Column(name = "L_MAJ_DAM")
	private String lMajDam;

	@Column(name = "L_WARR_RSTRN")
	private String lWarrRstrn;

	@Column(name = "N_INTRST_OTHR")
	private String nIntrstOthr;

	@Column(name = "N_VHCL_MAKE")
	private String nVhclMake;

	@Column(name = "N_VHCL_MOD")
	private String nVhclMod;

	@Column(name = "Q_CURR_ODOM")
	private Integer qCurrOdom;

	@Column(name = "T_IN_SERV")
	private Timestamp tInServ;

	@Column(name = "X_ADDL_INFO")
	private String xAddlInfo;

	@Column(name = "X_CNTCT")
	private String xCntct;

	@Column(name = "X_BLK_COMNT_1")
	private String xBlkCmnt1;

	@Column(name = "X_BLK_COMNT_2")
	private String xBlkCmnt2;

	@Column(name = "X_BLK_COMNT_3")
	private String xBlkCmnt3;

	@Column(name = "X_INTRST_NRTV")
	private String xIntrstNrtv;

	@Column(name = "X_DESC_DAM")
	private String xDescDam;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_SUBMTD_BY")
	private User submittedBy;

	@Column(name = "X_REP")
	private String xRep;

	@Temporal(TemporalType.DATE)
	@Column(name = "D_SUBMTD")
	private Date datesubmitted;

	@Column(name = "X_LST_WARR_RSTRN")
	private String xLstWarrRstrn;

	// bi-directional many-to-one association to AuctionDetail
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "C_AUCTN_CENTR", referencedColumnName = "C_AUCTN_CENTR")
	private AuctionDetail cAuctnCentr;

	// bi-directional many-to-one association to AuctionDetail
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "C_VHCL_AUCTN", referencedColumnName = "C_AUCTN_CENTR")
	private AuctionDetail cVhclAuctn;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_VHCL_CATGY")
	private CodeMaster vehicleCategoryCode;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_BUS_CENTR")
	private CodeMaster businessCntrCode;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_DSPSL_TYP")
	private CodeMaster disposalType;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_DISCLSR_TYP")
	private CodeMaster disclosureType;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_DSPSL_STAT")
	private CodeMaster iDspslStat;

	// bi-directional one-to-one association to DealerDetail
	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "C_DLR")
	private DealerDetail dealerDetail;

	// bi-directional many-to-one association to DisclsrVehicleOwner
	@OneToMany(mappedBy = "disclsrNonBybk")
	private Set<DisclsrVehicleOwner> disclsrVehicleOwners;

	// bi-directional many-to-one association to NonBybkCnResaleState
	@OneToMany(mappedBy = "disclsrNonBybk", fetch = FetchType.LAZY, orphanRemoval = true)
	@Cascade({ org.hibernate.annotations.CascadeType.SAVE_UPDATE, org.hibernate.annotations.CascadeType.DELETE,
			org.hibernate.annotations.CascadeType.MERGE, org.hibernate.annotations.CascadeType.PERSIST })
	private Set<NonBybkCnResaleState> nonBybkCnResaleStates;

	// bi-directional many-to-one association to NonBybkNonConfirmity
	@OneToMany(mappedBy = "disclsrNonBybk", fetch = FetchType.LAZY, orphanRemoval = true)
	@Cascade({ org.hibernate.annotations.CascadeType.SAVE_UPDATE, org.hibernate.annotations.CascadeType.DELETE,
			org.hibernate.annotations.CascadeType.MERGE, org.hibernate.annotations.CascadeType.PERSIST })
	private Set<NonBybkNonConfirmity> nonBybkNonConfirmities;

	// bi-directional many-to-one association to NonBybkNonConfirmity
	@OneToMany(mappedBy = "disclsrNonBybk", fetch = FetchType.LAZY, orphanRemoval = true)
	@Cascade({ org.hibernate.annotations.CascadeType.SAVE_UPDATE, org.hibernate.annotations.CascadeType.DELETE,
			org.hibernate.annotations.CascadeType.MERGE, org.hibernate.annotations.CascadeType.PERSIST })
	private Set<AuditTrailFunction> auditTrailFunctions;

	// bi-directional many-to-one association to NonBybkNonConfirmity
	@OneToMany(mappedBy = "disclsrNonBybk", fetch = FetchType.LAZY, orphanRemoval = true)
	@Cascade({ org.hibernate.annotations.CascadeType.SAVE_UPDATE, org.hibernate.annotations.CascadeType.DELETE,
			org.hibernate.annotations.CascadeType.MERGE, org.hibernate.annotations.CascadeType.PERSIST })
	private Set<AuditTrailField> auditTrailFields;

	@Column(name = "C_SOLD_DLR")
	private String cSoldDlr;

	@Column(name = "N_SOLD_CUST")
	private String nSoldCust;

	@Column(name = "D_SOLD_DLR")
	private Timestamp dSoldDlr;

	@Column(name = "D_SOLD_CUST")
	private Timestamp dSoldCust;

	@Column(name = "D_ASSGN_AUCTN")
	private Timestamp dAssgnAuctn;

	@Column(name = "I_AUCTN_BY")
	private String iAuctnBy;

	@Column(name = "D_DLR_PUR")
	private Timestamp dDlrPur;

	@Column(name = "N_DLR_PUR_BY")
	private String nDlrPurBy;

	@Column(name = "L_DLR_SIGN_DISCLSR")
	private String lDlrSignDisclsr;

	@Column(name = "D_DLR_SIGN_DISCLSR")
	private Timestamp dDlrSignDisclsr;

	@Column(name = "L_CUST_SIGN_DISCLSR")
	private String lCustSignDisclsr;

	@Column(name = "D_CUST_SIGN_DISCLSR")
	private Timestamp dCustSignDisclsr;

	public DisclsrNonBybk() {
		//
	}

	public Integer getINonBybkSeq() {
		return this.iNonBybkSeq;
	}

	public void setINonBybkSeq(Integer iNonBybkSeq) {
		this.iNonBybkSeq = iNonBybkSeq;
	}

	public BigDecimal getAIntrstApprox() {
		return this.aIntrstApprox;
	}

	public void setAIntrstApprox(BigDecimal aIntrstApprox) {
		this.aIntrstApprox = aIntrstApprox;
	}

	public BigDecimal getARep() {
		return this.aRep;
	}

	public void setARep(BigDecimal aRep) {
		this.aRep = aRep;
	}

	public BigDecimal getAWarr() {
		return this.aWarr;
	}

	public void setAWarr(BigDecimal aWarr) {
		this.aWarr = aWarr;
	}

	public String getCEmiss() {
		return this.cEmiss;
	}

	public void setCEmiss(String cEmiss) {
		this.cEmiss = cEmiss;
	}

	public String getCVhclMod() {
		return this.cVhclMod;
	}

	public void setCVhclMod(String cVhclMod) {
		this.cVhclMod = cVhclMod;
	}

	public Date getDBld() {
		return this.dBld;
	}

	public void setDBld(Date dBld) {
		this.dBld = dBld;
	}

	public Date getDIntrstActlCpln() {
		return this.dIntrstActlCpln;
	}

	public void setDIntrstActlCpln(Date dIntrstActlCpln) {
		this.dIntrstActlCpln = dIntrstActlCpln;
	}

	public String getINonBybkVin() {
		return this.iNonBybkVin;
	}

	public void setINonBybkVin(String iNonBybkVin) {
		this.iNonBybkVin = iNonBybkVin;
	}

	public String getIPh() {
		return this.iPh;
	}

	public void setIPh(String iPh) {
		this.iPh = iPh;
	}

	public Integer getIVhclMy() {
		return this.iVhclMy;
	}

	public void setIVhclMy(Integer iVhclMy) {
		this.iVhclMy = iVhclMy;
	}

	public String getLIntrstOthr() {
		return this.lIntrstOthr;
	}

	public void setLIntrstOthr(String lIntrstOthr) {
		this.lIntrstOthr = lIntrstOthr;
	}

	public String getLIntrstRepDam() {
		return this.lIntrstRepDam;
	}

	public void setLIntrstRepDam(String lIntrstRepDam) {
		this.lIntrstRepDam = lIntrstRepDam;
	}

	public String getLIntrstTransp() {
		return this.lIntrstTransp;
	}

	public void setLIntrstTransp(String lIntrstTransp) {
		this.lIntrstTransp = lIntrstTransp;
	}

	public String getLMajDam() {
		return this.lMajDam;
	}

	public void setLMajDam(String lMajDam) {
		this.lMajDam = lMajDam;
	}

	public String getLWarrRstrn() {
		return this.lWarrRstrn;
	}

	public void setLWarrRstrn(String lWarrRstrn) {
		this.lWarrRstrn = lWarrRstrn;
	}

	public String getNIntrstOthr() {
		return this.nIntrstOthr;
	}

	public void setNIntrstOthr(String nIntrstOthr) {
		this.nIntrstOthr = nIntrstOthr;
	}

	public String getNVhclMake() {
		return this.nVhclMake;
	}

	public void setNVhclMake(String nVhclMake) {
		this.nVhclMake = nVhclMake;
	}

	public String getNVhclMod() {
		return this.nVhclMod;
	}

	public void setNVhclMod(String nVhclMod) {
		this.nVhclMod = nVhclMod;
	}

	public Integer getQCurrOdom() {
		return this.qCurrOdom;
	}

	public void setQCurrOdom(Integer qCurrOdom) {
		this.qCurrOdom = qCurrOdom;
	}

	public Timestamp getTInServ() {
		return this.tInServ;
	}

	public void setTInServ(Timestamp tInServ) {
		this.tInServ = tInServ;
	}

	public String getXAddlInfo() {
		return this.xAddlInfo;
	}

	public void setXAddlInfo(String xAddlInfo) {
		this.xAddlInfo = xAddlInfo;
	}

	public String getXCntct() {
		return this.xCntct;
	}

	public void setXCntct(String xCntct) {
		this.xCntct = xCntct;
	}

	public String getxBlkCmnt1() {
		return xBlkCmnt1;
	}

	public void setxBlkCmnt1(String xBlkCmnt1) {
		this.xBlkCmnt1 = xBlkCmnt1;
	}

	public String getxBlkCmnt2() {
		return xBlkCmnt2;
	}

	public void setxBlkCmnt2(String xBlkCmnt2) {
		this.xBlkCmnt2 = xBlkCmnt2;
	}

	public String getxBlkCmnt3() {
		return xBlkCmnt3;
	}

	public void setxBlkCmnt3(String xBlkCmnt3) {
		this.xBlkCmnt3 = xBlkCmnt3;
	}

	public String getXIntrstNrtv() {
		return this.xIntrstNrtv;
	}

	public void setXIntrstNrtv(String xIntrstNrtv) {
		this.xIntrstNrtv = xIntrstNrtv;
	}

	public CodeMaster getVehicleCategoryCode() {
		return vehicleCategoryCode;
	}

	public void setVehicleCategoryCode(CodeMaster vehicleCategoryCode) {
		this.vehicleCategoryCode = vehicleCategoryCode;
	}

	public CodeMaster getBusinessCntrCode() {
		return businessCntrCode;
	}

	public void setBusinessCntrCode(CodeMaster businessCntrCode) {
		this.businessCntrCode = businessCntrCode;
	}

	public CodeMaster getDisposalType() {
		return disposalType;
	}

	public void setDisposalType(CodeMaster disposalType) {
		this.disposalType = disposalType;
	}

	public Set<DisclsrVehicleOwner> getDisclsrVehicleOwners() {
		return this.disclsrVehicleOwners;
	}

	public void setDisclsrVehicleOwners(Set<DisclsrVehicleOwner> disclsrVehicleOwners) {
		this.disclsrVehicleOwners = disclsrVehicleOwners;
	}

	public DisclsrVehicleOwner addDisclsrVehicleOwner(DisclsrVehicleOwner disclsrVehicleOwner) {
		getDisclsrVehicleOwners().add(disclsrVehicleOwner);
		disclsrVehicleOwner.setDisclsrNonBybk(this);

		return disclsrVehicleOwner;
	}

	public DisclsrVehicleOwner removeDisclsrVehicleOwner(DisclsrVehicleOwner disclsrVehicleOwner) {
		getDisclsrVehicleOwners().remove(disclsrVehicleOwner);
		disclsrVehicleOwner.setDisclsrNonBybk(null);

		return disclsrVehicleOwner;
	}

	public Set<NonBybkCnResaleState> getNonBybkCnResaleStates() {
		return this.nonBybkCnResaleStates;
	}

	public void setNonBybkCnResaleStates(Set<NonBybkCnResaleState> nonBybkCnResaleStates) {
		this.nonBybkCnResaleStates = nonBybkCnResaleStates;
	}

	public NonBybkCnResaleState addNonBybkCnResaleState(NonBybkCnResaleState nonBybkCnResaleState) {
		getNonBybkCnResaleStates().add(nonBybkCnResaleState);
		nonBybkCnResaleState.setDisclsrNonBybk(this);

		return nonBybkCnResaleState;
	}

	public NonBybkCnResaleState removeNonBybkCnResaleState(NonBybkCnResaleState nonBybkCnResaleState) {
		getNonBybkCnResaleStates().remove(nonBybkCnResaleState);
		nonBybkCnResaleState.setDisclsrNonBybk(null);

		return nonBybkCnResaleState;
	}

	public Set<NonBybkNonConfirmity> getNonBybkNonConfirmities() {
		return this.nonBybkNonConfirmities;
	}

	public void setNonBybkNonConfirmities(Set<NonBybkNonConfirmity> nonBybkNonConfirmities) {
		this.nonBybkNonConfirmities = nonBybkNonConfirmities;
	}

	public String getxLstWarrRstrn() {
		return xLstWarrRstrn;
	}

	public void setxLstWarrRstrn(String xLstWarrRstrn) {
		this.xLstWarrRstrn = xLstWarrRstrn;
	}

	public DealerDetail getDealerDetail() {
		return dealerDetail;
	}

	public void setDealerDetail(DealerDetail dealerDetail) {
		this.dealerDetail = dealerDetail;
	}

	public NonBybkNonConfirmity addNonBybkNonConfirmity(NonBybkNonConfirmity nonBybkNonConfirmity) {
		getNonBybkNonConfirmities().add(nonBybkNonConfirmity);
		nonBybkNonConfirmity.setDisclsrNonBybk(this);

		return nonBybkNonConfirmity;
	}

	public NonBybkNonConfirmity removeNonBybkNonConfirmity(NonBybkNonConfirmity nonBybkNonConfirmity) {
		getNonBybkNonConfirmities().remove(nonBybkNonConfirmity);
		nonBybkNonConfirmity.setDisclsrNonBybk(null);

		return nonBybkNonConfirmity;
	}

	public CodeMaster getiDspslStat() {
		return iDspslStat;
	}

	public void setiDspslStat(CodeMaster iDspslStat) {
		this.iDspslStat = iDspslStat;
	}

	public Timestamp getdAssgnAuctn() {
		return dAssgnAuctn;
	}

	public void setdAssgnAuctn(Timestamp dAssgnAuctn) {
		this.dAssgnAuctn = dAssgnAuctn;
	}

	public String getiAuctnBy() {
		return iAuctnBy;
	}

	public void setiAuctnBy(String iAuctnBy) {
		this.iAuctnBy = iAuctnBy;
	}

	public Timestamp getdDlrPur() {
		return dDlrPur;
	}

	public void setdDlrPur(Timestamp dDlrPur) {
		this.dDlrPur = dDlrPur;
	}

	public String getnDlrPurBy() {
		return nDlrPurBy;
	}

	public void setnDlrPurBy(String nDlrPurBy) {
		this.nDlrPurBy = nDlrPurBy;
	}

	public String getlDlrSignDisclsr() {
		return lDlrSignDisclsr;
	}

	public void setlDlrSignDisclsr(String lDlrSignDisclsr) {
		this.lDlrSignDisclsr = lDlrSignDisclsr;
	}

	public Timestamp getdDlrSignDisclsr() {
		return dDlrSignDisclsr;
	}

	public void setdDlrSignDisclsr(Timestamp dDlrSignDisclsr) {
		this.dDlrSignDisclsr = dDlrSignDisclsr;
	}

	public String getlCustSignDisclsr() {
		return lCustSignDisclsr;
	}

	public void setlCustSignDisclsr(String lCustSignDisclsr) {
		this.lCustSignDisclsr = lCustSignDisclsr;
	}

	public Timestamp getdCustSignDisclsr() {
		return dCustSignDisclsr;
	}

	public void setdCustSignDisclsr(Timestamp dCustSignDisclsr) {
		this.dCustSignDisclsr = dCustSignDisclsr;
	}

	public String getcSoldDlr() {
		return cSoldDlr;
	}

	public void setcSoldDlr(String cSoldDlr) {
		this.cSoldDlr = cSoldDlr;
	}

	public String getnSoldCust() {
		return nSoldCust;
	}

	public void setnSoldCust(String nSoldCust) {
		this.nSoldCust = nSoldCust;
	}

	public Timestamp getdSoldDlr() {
		return dSoldDlr;
	}

	public void setdSoldDlr(Timestamp dSoldDlr) {
		this.dSoldDlr = dSoldDlr;
	}

	public Timestamp getdSoldCust() {
		return dSoldCust;
	}

	public void setdSoldCust(Timestamp dSoldCust) {
		this.dSoldCust = dSoldCust;
	}

	public AuctionDetail getcAuctnCentr() {
		return cAuctnCentr;
	}

	public void setcAuctnCentr(AuctionDetail cAuctnCentr) {
		this.cAuctnCentr = cAuctnCentr;
	}

	public AuctionDetail getcVhclAuctn() {
		return cVhclAuctn;
	}

	public void setcVhclAuctn(AuctionDetail cVhclAuctn) {
		this.cVhclAuctn = cVhclAuctn;
	}

	public String getxDescDam() {
		return xDescDam;
	}

	public void setxDescDam(String xDescDam) {
		this.xDescDam = xDescDam;
	}

	public CodeMaster getDisclosureType() {
		return disclosureType;
	}

	public void setDisclosureType(CodeMaster disclosureType) {
		this.disclosureType = disclosureType;
	}

	public User getSubmittedBy() {
		return submittedBy;
	}

	public void setSubmittedBy(User submittedBy) {
		this.submittedBy = submittedBy;
	}

	public Date getDatesubmitted() {
		return datesubmitted;
	}

	public void setDatesubmitted(Date datesubmitted) {
		this.datesubmitted = datesubmitted;
	}

	public String getxRep() {
		return xRep;
	}

	public void setxRep(String xRep) {
		this.xRep = xRep;
	}

	public Set<AuditTrailFunction> getAuditTrailFunctions() {
		return auditTrailFunctions;
	}

	public Set<AuditTrailField> getAuditTrailFields() {
		return auditTrailFields;
	}

	public void setAuditTrailFunctions(Set<AuditTrailFunction> auditTrailFunctions) {
		this.auditTrailFunctions = auditTrailFunctions;
	}

	public void setAuditTrailFields(Set<AuditTrailField> auditTrailFields) {
		this.auditTrailFields = auditTrailFields;
	}

}