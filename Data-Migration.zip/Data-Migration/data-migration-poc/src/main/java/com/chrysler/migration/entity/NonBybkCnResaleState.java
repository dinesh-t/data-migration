package com.chrysler.migration.entity;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the NON_BYBK_CN_RESALE_STATE database table.
 * 
 */
@Entity
@Table(name="NON_BYBK_CN_RESALE_STATE")
@NamedQuery(name="NonBybkCnResaleState.findAll", query="SELECT n FROM NonBybkCnResaleState n")
public class NonBybkCnResaleState extends AuditColumns implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="I_NON_RESALE_SEQ")
	private int iNonResaleSeq;

	//bi-directional many-to-one association to CodeMaster
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="I_RESALE_STATE")
	private CodeMaster codeMaster;

	//bi-directional many-to-one association to DisclsrNonBybk
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="I_NON_BYBK")
	private DisclsrNonBybk disclsrNonBybk;

	public NonBybkCnResaleState() {
		//
	}

	public int getINonResaleSeq() {
		return this.iNonResaleSeq;
	}

	public void setINonResaleSeq(int iNonResaleSeq) {
		this.iNonResaleSeq = iNonResaleSeq;
	}

	public CodeMaster getCodeMaster() {
		return this.codeMaster;
	}

	public void setCodeMaster(CodeMaster codeMaster) {
		this.codeMaster = codeMaster;
	}

	public DisclsrNonBybk getDisclsrNonBybk() {
		return this.disclsrNonBybk;
	}

	public void setDisclsrNonBybk(DisclsrNonBybk disclsrNonBybk) {
		this.disclsrNonBybk = disclsrNonBybk;
	}

}