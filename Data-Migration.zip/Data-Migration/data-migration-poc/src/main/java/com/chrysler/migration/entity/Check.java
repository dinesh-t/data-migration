package com.chrysler.migration.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * The persistent class for the "CHECK" database table.
 * 
 */
@Entity
@Table(name = "CHECK")
@NamedQuery(name = "Check.findAll", query = "SELECT c FROM Check c")
public class Check extends AuditColumns implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "I_CHECK_SEQ")
	private Integer iCheckSeq;

	@Column(name = "A_CHECK")
	private BigDecimal aCheck;

	@Column(name = "A_REQ_CHEQUE")
	private BigDecimal aReqCheque;

	@Column(name = "A_REQ_DISCT")
	private BigDecimal aReqDisct;

	@Column(name = "A_REQ_DSTRBN")
	private BigDecimal aReqDstrbn;

	@Column(name = "C_REQ_PAYE_ZIP")
	private String cReqPayeZip;

	@Column(name = "C_SEN_COMP")
	private String cSenComp;

	@Temporal(TemporalType.DATE)
	@Column(name = "D_CHECK")
	private Date dCheck;

	@Temporal(TemporalType.DATE)
	@Column(name = "D_CHECK_CAIR")
	private Date dCheckCair;

	@Temporal(TemporalType.DATE)
	@Column(name = "D_INVC")
	private Date dInvc;

	@Temporal(TemporalType.DATE)
	@Column(name = "D_REQ_INVC")
	private Date dReqInvc;

	@Temporal(TemporalType.DATE)
	@Column(name = "D_REQ_PAYMT_DUE")
	private Date dReqPaymtDue;

	@Column(name = "D_REQ_VOID")
	private Timestamp dReqVoid;

	@Temporal(TemporalType.DATE)
	@Column(name = "D_VOID")
	private Date dVoid;

	@Column(name = "I_CHECK")
	private String iCheck;

	@Column(name = "I_CHECK_CAIR")
	private String iCheckCair;

	@Column(name = "I_INVC")
	private String iInvc;

	@Column(name = "I_PAYMT_CURNCY")
	private String iPaymtCurncy;

	@Column(name = "I_REQ_INVC")
	private String iReqInvc;

	@Column(name = "I_REQ_SEQ")
	private Integer iReqSeq;

	@Column(name = "L_CHECK_SRCE")
	private String lCheckSrce;

	@Column(name = "L_PAYMT_METHD")
	private String lPaymtMethd;

	@Column(name = "L_REQ_VOID")
	private String lReqVoid;

	@Column(name = "L_VOID")
	private String lVoid;

	@Column(name = "N_HSE_BANK")
	private String nHseBank;

	@Column(name = "N_REQ_PAYE_CITY")
	private String nReqPayeCity;

	@Column(name = "N_REQ_PAYE_CNTRY")
	private String nReqPayeCntry;

	@Column(name = "N_VNDR")
	private String nVndr;

	@Column(name = "N_VNDR_CITY")
	private String nVndrCity;

	@Column(name = "N_VOID_BY")
	private String nVoidBy;

	@Column(name = "T_REQ_SENT")
	private Timestamp tReqSent;

	@Column(name = "T_RESPS_RECVD_DATE")
	private Timestamp tRespsRecvdDate;

	@Column(name = "X_REAS")
	private String xReas;

	@Column(name = "X_REQ_1099_DATA")
	private String xReq1099Data;

	@Column(name = "X_REQ_PAYE_ADDR1")
	private String xReqPayeAddr1;

	@Column(name = "X_REQ_PAYE_ADDR2")
	private String xReqPayeAddr2;

	@Column(name = "X_REQ_PAYE_LINE1")
	private String xReqPayeLine1;

	@Column(name = "X_REQ_PAYE_LINE2")
	private String xReqPayeLine2;

	@Column(name = "X_REQ_PAYE_LINE3")
	private String xReqPayeLine3;

	@Column(name = "X_REQ_REMIT_ADVCE1")
	private String xReqRemitAdvce1;

	@Column(name = "X_REQ_REMIT_ADVCE2")
	private String xReqRemitAdvce2;

	@Column(name = "X_COMNT")
	private String xComnt;

	@Column(name = "C_PAYE")
	private String cPaye;

	@Column(name = "I_VNDR")
	private String iVndr;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_APRVL_STAT")
	private CodeMaster approvalStatus;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_CHECK_TYP")
	private CodeMaster checkType;

	// bi-directional many-to-one association to Buyback
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_BYBK")
	private Buyback buyback;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "L_SCHD")
	private CodeMaster scheduleFlag;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_REQ_PAYE_STATE")
	private CodeMaster payeeState;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_VNDR_STATE")
	private CodeMaster vendorState;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_CHECK_STAT")
	private CodeMaster checkStatus;

	public Check() {
	}

	public Integer getiCheckSeq() {
		return iCheckSeq;
	}

	public void setiCheckSeq(Integer iCheckSeq) {
		this.iCheckSeq = iCheckSeq;
	}

	public BigDecimal getaCheck() {
		return aCheck;
	}

	public void setaCheck(BigDecimal aCheck) {
		this.aCheck = aCheck;
	}

	public BigDecimal getaReqCheque() {
		return aReqCheque;
	}

	public void setaReqCheque(BigDecimal aReqCheque) {
		this.aReqCheque = aReqCheque;
	}

	public BigDecimal getaReqDisct() {
		return aReqDisct;
	}

	public void setaReqDisct(BigDecimal aReqDisct) {
		this.aReqDisct = aReqDisct;
	}

	public BigDecimal getaReqDstrbn() {
		return aReqDstrbn;
	}

	public void setaReqDstrbn(BigDecimal aReqDstrbn) {
		this.aReqDstrbn = aReqDstrbn;
	}

	public String getcReqPayeZip() {
		return cReqPayeZip;
	}

	public void setcReqPayeZip(String cReqPayeZip) {
		this.cReqPayeZip = cReqPayeZip;
	}

	public String getcSenComp() {
		return cSenComp;
	}

	public void setcSenComp(String cSenComp) {
		this.cSenComp = cSenComp;
	}

	public Date getdCheck() {
		return dCheck;
	}

	public void setdCheck(Date dCheck) {
		this.dCheck = dCheck;
	}

	public Date getdCheckCair() {
		return dCheckCair;
	}

	public void setdCheckCair(Date dCheckCair) {
		this.dCheckCair = dCheckCair;
	}

	public Date getdInvc() {
		return dInvc;
	}

	public void setdInvc(Date dInvc) {
		this.dInvc = dInvc;
	}

	public Date getdReqInvc() {
		return dReqInvc;
	}

	public void setdReqInvc(Date dReqInvc) {
		this.dReqInvc = dReqInvc;
	}

	public Date getdReqPaymtDue() {
		return dReqPaymtDue;
	}

	public void setdReqPaymtDue(Date dReqPaymtDue) {
		this.dReqPaymtDue = dReqPaymtDue;
	}

	public Timestamp getdReqVoid() {
		return dReqVoid;
	}

	public void setdReqVoid(Timestamp dReqVoid) {
		this.dReqVoid = dReqVoid;
	}

	public Date getdVoid() {
		return dVoid;
	}

	public void setdVoid(Date dVoid) {
		this.dVoid = dVoid;
	}

	public String getiCheck() {
		return iCheck;
	}

	public void setiCheck(String iCheck) {
		this.iCheck = iCheck;
	}

	public String getiCheckCair() {
		return iCheckCair;
	}

	public void setiCheckCair(String iCheckCair) {
		this.iCheckCair = iCheckCair;
	}

	public String getiInvc() {
		return iInvc;
	}

	public void setiInvc(String iInvc) {
		this.iInvc = iInvc;
	}

	public String getiPaymtCurncy() {
		return iPaymtCurncy;
	}

	public void setiPaymtCurncy(String iPaymtCurncy) {
		this.iPaymtCurncy = iPaymtCurncy;
	}

	public String getiReqInvc() {
		return iReqInvc;
	}

	public void setiReqInvc(String iReqInvc) {
		this.iReqInvc = iReqInvc;
	}

	public Integer getiReqSeq() {
		return iReqSeq;
	}

	public void setiReqSeq(Integer iReqSeq) {
		this.iReqSeq = iReqSeq;
	}

	public String getlCheckSrce() {
		return lCheckSrce;
	}

	public void setlCheckSrce(String lCheckSrce) {
		this.lCheckSrce = lCheckSrce;
	}

	public String getlPaymtMethd() {
		return lPaymtMethd;
	}

	public void setlPaymtMethd(String lPaymtMethd) {
		this.lPaymtMethd = lPaymtMethd;
	}

	public String getlReqVoid() {
		return lReqVoid;
	}

	public void setlReqVoid(String lReqVoid) {
		this.lReqVoid = lReqVoid;
	}

	public String getlVoid() {
		return lVoid;
	}

	public void setlVoid(String lVoid) {
		this.lVoid = lVoid;
	}

	public String getnHseBank() {
		return nHseBank;
	}

	public void setnHseBank(String nHseBank) {
		this.nHseBank = nHseBank;
	}

	public String getnReqPayeCity() {
		return nReqPayeCity;
	}

	public void setnReqPayeCity(String nReqPayeCity) {
		this.nReqPayeCity = nReqPayeCity;
	}

	public String getnReqPayeCntry() {
		return nReqPayeCntry;
	}

	public void setnReqPayeCntry(String nReqPayeCntry) {
		this.nReqPayeCntry = nReqPayeCntry;
	}

	public String getnVndr() {
		return nVndr;
	}

	public void setnVndr(String nVndr) {
		this.nVndr = nVndr;
	}

	public String getnVndrCity() {
		return nVndrCity;
	}

	public void setnVndrCity(String nVndrCity) {
		this.nVndrCity = nVndrCity;
	}

	public String getnVoidBy() {
		return nVoidBy;
	}

	public void setnVoidBy(String nVoidBy) {
		this.nVoidBy = nVoidBy;
	}

	public Timestamp gettReqSent() {
		return tReqSent;
	}

	public void settReqSent(Timestamp tReqSent) {
		this.tReqSent = tReqSent;
	}

	public Timestamp gettRespsRecvdDate() {
		return tRespsRecvdDate;
	}

	public void settRespsRecvdDate(Timestamp tRespsRecvdDate) {
		this.tRespsRecvdDate = tRespsRecvdDate;
	}

	public String getxReas() {
		return xReas;
	}

	public void setxReas(String xReas) {
		this.xReas = xReas;
	}

	public String getxReq1099Data() {
		return xReq1099Data;
	}

	public void setxReq1099Data(String xReq1099Data) {
		this.xReq1099Data = xReq1099Data;
	}

	public String getxReqPayeAddr1() {
		return xReqPayeAddr1;
	}

	public void setxReqPayeAddr1(String xReqPayeAddr1) {
		this.xReqPayeAddr1 = xReqPayeAddr1;
	}

	public String getxReqPayeAddr2() {
		return xReqPayeAddr2;
	}

	public void setxReqPayeAddr2(String xReqPayeAddr2) {
		this.xReqPayeAddr2 = xReqPayeAddr2;
	}

	public String getxReqPayeLine1() {
		return xReqPayeLine1;
	}

	public void setxReqPayeLine1(String xReqPayeLine1) {
		this.xReqPayeLine1 = xReqPayeLine1;
	}

	public String getxReqPayeLine2() {
		return xReqPayeLine2;
	}

	public void setxReqPayeLine2(String xReqPayeLine2) {
		this.xReqPayeLine2 = xReqPayeLine2;
	}

	public String getxReqPayeLine3() {
		return xReqPayeLine3;
	}

	public void setxReqPayeLine3(String xReqPayeLine3) {
		this.xReqPayeLine3 = xReqPayeLine3;
	}

	public String getxReqRemitAdvce1() {
		return xReqRemitAdvce1;
	}

	public void setxReqRemitAdvce1(String xReqRemitAdvce1) {
		this.xReqRemitAdvce1 = xReqRemitAdvce1;
	}

	public String getxReqRemitAdvce2() {
		return xReqRemitAdvce2;
	}

	public void setxReqRemitAdvce2(String xReqRemitAdvce2) {
		this.xReqRemitAdvce2 = xReqRemitAdvce2;
	}

	public String getxComnt() {
		return xComnt;
	}

	public void setxComnt(String xComnt) {
		this.xComnt = xComnt;
	}

	public String getcPaye() {
		return cPaye;
	}

	public void setcPaye(String cPaye) {
		this.cPaye = cPaye;
	}

	public Buyback getBuyback() {
		return buyback;
	}

	public void setBuyback(Buyback buyback) {
		this.buyback = buyback;
	}

	public CodeMaster getScheduleFlag() {
		return scheduleFlag;
	}

	public void setScheduleFlag(CodeMaster scheduleFlag) {
		this.scheduleFlag = scheduleFlag;
	}

	public CodeMaster getPayeeState() {
		return payeeState;
	}

	public void setPayeeState(CodeMaster payeeState) {
		this.payeeState = payeeState;
	}

	public CodeMaster getVendorState() {
		return vendorState;
	}

	public void setVendorState(CodeMaster vendorState) {
		this.vendorState = vendorState;
	}

	public CodeMaster getCheckStatus() {
		return checkStatus;
	}

	public void setCheckStatus(CodeMaster checkStatus) {
		this.checkStatus = checkStatus;
	}

	public CodeMaster getApprovalStatus() {
		return approvalStatus;
	}

	public void setApprovalStatus(CodeMaster approvalStatus) {
		this.approvalStatus = approvalStatus;
	}

	public CodeMaster getCheckType() {
		return checkType;
	}

	public void setCheckType(CodeMaster checkType) {
		this.checkType = checkType;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((aCheck == null) ? 0 : aCheck.hashCode());
		result = prime * result + ((buyback == null) ? 0 : buyback.hashCode());
		result = prime * result + ((iCheckCair == null) ? 0 : iCheckCair.hashCode());
		result = prime * result + ((nReqPayeCity == null) ? 0 : nReqPayeCity.hashCode());
		result = prime * result + ((payeeState == null) ? 0 : payeeState.hashCode());
		result = prime * result + ((xReas == null) ? 0 : xReas.hashCode());
		result = prime * result + ((xReqPayeAddr1 == null) ? 0 : xReqPayeAddr1.hashCode());
		result = prime * result + ((xReqPayeAddr2 == null) ? 0 : xReqPayeAddr2.hashCode());
		result = prime * result + ((xReqPayeLine1 == null) ? 0 : xReqPayeLine1.hashCode());
		result = prime * result + ((xComnt == null) ? 0 : xComnt.hashCode());
		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (!(obj instanceof Check))
			return false;
		Check other = (Check) obj;
		if (aCheck == null) {
			if (other.aCheck != null)
				return false;
		} else if (!aCheck.equals(other.aCheck))
			return false;
		if (buyback == null) {
			if (other.buyback != null)
				return false;
		} else if (buyback.getIBybkSeq() != other.buyback.getIBybkSeq())
			return false;
		if (iCheckCair == null) {
			if (other.iCheckCair != null)
				return false;
		} else if (!iCheckCair.equals(other.iCheckCair))
			return false;
		if (nReqPayeCity == null) {
			if (other.nReqPayeCity != null)
				return false;
		} else if (!nReqPayeCity.equals(other.nReqPayeCity))
			return false;
		if (payeeState == null) {
			if (other.payeeState != null)
				return false;
		} else if (!payeeState.getICodeMstrSeq().equals(other.payeeState.getICodeMstrSeq()))
			return false;
		if (xReas == null) {
			if (other.xReas != null)
				return false;
		} else if (!xReas.equals(other.xReas))
			return false;
		if (xReqPayeAddr1 == null) {
			if (other.xReqPayeAddr1 != null)
				return false;
		} else if (!xReqPayeAddr1.equals(other.xReqPayeAddr1))
			return false;
		if (xReqPayeAddr2 == null) {
			if (other.xReqPayeAddr2 != null)
				return false;
		} else if (!xReqPayeAddr2.equals(other.xReqPayeAddr2))
			return false;
		if (xReqPayeLine1 == null) {
			if (other.xReqPayeLine1 != null)
				return false;
		} else if (!xReqPayeLine1.equals(other.xReqPayeLine1))
			return false;
		return true;
	}

	public String getiVndr() {
		return iVndr;
	}

	public void setiVndr(String iVndr) {
		this.iVndr = iVndr;
	}
}