package com.chrysler.migration.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MapsId;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.LazyToOne;
import org.hibernate.annotations.LazyToOneOption;


/**
 * The persistent class for the BUYBACK_APPROVAL database table.
 * 
 */
@Entity
@Table(name="BYBK_APPROVAL")
@NamedQuery(name="BuybackApproval.findAll", query="SELECT b FROM BuybackApproval b")
public class BuybackApproval implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private int iBybk;

	@Column(name="A_BYBK_APRVL_RANGE")
	private BigDecimal aBybkAprvlRange;

	@Column(name="I_LOGON")
	private String iLogon;

	@Column(name="I_LOGON_UPD")
	private String iLogonUpd;

	@Column(name="T_STMP_ADD")
	private Timestamp tStmpAdd;

	@Column(name="T_STMP_UPD")
	private Timestamp tStmpUpd;

	@Column(name="X_BYBK_APRVL_COMNT")
	private String xBybkAprvlComnt;

	//bi-directional one-to-one association to Buyback
	@OneToOne(fetch=FetchType.LAZY)
	@MapsId
    @LazyToOne(LazyToOneOption.NO_PROXY)
	@JoinColumn(name="I_BYBK")
	private Buyback buyback;

	//bi-directional many-to-one association to CodeMaster
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="I_APRVL_TYP")
	private CodeMaster codeMaster;

	public BuybackApproval() {
	}

	public int getIBybk() {
		return this.iBybk;
	}

	public void setIBybk(int iBybk) {
		this.iBybk = iBybk;
	}

	public BigDecimal getABybkAprvlRange() {
		return this.aBybkAprvlRange;
	}

	public void setABybkAprvlRange(BigDecimal aBybkAprvlRange) {
		this.aBybkAprvlRange = aBybkAprvlRange;
	}

	public String getILogon() {
		return this.iLogon;
	}

	public void setILogon(String iLogon) {
		this.iLogon = iLogon;
	}

	public String getILogonUpd() {
		return this.iLogonUpd;
	}

	public void setILogonUpd(String iLogonUpd) {
		this.iLogonUpd = iLogonUpd;
	}

	public Timestamp getTStmpAdd() {
		return this.tStmpAdd;
	}

	public void setTStmpAdd(Timestamp tStmpAdd) {
		this.tStmpAdd = tStmpAdd;
	}

	public Timestamp getTStmpUpd() {
		return this.tStmpUpd;
	}

	public void setTStmpUpd(Timestamp tStmpUpd) {
		this.tStmpUpd = tStmpUpd;
	}

	public String getXBybkAprvlComnt() {
		return this.xBybkAprvlComnt;
	}

	public void setXBybkAprvlComnt(String xBybkAprvlComnt) {
		this.xBybkAprvlComnt = xBybkAprvlComnt;
	}

	public Buyback getBuyback() {
		return this.buyback;
	}

	public void setBuyback(Buyback buyback) {
		this.buyback = buyback;
	}

	public CodeMaster getCodeMaster() {
		return this.codeMaster;
	}

	public void setCodeMaster(CodeMaster codeMaster) {
		this.codeMaster = codeMaster;
	}

}