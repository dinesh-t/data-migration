package com.chrysler.migration.entity;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;


/**
 * The persistent class for the USER_TYPE_MAPPING database table.
 * 
 */
@Entity
@Table(name="USER_TYPE_MAPG")
@NamedQuery(name="UserTypeMapping.findAll", query="SELECT u FROM UserTypeMapping u")
public class UserTypeMapping  extends AuditColumns implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="I_USER_MAPG_SEQ")
	private int iUserMapgSeq;

	//bi-directional many-to-one association to CodeMaster
	@ManyToOne
	@JoinColumn(name="I_USER_TYP_2")
	private CodeMaster userType2;

	//bi-directional many-to-one association to CodeMaster
	@ManyToOne
	@JoinColumn(name="I_USER_TYP_1")
	private CodeMaster userType1;

	public UserTypeMapping() {
		//
	}

	public int getIUserMapgSeq() {
		return this.iUserMapgSeq;
	}

	public void setIUserMapgSeq(int iUserMapgSeq) {
		this.iUserMapgSeq = iUserMapgSeq;
	}

	public CodeMaster getUserType2() {
		return userType2;
	}

	public void setUserType2(CodeMaster userType2) {
		this.userType2 = userType2;
	}

	public CodeMaster getUserType1() {
		return userType1;
	}

	public void setUserType1(CodeMaster userType1) {
		this.userType1 = userType1;
	}

	

}