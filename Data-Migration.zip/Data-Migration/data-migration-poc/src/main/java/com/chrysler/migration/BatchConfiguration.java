package com.chrysler.migration;

import javax.persistence.EntityManagerFactory;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.core.step.builder.TaskletStepBuilder;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.database.JpaItemWriter;
import org.springframework.batch.item.xml.StaxEventItemReader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;

import com.chrysler.migration.dto.Record;
import com.chrysler.migration.entity.Buyback;

/**
 * 
 * @author STG
 *
 */
@Configuration
@EnableBatchProcessing
public class BatchConfiguration {

	private static final Logger log = LoggerFactory.getLogger(BatchConfiguration.class);

	@Autowired
	public JobBuilderFactory jobBuilderFactory;

	@Autowired
	public StepBuilderFactory stepBuilderFactory;

	@Autowired
	EntityManagerFactory entityManagerFactory;
	
	
	/**
	 * Buyback Job definition.
	 * 
	 * @param listener
	 * @return Job
	 */
	@Bean
	public Job importBuybackJob() {
		return jobBuilderFactory.get("importBuybackJob").incrementer(new RunIdIncrementer()).listener(jobListener()).flow(stepOne()).next(stepTwo()).end()
				.build();
	}

	/**
	 * Step one definition.
	 * 
	 * @return Step
	 */
	@Bean
	public Step stepOne() {
		return stepBuilderFactory.get("stepOne").<Record, Buyback>chunk(10).reader(reader()).processor(processor())
				.writer(writer()).build();
	}

	/**
	 * Step two definition.
	 * 
	 * @return Step
	 */
	@Bean
	public Step  stepTwo() {
		return stepBuilderFactory.get("stepTwo").tasklet(taskletStep()).build();
	}
	
	/**
	 * Defines TaskLet.
	 * 
	 * @return TaskletStep
	 */
	@Bean
	  public TaskletStep taskletStep() {
	   TaskletStep taskletStep = new TaskletStep();
	    return taskletStep;
	  }
	
	
	/**
	 * Defines Listener.
	 * 
	 * @return JobStatusListener
	 */
	@Bean
	  public JobStatusListener jobListener() {
		JobStatusListener jobListener = new JobStatusListener();
	    return jobListener;
	  }
	
	
	/**
	 * Defines Buyabck XML reader.
	 * 
	 * @return ItemReader
	 */
	@Bean
	public ItemReader<Record> reader() {
		log.info("** Reading Item - In ***");
		StaxEventItemReader<Record> xmlFileReader = new StaxEventItemReader<>();
		xmlFileReader.setResource(new ClassPathResource("xml/Buy Back Form-External v2.xml"));
		xmlFileReader.setFragmentRootElementName("record");
		Jaxb2Marshaller empMarshaller = new Jaxb2Marshaller();
		empMarshaller.setClassesToBeBound(Record.class);
		xmlFileReader.setUnmarshaller(empMarshaller);
		xmlFileReader.setStrict(false);
		log.info("** Reading Item - Out ***");
		return xmlFileReader;
	}

	/**
	 * Process buyback data.
	 * 
	 * @return BuybackItemProcessor
	 */
	@Bean
	public BuybackItemProcessor processor() {
		return new BuybackItemProcessor();
	}

	/**
	 * Setting entity values of Buyback
	 * 
	 * @return BuyBack
	 */
	@Bean
	public BuyBackSettingValues setValues() {
		return new BuyBackSettingValues();
	}
	
	
	/**
	 * Setting entity values of Buyback
	 * 
	 * @return BuyBack
	 */
	@Bean
	public Transformation transformation() {
		return new Transformation();
	}
	
	
	
	/**
	 * Write buyback to database.
	 * 
	 * @return ItemWriter
	 */
	@Bean
	public ItemWriter<Buyback> writer() {
		log.info("** Writing data - In ***");
		JpaItemWriter<Buyback> jpaItemWriter = new JpaItemWriter<>();
		jpaItemWriter.setEntityManagerFactory(entityManagerFactory);
		log.info("** Writing data - out ***");
		return jpaItemWriter;
	}

}
