package com.chrysler.migration.entity;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * The persistent class for the TABLE_MASTER database table.
 * 
 */
@Entity
@Table(name = "TABLE_MASTER")
@NamedQuery(name = "TableMaster.findAll", query = "SELECT t FROM TableMaster t")
public class TableMaster extends AuditColumns implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "I_TBL_SEQ")
	private int iTblSeq;

	@Column(name = "N_TBL_BUS")
	private String nTblBus;

	@Column(name = "N_TBL_PHYS")
	private String nTblPhys;

	@Column(name = "L_BYBK")
	private String lBuyback;

	// bi-directional many-to-one association to ColumnMaster
	@OneToMany(mappedBy = "tableMaster")
	private Set<ColumnMaster> columnMasters;

	// bi-directional many-to-one association to WhereCondMstr
	@OneToMany(mappedBy = "tableMaster1")
	private Set<WhereCondMstr> whereCondMstrs1;

	// bi-directional many-to-one association to WhereCondMstr
	@OneToMany(mappedBy = "tableMaster2")
	private Set<WhereCondMstr> whereCondMstrs2;

	public TableMaster() {
	}

	public int getITblSeq() {
		return this.iTblSeq;
	}

	public void setITblSeq(int iTblSeq) {
		this.iTblSeq = iTblSeq;
	}

	public String getNTblBus() {
		return this.nTblBus;
	}

	public void setNTblBus(String nTblBus) {
		this.nTblBus = nTblBus;
	}

	public String getNTblPhys() {
		return this.nTblPhys;
	}

	public void setNTblPhys(String nTblPhys) {
		this.nTblPhys = nTblPhys;
	}

	public Set<ColumnMaster> getColumnMasters() {
		return this.columnMasters;
	}

	public void setColumnMasters(Set<ColumnMaster> columnMasters) {
		this.columnMasters = columnMasters;
	}

	public ColumnMaster addColumnMaster(ColumnMaster columnMaster) {
		getColumnMasters().add(columnMaster);
		columnMaster.setTableMaster(this);

		return columnMaster;
	}

	public ColumnMaster removeColumnMaster(ColumnMaster columnMaster) {
		getColumnMasters().remove(columnMaster);
		columnMaster.setTableMaster(null);

		return columnMaster;
	}

	public Set<WhereCondMstr> getWhereCondMstrs1() {
		return this.whereCondMstrs1;
	}

	public void setWhereCondMstrs1(Set<WhereCondMstr> whereCondMstrs1) {
		this.whereCondMstrs1 = whereCondMstrs1;
	}

	public WhereCondMstr addWhereCondMstrs1(WhereCondMstr whereCondMstrs1) {
		getWhereCondMstrs1().add(whereCondMstrs1);
		whereCondMstrs1.setTableMaster1(this);

		return whereCondMstrs1;
	}

	public WhereCondMstr removeWhereCondMstrs1(WhereCondMstr whereCondMstrs1) {
		getWhereCondMstrs1().remove(whereCondMstrs1);
		whereCondMstrs1.setTableMaster1(null);

		return whereCondMstrs1;
	}

	public Set<WhereCondMstr> getWhereCondMstrs2() {
		return this.whereCondMstrs2;
	}

	public void setWhereCondMstrs2(Set<WhereCondMstr> whereCondMstrs2) {
		this.whereCondMstrs2 = whereCondMstrs2;
	}

	public WhereCondMstr addWhereCondMstrs2(WhereCondMstr whereCondMstrs2) {
		getWhereCondMstrs2().add(whereCondMstrs2);
		whereCondMstrs2.setTableMaster2(this);

		return whereCondMstrs2;
	}

	public WhereCondMstr removeWhereCondMstrs2(WhereCondMstr whereCondMstrs2) {
		getWhereCondMstrs2().remove(whereCondMstrs2);
		whereCondMstrs2.setTableMaster2(null);

		return whereCondMstrs2;
	}

	public String getlBuyback() {
		return lBuyback;
	}

	public void setlBuyback(String lBuyback) {
		this.lBuyback = lBuyback;
	}

}