package com.chrysler.migration.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * The persistent class for the DASH_BD_CHART database table.
 * 
 */
@Entity
@Table(name = "DASH_BD_CHART")
@NamedQuery(name = "DashBdChart.findAll", query = "SELECT d FROM DashBdChart d")
public class DashBdChart extends AuditColumns implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "I_DASH_CHART_SEQ")
	private int iDashChartSeq;

	// bi-directional many-to-one association to ColumnMaster
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_X_AXIS")
	private ColumnMaster iXAxis;

	// bi-directional many-to-one association to ColumnMaster
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_Y_AXIS")
	private ColumnMaster iYAxis;

	// bi-directional many-to-one association to DashBd
	@ManyToOne
	@JoinColumn(name = "I_DASH_BD")
	private DashBd dashBd;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne
	@JoinColumn(name = "I_TYP_CHART")
	private CodeMaster codeMaster;

	@Column(name = "I_RPT")
	private Integer iRpt;

	public int getIDashChartSeq() {
		return this.iDashChartSeq;
	}

	public void setIDashChartSeq(int iDashChartSeq) {
		this.iDashChartSeq = iDashChartSeq;
	}

	public ColumnMaster getiXAxis() {
		return iXAxis;
	}

	public void setiXAxis(ColumnMaster iXAxis) {
		this.iXAxis = iXAxis;
	}

	public ColumnMaster getiYAxis() {
		return iYAxis;
	}

	public void setiYAxis(ColumnMaster iYAxis) {
		this.iYAxis = iYAxis;
	}

	public DashBd getDashBd() {
		return this.dashBd;
	}

	public void setDashBd(DashBd dashBd) {
		this.dashBd = dashBd;
	}

	public CodeMaster getCodeMaster() {
		return this.codeMaster;
	}

	public void setCodeMaster(CodeMaster codeMaster) {
		this.codeMaster = codeMaster;
	}

	public Integer getiRpt() {
		return iRpt;
	}

	public void setiRpt(Integer iRpt) {
		this.iRpt = iRpt;
	}

}