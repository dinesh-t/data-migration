package com.chrysler.migration.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * The persistent class for the USER_EMAIL database table.
 * 
 */
@Entity
@Table(name = "USER_EMAIL")
@NamedQuery(name = "UserEmail.findAll", query = "SELECT u FROM UserEmail u")
public class UserEmail extends AuditColumns implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "I_USER_EMAIL_SEQ")
	private int iUserEmailSeq;

	// bi-directional many-to-one association to ColumnMaster
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_COLM")
	private CodeMaster columnMaster;

	// bi-directional many-to-one association to User
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_USER")
	private User user;

	public UserEmail() {
	}

	public int getIUserEmailSeq() {
		return this.iUserEmailSeq;
	}

	public void setIUserEmailSeq(int iUserEmailSeq) {
		this.iUserEmailSeq = iUserEmailSeq;
	}

	public CodeMaster getColumnMaster() {
		return columnMaster;
	}

	public void setColumnMaster(CodeMaster columnMaster) {
		this.columnMaster = columnMaster;
	}

	public User getUser() {
		return this.user;
	}

	public void setUser(User user) {
		this.user = user;
	}

}