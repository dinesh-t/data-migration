package com.chrysler.migration.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * The persistent class for the CODE_MASTER database table.
 * 
 */
@Entity
@Table(name = "CODE_MASTER")
@NamedQuery(name = "CodeMaster.findAll", query = "SELECT c FROM CodeMaster c")
public class CodeMaster extends AuditColumns implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "I_CODE_MSTR_SEQ")
	private Integer iCodeMstrSeq;

	@Column(name = "C_FLD_NAME")
	private String cFldName;

	@Column(name = "L_FLD_EDITBL")
	private String lFldEditbl;

	@Column(name = "L_FLD_STAT")
	private String lFldStat;

	@Column(name = "X_FLD_COMNT")
	private String xFldComnt;

	@Column(name = "X_FLD_VAL")
	private String xFldVal;

	@Column(name = "I_FLD_SORT")
	private Integer iFldSort;

	@Column(name = "X_FLD_LOG")
	private String xFldLog;

	@Column(name = "X_TBL_LOG")
	private String xTblLog;

	@ManyToOne
	@JoinColumn(name = "C_TYP")
	private TypeMaster typeMaster;

	public Integer getICodeMstrSeq() {
		return this.iCodeMstrSeq;
	}

	public void setICodeMstrSeq(Integer iCodeMstrSeq) {
		this.iCodeMstrSeq = iCodeMstrSeq;
	}

	public String getCFldName() {
		return this.cFldName;
	}

	public void setCFldName(String cFldName) {
		this.cFldName = cFldName;
	}

	public String getLFldEditbl() {
		return this.lFldEditbl;
	}

	public void setLFldEditbl(String lFldEditbl) {
		this.lFldEditbl = lFldEditbl;
	}

	public String getLFldStat() {
		return this.lFldStat;
	}

	public void setLFldStat(String lFldStat) {
		this.lFldStat = lFldStat;
	}

	public Integer getiFldSort() {
		return iFldSort;
	}

	public void setiFldSort(Integer iFldSort) {
		this.iFldSort = iFldSort;
	}

	public String getXFldComnt() {
		return this.xFldComnt;
	}

	public void setXFldComnt(String xFldComnt) {
		this.xFldComnt = xFldComnt;
	}

	public String getXFldVal() {
		return this.xFldVal;
	}

	public void setXFldVal(String xFldVal) {
		this.xFldVal = xFldVal;
	}

	public TypeMaster getTypeMaster() {
		return this.typeMaster;
	}

	public void setTypeMaster(TypeMaster typeMaster) {
		this.typeMaster = typeMaster;
	}

	public String getxFldLog() {
		return xFldLog;
	}

	public void setxFldLog(String xFldLog) {
		this.xFldLog = xFldLog;
	}

	public String getxTblLog() {
		return xTblLog;
	}

	public void setxTblLog(String xTblLog) {
		this.xTblLog = xTblLog;
	}

}