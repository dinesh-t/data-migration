package com.chrysler.migration.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * The persistent class for the DISCLSR_CN_RESALE_STATE database table.
 * 
 */
@Entity
@Table(name = "DISCLSR_CN_RESALE_STATE")
@NamedQuery(name = "DisclsrCnResaleState.findAll", query = "SELECT d FROM DisclsrCnResaleState d")
public class DisclsrCnResaleState extends AuditColumns implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "I_DISCLSR_SALE_SEQ")
	private int iDisclsrSaleSeq;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_RESALE_STATE")
	private CodeMaster codeMaster;

	// bi-directional many-to-one association to DisclsrVehicleOwner
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_DISCLSR_VIN")
	private DisclsrVehicleOwner disclsrVehicleOwner;

	public DisclsrCnResaleState() {
		//
	}

	public int getIDisclsrSaleSeq() {
		return this.iDisclsrSaleSeq;
	}

	public void setIDisclsrSaleSeq(int iDisclsrSaleSeq) {
		this.iDisclsrSaleSeq = iDisclsrSaleSeq;
	}

	public CodeMaster getCodeMaster() {
		return this.codeMaster;
	}

	public void setCodeMaster(CodeMaster codeMaster) {
		this.codeMaster = codeMaster;
	}

	public DisclsrVehicleOwner getDisclsrVehicleOwner() {
		return this.disclsrVehicleOwner;
	}

	public void setDisclsrVehicleOwner(DisclsrVehicleOwner disclsrVehicleOwner) {
		this.disclsrVehicleOwner = disclsrVehicleOwner;
	}

}