package com.chrysler.migration;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.chrysler.migration.dto.Record;
import com.chrysler.migration.entity.Buyback;

public class BuyBackSettingValues {

	@Autowired
	private Transformation transform;
	
	/**
	 * Slf4j Object.
	 */
	private static final Logger log = LoggerFactory.getLogger(BuyBackSettingValues.class);
	
	public Buyback setBuyBackValues(Record record) {
		
		log.info("*************Inside BuyBack Setting Values****************");
		try {
		
		transform.stringToTimeStamp(record.getDocCreated().getData());
		String data="2013-01-29T18:58:33.73Z";
		log.info("Converted data is : "+transform.stringToTimeStamp(data));
		Buyback buyBack=new Buyback();
				
		buyBack.setiLogonUpd(record.getModifiedBy().getElement().get(0).toString());
		buyBack.settStmpAdd(transform.stringToTimeStamp(record.getDocCreated().getData()));
		buyBack.settStmpUpd(transform.stringToTimeStamp(record.getDocModified().getData()));
		buyBack.setITmpltCair(record.getCAIR_Number().getData());
		buyBack.setlReaqSys(record.getPushedToREAQ().getData());
		buyBack.setIBybkVin(record.getVIN().getData());
		buyBack.setLegalEntry(transform.toLegalEntry(record));
		buyBack.setBuybackPackage(transform.toBuyBackPkg(record));
		buyBack.setBusinessCenterInformation(transform.toBusinessCenterInformation(record));
		buyBack.setBuybackReason(transform.toBuyBackReason(record));
		buyBack.setBybkReasProbMapgs(transform.toBybkReasProbMapg(record));
		buyBack.setCustomerDetail(transform.toCustomerDetail(record));
		buyBack.setWarranty(transform.toWarranty(record));
		buyBack.setBuybackEntryOffsets(transform.toBuybackEntryOffset(record));
		buyBack.setBuybackEntryLogical(transform.toBuybackEntryLogical(record));
		buyBack.setVehicleDetail(transform.toVehicleDetail(record));
		buyBack.setDealerDetails(transform.toDealerDetail(record));
		//buyBack.settStmpAdd(tranform.stringToInteger(record.getDocCreated().getData()));
		return buyBack;
		}catch(Exception e) {
		return null;
	}
		
		
		}
	
}
