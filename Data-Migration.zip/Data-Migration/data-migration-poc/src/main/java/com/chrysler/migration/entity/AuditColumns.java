package com.chrysler.migration.entity;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.MappedSuperclass;

/**
 * Extend this class if entity has created time,updated time and user TID
 * 
 * @author renjithkn
 *
 */
@MappedSuperclass
public class AuditColumns {

	@Column(name = "I_LOGON")
	public String iLogon;

	@Column(name = "I_LOGON_UPD")
	public String iLogonUpd;

	@Column(name = "T_STMP_ADD")
	public Timestamp tStmpAdd;

	@Column(name = "T_STMP_UPD")
	public Timestamp tStmpUpd;

	public String getiLogon() {
		return iLogon;
	}

	public void setiLogon(String iLogon) {
		this.iLogon = iLogon;
	}

	public String getiLogonUpd() {
		return iLogonUpd;
	}

	public void setiLogonUpd(String iLogonUpd) {
		this.iLogonUpd = iLogonUpd;
	}

	public Timestamp gettStmpAdd() {
		return tStmpAdd;
	}

	public void settStmpAdd(Timestamp tStmpAdd) {
		this.tStmpAdd = tStmpAdd;
	}

	public Timestamp gettStmpUpd() {
		return tStmpUpd;
	}

	public void settStmpUpd(Timestamp tStmpUpd) {
		this.tStmpUpd = tStmpUpd;
	}

}
