package com.chrysler.migration;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.text.ParseException;
import java.util.HashSet;
import java.util.Set;
import com.chrysler.migration.dto.Record;
import com.chrysler.migration.entity.BusinessCenterInformation;
import com.chrysler.migration.entity.BuybackDealerDetail;
import com.chrysler.migration.entity.BuybackEntryLogical;
import com.chrysler.migration.entity.BuybackEntryOffset;
import com.chrysler.migration.entity.BuybackPackage;
import com.chrysler.migration.entity.BuybackReason;
import com.chrysler.migration.entity.BybkReasProbMapg;
import com.chrysler.migration.entity.CustomerDetail;
import com.chrysler.migration.entity.LegalEntry;
import com.chrysler.migration.entity.VehicleDetail;
import com.chrysler.migration.entity.Warranty;



public class Transformation {

	
	//This method Converts String to TimeStamp
	public Timestamp stringToTimeStamp(String str) throws ParseException {
		
		Timestamp ts = Timestamp.valueOf(str);
		return ts;
	}
	
	
	public BigDecimal stringToBigDecimal(String str) {
		
		if(str!=null)
		return new BigDecimal(str);
		else
		return null;	
		
	}
	
	/*Set LegalEntry to BuyBack*/	
	
	public LegalEntry toLegalEntry(Record record) {
		LegalEntry legalEntry = new LegalEntry();
		legalEntry.setXAftMktAccry(record.getAftermarketAccessories().getData());
		legalEntry.setAAttyFee(stringToBigDecimal(record.getAttorneyFees().getData()));
		legalEntry.setNAtty(record.getAttorneyName().getData());
		legalEntry.setIAttyPh(record.getAttorneyPhone().getData());
		return legalEntry;
	}
	
	/*Set BuyBack_Pkg to BuyBack*/
	
	public BuybackPackage toBuyBackPkg(Record record) {
		BuybackPackage bPkg = new BuybackPackage();
		
		bPkg.setNServDlr(record.getServiceDealerContactName().getData());
		bPkg.setLArbCaseFiled(record.getStateArbitration().getData());
		
		return bPkg;
	}
	
	
	/*Set BusinessCenterInformation to BuyBack*/
	
	public BusinessCenterInformation toBusinessCenterInformation(Record record) {
		BusinessCenterInformation bci = new BusinessCenterInformation();
		
		bci.setIDecnMkr(record.getDecisionMaker().getData());
		bci.setIDecnMkrPh(record.getDecisionMakerPhone().getData());
				
		return bci;
	}
	
	
	/*Set BuybackReason to BuyBack*/
	
	public BuybackReason toBuyBackReason(Record record) {
		
		BuybackReason buyBackReas = new BuybackReason();
		
		buyBackReas.setLPhysDamage(record.getBuybackDamage().getData());
		buyBackReas.setxDamageDesc(record.getBuybackDamageDescription().getData());
		buyBackReas.setLCustRespRep(record.getBuybackDamageResponsible().getData());
		buyBackReas.setxRepDesc(record.getBuybackDamageResponsibleWhyNot().getData());
		buyBackReas.setLBeenRepaired(record.getBuybackReasonRepaired().getData());
		//buyBackReas.setxRepDesc(record.getBuybackReasonRepairedDescription().getData());
		//buyBackReas.setCBybkReasDlr(Integer.valueOf(record.getComputeRespDealerCode().getData()));
		buyBackReas.setXAddlInfoReas(record.getCustomerDescriptionOfProblem().getData());
		buyBackReas.setlDlrCausByBk(record.getDealerCausedBuybackYN().getData());
		//buyBackReas.setiRepOrdr(Integer.valueOf(record.getRepairOrderNumber().getData()));
		return buyBackReas;
	}
	
	/*Set BybkReasProbMapg to BuyBack*/
	
		public Set<BybkReasProbMapg> toBybkReasProbMapg(Record record) {
			Set<BybkReasProbMapg> bybkReasProb = new HashSet<BybkReasProbMapg>();
			
			//bybkReasProb.setPrimaryProblemCategory(record.getBuybackReasonCategoryAdditional().getElement());
			//for(String )
			
			
			return bybkReasProb;
		}
		
		/*Set CustomerDetail to BuyBack*/
		
		public CustomerDetail toCustomerDetail(Record record) throws ParseException {
			
			CustomerDetail custDetail=new CustomerDetail();
			
			//custDetail.setContactPreferenceCode(record.getContactPreference().getData());
			custDetail.setNCustFirst(record.getCreator().getData());
			//custDetail.setNCustSec(record.getCreator().getData());
			custDetail.setNCustSec(record.getCustomerLastName().getData());
			custDetail.setXCustEmailAddr(record.getCustomerseMailAddress().getData());
			custDetail.setICustPrmryPh(record.getPhone1().getData());
			custDetail.setICustAltPh1(record.getPhone2().getData());
			custDetail.setICustAltPh2(record.getPhone3().getData());
			custDetail.setLRntl(record.getRentalProvided().getData());
			
			//custDetail.setTRntlStrt(stringToTimeStamp(record.getRentalProvidedDate().getData()));
			
			return custDetail;
			
		}
		
		/*Set Warranty to BuyBack*/
		
		public Warranty toWarranty(Record record) {
			Warranty warranty=new Warranty();
			
			warranty.setQVhclCurrMilg(Integer.valueOf(record.getCurrentMileage().getData()));
		
			return warranty;
		}
		
		/*Set BuybackDealerDetail to BuyBack*/
		
		public BuybackDealerDetail toBuybackDealerDetail(Record record) {
			BuybackDealerDetail dealerDetail = new BuybackDealerDetail();
		
			//dealerDetail.setCDlr(record.getDealerCode().getData());
			dealerDetail.setNDlr(record.getDealerContactName().getData());
			dealerDetail.setIDlrPh((record.getDealerPhone()).getData());
			return dealerDetail;
		}
		
		/*Set BuybackEntryOffset to BuyBack*/
		
		public Set<BuybackEntryOffset> toBuybackEntryOffset(Record record) {
			BuybackEntryOffset byBkOffset = new BuybackEntryOffset();
			Set<BuybackEntryOffset> setByBkOffset = new HashSet<BuybackEntryOffset>();
			
			byBkOffset.setAFlatUsageFee(stringToBigDecimal(record.getFlatUsageFee().getData()));
			//byBkOffset.setIMiles(Integer.valueOf(record.getMileageOffsetNumberOfMiles().getData()));
			byBkOffset.setAPurPrc(stringToBigDecimal(record.getMileageOffsetPurchasePrice().getData()));
			byBkOffset.setACostPerMile(stringToBigDecimal(record.getStraightMileage_CostPerMile().getData()));
			//byBkOffset.setAFlatUsageFee(aFlatUsageFee);
			setByBkOffset.addAll(setByBkOffset);
			return setByBkOffset;
		}
		
		/*Set BuybackEntryLogical to BuyBack*/
		
		public BuybackEntryLogical toBuybackEntryLogical(Record record) {
			BuybackEntryLogical bybkLogic = new BuybackEntryLogical();
			
			bybkLogic.setlMilgOffset(record.getISG_MileageOffset().getData());
			//bybkLogic.setiTotOffset(Integer.valueOf(record.getTotalOffset().getData()));
			
			return bybkLogic;
		}
		
		/*Set VehicleDetail to BuyBack*/
		
		public VehicleDetail toVehicleDetail(Record record) {
			VehicleDetail vehicleDetail=new VehicleDetail();
			
			vehicleDetail.setIBybkVin(record.getVIN().getData());
			
			return vehicleDetail;
		}
		
		/*Set BuybackDealerDetail to BuyBack*/
		
		public Set<BuybackDealerDetail> toDealerDetail(Record record) {
			BuybackDealerDetail dealerDetail = new BuybackDealerDetail();
			Set<BuybackDealerDetail> setDealerDetail = new HashSet<BuybackDealerDetail>();
			dealerDetail.setIDlrPh(record.getServiceDealerPhone().getData());
			setDealerDetail.add(dealerDetail);
			
			return setDealerDetail;
		}
	}
	

