package com.chrysler.migration.entity;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * The persistent class for the DASH_BD database table.
 * 
 */
@Entity
@Table(name = "DASH_BD")
@NamedQuery(name = "DashBd.findAll", query = "SELECT d FROM DashBd d")
public class DashBd extends AuditColumns implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "I_DASH_BD_SEQ")
	private int iDashBdSeq;

	// bi-directional many-to-one association to Role
	@ManyToOne
	@JoinColumn(name = "I_ROLE")
	private Role role;

	// bi-directional many-to-one association to DashBdChart
	@OneToMany(mappedBy = "dashBd")
	private List<DashBdChart> dashBdCharts;

	public DashBd() {
	}

	public int getIDashBdSeq() {
		return this.iDashBdSeq;
	}

	public void setIDashBdSeq(int iDashBdSeq) {
		this.iDashBdSeq = iDashBdSeq;
	}

	public Role getRole() {
		return this.role;
	}

	public void setRole(Role role) {
		this.role = role;
	}

	public List<DashBdChart> getDashBdCharts() {
		return this.dashBdCharts;
	}

	public void setDashBdCharts(List<DashBdChart> dashBdCharts) {
		this.dashBdCharts = dashBdCharts;
	}

	public DashBdChart addDashBdChart(DashBdChart dashBdChart) {
		getDashBdCharts().add(dashBdChart);
		dashBdChart.setDashBd(this);

		return dashBdChart;
	}

	public DashBdChart removeDashBdChart(DashBdChart dashBdChart) {
		getDashBdCharts().remove(dashBdChart);
		dashBdChart.setDashBd(null);

		return dashBdChart;
	}

}