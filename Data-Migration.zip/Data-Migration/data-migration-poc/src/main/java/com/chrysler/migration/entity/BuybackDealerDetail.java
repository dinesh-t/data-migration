package com.chrysler.migration.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * The persistent class for the DEALER_DETAIL database table.
 * 
 */
@Entity
@Table(name = "BYBK_DEALER_DETAIL")
@NamedQuery(name = "BuybackDealerDetail.findAll", query = "SELECT d FROM BuybackDealerDetail d")
public class BuybackDealerDetail extends AuditColumns implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "I_BYBK_DLR_SEQ")
	private Integer iDlrSeq;

	// @FieldMapper(name = "dealerId")
	// @Column(name = "C_DLR")
	// private String cDlr;

	@Column(name = "I_DLR_PH")
	private String iDlrPh;

	@Column(name = "N_DLR")
	private String nDlr;

	@Column(name = "X_DLR_CNTCT")
	private String xDlrCntct;

	@Column(name = "X_DLR_EMAIL_ADDR")
	private String xDlrEmailAddr;

	// bi-directional many-to-one association to Buyback
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_BYBK")
	private Buyback buyback;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_DLR_TYP")
	private CodeMaster dealerTypeCode;

	// bi-directional many-to-one association to DealerDetail
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "C_DLR", referencedColumnName = "C_DLR")
	private DealerDetail cDlr;

	public BuybackDealerDetail() {
	}

	public Integer getIDlrSeq() {
		return this.iDlrSeq;
	}

	public void setIDlrSeq(Integer iDlrSeq) {
		this.iDlrSeq = iDlrSeq;
	}

	public DealerDetail getCDlr() {
		return cDlr;
	}

	public void setCDlr(DealerDetail cDlr) {
		this.cDlr = cDlr;
	}

	public String getIDlrPh() {
		return this.iDlrPh;
	}

	public void setIDlrPh(String iDlrPh) {
		this.iDlrPh = iDlrPh;
	}

	public String getNDlr() {
		return this.nDlr;
	}

	public void setNDlr(String nDlr) {
		this.nDlr = nDlr;
	}

	public String getXDlrCntct() {
		return this.xDlrCntct;
	}

	public void setXDlrCntct(String xDlrCntct) {
		this.xDlrCntct = xDlrCntct;
	}

	public String getXDlrEmailAddr() {
		return this.xDlrEmailAddr;
	}

	public void setXDlrEmailAddr(String xDlrEmailAddr) {
		this.xDlrEmailAddr = xDlrEmailAddr;
	}

	public Buyback getBuyback() {
		return this.buyback;
	}

	public void setBuyback(Buyback buyback) {
		this.buyback = buyback;
	}

	public CodeMaster getDealerTypeCode() {
		return dealerTypeCode;
	}

	public void setDealerTypeCode(CodeMaster dealerTypeCode) {
		this.dealerTypeCode = dealerTypeCode;
	}

}