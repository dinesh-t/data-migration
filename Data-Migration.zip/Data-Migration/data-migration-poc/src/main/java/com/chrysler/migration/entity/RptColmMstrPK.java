package com.chrysler.migration.entity;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the RPT_COLM_MSTR database table.
 * 
 */
@Embeddable
public class RptColmMstrPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="I_RPT", insertable=false, updatable=false)
	private int iRpt;

	@Column(name="I_COLM", insertable=false, updatable=false)
	private int iColm;

	public RptColmMstrPK() {
	}
	public int getIRpt() {
		return this.iRpt;
	}
	public void setIRpt(int iRpt) {
		this.iRpt = iRpt;
	}
	public int getIColm() {
		return this.iColm;
	}
	public void setIColm(int iColm) {
		this.iColm = iColm;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof RptColmMstrPK)) {
			return false;
		}
		RptColmMstrPK castOther = (RptColmMstrPK)other;
		return 
			(this.iRpt == castOther.iRpt)
			&& (this.iColm == castOther.iColm);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.iRpt;
		hash = hash * prime + this.iColm;
		
		return hash;
	}
}