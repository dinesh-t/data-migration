package com.chrysler.migration;

import java.lang.reflect.InvocationTargetException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.util.Calendar;
import java.util.Date;

import org.apache.commons.beanutils.PropertyUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;

import com.chrysler.migration.dto.Field;
import com.chrysler.migration.dto.FieldArray;
import com.chrysler.migration.dto.Record;
import com.chrysler.migration.entity.Buyback;
import com.google.gson.Gson;

public class BuybackItemProcessor implements ItemProcessor<Record, Buyback> {

	private static final Logger log = LoggerFactory.getLogger(BuybackItemProcessor.class);

	
	
	@Autowired
	private Transformation transform;	
	
	@Override
	public Buyback process(final Record record) throws ParseException {
		log.info("*** Processing Data - In ***");
		Gson gson = new Gson();
		log.info("*** XML data ***");
		log.info(gson.toJson(record));
		
		
		//Buyback buyback = setValues.setBuyBackValues(record);
		Buyback buyBack=new Buyback();
		Timestamp  ts = new Timestamp(Calendar.getInstance().getTime().getTime());
				
		//buyBack.setiLogonUpd(record.getModifiedBy().getElement().get(0).toString());
		buyBack.settStmpAdd(ts);
		buyBack.settStmpUpd(ts);
		buyBack.setITmpltCair(record.getCAIR_Number().getData());
		buyBack.setlReaqSys(record.getPushedToREAQ().getData());
		buyBack.setIBybkVin(record.getVIN().getData());
		buyBack.setLegalEntry(transform.toLegalEntry(record));
		buyBack.setBuybackPackage(transform.toBuyBackPkg(record));
		buyBack.setBusinessCenterInformation(transform.toBusinessCenterInformation(record));
		buyBack.setBuybackReason(transform.toBuyBackReason(record));
		buyBack.setBybkReasProbMapgs(transform.toBybkReasProbMapg(record));
		buyBack.setCustomerDetail(transform.toCustomerDetail(record));
		buyBack.setWarranty(transform.toWarranty(record));
		buyBack.setBuybackEntryOffsets(transform.toBuybackEntryOffset(record));
		buyBack.setBuybackEntryLogical(transform.toBuybackEntryLogical(record));
		buyBack.setVehicleDetail(transform.toVehicleDetail(record));
		buyBack.setDealerDetails(transform.toDealerDetail(record));
		
		
		log.info("*** Processing Data - Out ***");
		return buyBack;
	}

}
