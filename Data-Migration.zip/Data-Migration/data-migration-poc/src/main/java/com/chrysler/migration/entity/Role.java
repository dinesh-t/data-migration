package com.chrysler.migration.entity;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedAttributeNode;
import javax.persistence.NamedEntityGraph;
import javax.persistence.NamedSubgraph;
import javax.persistence.OneToMany;

/**
 * The persistent class for the ROLE database table.
 * 
 */
@Entity
@NamedEntityGraph(name = "role.findEager", attributeNodes = @NamedAttributeNode(value = "roleFunctions", subgraph = "roleFunctions"), subgraphs = {
		@NamedSubgraph(name = "roleFunctions", attributeNodes = @NamedAttributeNode(value = "roleFunctions", subgraph = "typeMaster")),
		@NamedSubgraph(name = "typeMaster", attributeNodes = @NamedAttributeNode(value = "typeMaster")) })
public class Role extends AuditColumns implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "I_ROLE_SEQ")
	private Integer iRoleSeq;

	@Column(name = "L_ROLE_LVL")
	private String lRoleLvl;

	@Column(name = "N_ROLE")
	private String nRole;

	@Column(name = "X_ROLE_DESC")
	private String xRoleDesc;

	// bi-directional many-to-one association to RoleFunction
	@OneToMany(mappedBy = "role", fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	private Set<RoleFunction> roleFunctions;

	public Role() {
	}

	public Integer getIRoleSeq() {
		return this.iRoleSeq;
	}

	public void setIRoleSeq(Integer iRoleSeq) {
		this.iRoleSeq = iRoleSeq;
	}

	public String getLRoleLvl() {
		return this.lRoleLvl;
	}

	public void setLRoleLvl(String lRoleLvl) {
		this.lRoleLvl = lRoleLvl;
	}

	public String getNRole() {
		return this.nRole;
	}

	public void setNRole(String nRole) {
		this.nRole = nRole;
	}

	public String getXRoleDesc() {
		return this.xRoleDesc;
	}

	public void setXRoleDesc(String xRoleDesc) {
		this.xRoleDesc = xRoleDesc;
	}

	public Set<RoleFunction> getRoleFunctions() {
		return this.roleFunctions;
	}

	public void setRoleFunctions(Set<RoleFunction> roleFunctions) {
		this.roleFunctions = roleFunctions;
	}

	public RoleFunction addRoleFunction(RoleFunction roleFunction) {
		getRoleFunctions().add(roleFunction);
		roleFunction.setRole(this);

		return roleFunction;
	}

	public RoleFunction removeRoleFunction(RoleFunction roleFunction) {
		getRoleFunctions().remove(roleFunction);
		roleFunction.setRole(null);

		return roleFunction;
	}

}