package com.chrysler.migration.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * The persistent class for the RPT_WHERE_COND database table.
 * 
 */
@Entity
@Table(name = "RPT_WHERE_COND")
@NamedQuery(name = "RptWhereCond.findAll", query = "SELECT r FROM RptWhereCond r")
public class RptWhereCond extends AuditColumns implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "I_RPT_COND_SEQ")
	private int iRptCondSeq;

	@Column(name = "C_CLOSE")
	private String cClose;

	@Column(name = "C_INNR_AND_OR_OPTR")
	private String cInnrAndOrOptr;

	@Column(name = "C_OPEN")
	private String cOpen;

	@Column(name = "C_OUTR_AND_OR_OPTR")
	private String cOutrAndOrOptr;

	@Column(name = "I_OPTR")
	private String iOptr;

	@Column(name = "I_VAL")
	private String iVal;

	@Column(name = "L_SHOW")
	private String lShow;

	@Column(name = "L_BYBK")
	private String lBuyback;

	// bi-directional many-to-one association to RptMstr
	@ManyToOne
	@JoinColumn(name = "I_RPT")
	private RptMstr rptMstr;

	// bi-directional many-to-one association to ColumnMaster
	@ManyToOne
	@JoinColumn(name = "I_COLM")
	private ColumnMaster columnMaster;

	@Column(name = "I_WHERE_SEQ")
	private Integer iWhereSeq;

	public RptWhereCond() {
	}

	public int getIRptCondSeq() {
		return this.iRptCondSeq;
	}

	public void setIRptCondSeq(int iRptCondSeq) {
		this.iRptCondSeq = iRptCondSeq;
	}

	public String getCClose() {
		return this.cClose;
	}

	public void setCClose(String cClose) {
		this.cClose = cClose;
	}

	public String getCInnrAndOrOptr() {
		return this.cInnrAndOrOptr;
	}

	public void setCInnrAndOrOptr(String cInnrAndOrOptr) {
		this.cInnrAndOrOptr = cInnrAndOrOptr;
	}

	public String getCOpen() {
		return this.cOpen;
	}

	public void setCOpen(String cOpen) {
		this.cOpen = cOpen;
	}

	public String getCOutrAndOrOptr() {
		return this.cOutrAndOrOptr;
	}

	public void setCOutrAndOrOptr(String cOutrAndOrOptr) {
		this.cOutrAndOrOptr = cOutrAndOrOptr;
	}

	public String getIOptr() {
		return this.iOptr;
	}

	public void setIOptr(String iOptr) {
		this.iOptr = iOptr;
	}

	public String getIVal() {
		return this.iVal;
	}

	public void setIVal(String iVal) {
		this.iVal = iVal;
	}

	public String getLShow() {
		return this.lShow;
	}

	public void setLShow(String lShow) {
		this.lShow = lShow;
	}

	public RptMstr getRptMstr() {
		return this.rptMstr;
	}

	public void setRptMstr(RptMstr rptMstr) {
		this.rptMstr = rptMstr;
	}

	public ColumnMaster getColumnMaster() {
		return this.columnMaster;
	}

	public void setColumnMaster(ColumnMaster columnMaster) {
		this.columnMaster = columnMaster;
	}

	public String getlBuyback() {
		return lBuyback;
	}

	public void setlBuyback(String lBuyback) {
		this.lBuyback = lBuyback;
	}

	public Integer getiWhereSeq() {
		return iWhereSeq;
	}

	public void setiWhereSeq(Integer iWhereSeq) {
		this.iWhereSeq = iWhereSeq;
	}

}