package com.chrysler.migration.entity;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * The persistent class for the AUCTION_DETAIL database table.
 * 
 */
@Entity
@Table(name = "AUCTION_DETAIL")
@NamedQuery(name = "AuctionDetail.findAll", query = "SELECT a FROM AuctionDetail a")
public class AuctionDetail extends AuditColumns implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "I_AUCTN_DTL_SEQ")
	private Integer iAuctnDtlSeq;

	@Column(name = "C_AUCTN_CENTR")
	private String cAuctnCentr;

	@Column(name = "C_CENTR_ZIP")
	private String cCentrZip;

	@Column(name = "I_CENTR_ALT_PH")
	private String iCentrAltPh;

	@Column(name = "I_CENTR_PRMRY_PH")
	private String iCentrPrmryPh;

	@Column(name = "L_AUCTN_CO_RSTRCT")
	private String lAuctnCoRstrct;

	@Column(name = "L_AUCTN_MARSH")
	private String lAuctnMarsh;

	@Column(name = "L_CO_RSTRCT_HAZ")
	private String lCoRstrctHaz;

	@Column(name = "N_AUCTN_CENTR")
	private String nAuctnCentr;

	@Column(name = "N_CENTR_CITY")
	private String nCentrCity;

	@Column(name = "N_CENTR_CNTRY")
	private String nCentrCntry;

	@Column(name = "X_AUCTN_ZONE")
	private String xAuctnZone;

	@Column(name = "X_CENTR_ADDR")
	private String xCentrAddr;

	// bi-directional many-to-one association to AuctionContact
	@OneToMany(mappedBy = "auctionDetail", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	private Set<AuctionContact> auctionContacts;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_AUCTN_TYP")
	private CodeMaster auctionType;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_CENTR_STATE")
	private CodeMaster state;

	public AuctionDetail() {
	}

	public Integer getIAuctnDtlSeq() {
		return this.iAuctnDtlSeq;
	}

	public void setIAuctnDtlSeq(Integer iAuctnDtlSeq) {
		this.iAuctnDtlSeq = iAuctnDtlSeq;
	}

	public String getCAuctnCentr() {
		return this.cAuctnCentr;
	}

	public void setCAuctnCentr(String cAuctnCentr) {
		this.cAuctnCentr = cAuctnCentr;
	}

	public String getCCentrZip() {
		return this.cCentrZip;
	}

	public void setCCentrZip(String cCentrZip) {
		this.cCentrZip = cCentrZip;
	}

	public String getICentrAltPh() {
		return this.iCentrAltPh;
	}

	public void setICentrAltPh(String iCentrAltPh) {
		this.iCentrAltPh = iCentrAltPh;
	}

	public String getICentrPrmryPh() {
		return this.iCentrPrmryPh;
	}

	public void setICentrPrmryPh(String iCentrPrmryPh) {
		this.iCentrPrmryPh = iCentrPrmryPh;
	}

	public String getLAuctnCoRstrct() {
		return this.lAuctnCoRstrct;
	}

	public void setLAuctnCoRstrct(String lAuctnCoRstrct) {
		this.lAuctnCoRstrct = lAuctnCoRstrct;
	}

	public String getLAuctnMarsh() {
		return this.lAuctnMarsh;
	}

	public void setLAuctnMarsh(String lAuctnMarsh) {
		this.lAuctnMarsh = lAuctnMarsh;
	}

	public String getLCoRstrctHaz() {
		return this.lCoRstrctHaz;
	}

	public void setLCoRstrctHaz(String lCoRstrctHaz) {
		this.lCoRstrctHaz = lCoRstrctHaz;
	}

	public String getNAuctnCentr() {
		return this.nAuctnCentr;
	}

	public void setNAuctnCentr(String nAuctnCentr) {
		this.nAuctnCentr = nAuctnCentr;
	}

	public String getNCentrCity() {
		return this.nCentrCity;
	}

	public void setNCentrCity(String nCentrCity) {
		this.nCentrCity = nCentrCity;
	}

	public String getNCentrCntry() {
		return this.nCentrCntry;
	}

	public void setNCentrCntry(String nCentrCntry) {
		this.nCentrCntry = nCentrCntry;
	}

	public String getXAuctnZone() {
		return this.xAuctnZone;
	}

	public void setXAuctnZone(String xAuctnZone) {
		this.xAuctnZone = xAuctnZone;
	}

	public String getXCentrAddr() {
		return this.xCentrAddr;
	}

	public void setXCentrAddr(String xCentrAddr) {
		this.xCentrAddr = xCentrAddr;
	}

	public Set<AuctionContact> getAuctionContacts() {
		return this.auctionContacts;
	}

	public void setAuctionContacts(Set<AuctionContact> auctionContacts) {
		this.auctionContacts = auctionContacts;
	}

	public AuctionContact addAuctionContact(AuctionContact auctionContact) {
		getAuctionContacts().add(auctionContact);
		auctionContact.setAuctionDetail(this);

		return auctionContact;
	}

	public AuctionContact removeAuctionContact(AuctionContact auctionContact) {
		getAuctionContacts().remove(auctionContact);
		auctionContact.setAuctionDetail(null);

		return auctionContact;
	}

	public CodeMaster getAuctionType() {
		return auctionType;
	}

	public void setAuctionType(CodeMaster auctionType) {
		this.auctionType = auctionType;
	}

	public CodeMaster getState() {
		return state;
	}

	public String getStateValue() {

		return state != null ? state.getXFldVal() : null;
	}

	public void setState(CodeMaster state) {
		this.state = state;
	}

}