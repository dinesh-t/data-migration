package com.chrysler.migration.entity;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * The persistent class for the DEALER_RESTRICTION database table.
 * 
 */
@Entity
@Table(name = "DEALER_RESTRICTION")
@NamedQuery(name = "DealerRestriction.findAll", query = "SELECT d FROM DealerRestriction d")
public class DealerRestriction extends AuditColumns implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "I_DLR_RSTRN_SEQ")
	private int iDlrRstrnSeq;

	@Column(name = "D_RSTRN_END")
	private Timestamp dRstrnEnd;

	@Column(name = "D_RSTRN_STRT")
	private Timestamp dRstrnStrt;

	@Column(name = "L_DLR_RSTRCT")
	private String lDlrRstrct;

	@Column(name = "X_RSTRN_REAS")
	private String xRstrnReas;

	// bi-directional many-to-one association to CodeMaster
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_TYP_CATGY")
	private CodeMaster vehicleTypeCategory;

	// bi-directional many-to-one association to DealerDetail
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "I_DLR_DTL")
	private DealerDetail dealerDetail;

	public DealerRestriction() {
	}

	public int getIDlrRstrnSeq() {
		return this.iDlrRstrnSeq;
	}

	public void setIDlrRstrnSeq(int iDlrRstrnSeq) {
		this.iDlrRstrnSeq = iDlrRstrnSeq;
	}

	public Timestamp getDRstrnEnd() {
		return this.dRstrnEnd;
	}

	public void setDRstrnEnd(Timestamp dRstrnEnd) {
		this.dRstrnEnd = dRstrnEnd;
	}

	public Timestamp getDRstrnStrt() {
		return this.dRstrnStrt;
	}

	public void setDRstrnStrt(Timestamp dRstrnStrt) {
		this.dRstrnStrt = dRstrnStrt;
	}

	public String getLDlrRstrct() {
		return this.lDlrRstrct;
	}

	public void setLDlrRstrct(String lDlrRstrct) {
		this.lDlrRstrct = lDlrRstrct;
	}

	public String getXRstrnReas() {
		return this.xRstrnReas;
	}

	public void setXRstrnReas(String xRstrnReas) {
		this.xRstrnReas = xRstrnReas;
	}

	public CodeMaster getVehicleTypeCategory() {
		return vehicleTypeCategory;
	}

	public void setVehicleTypeCategory(CodeMaster vehicleTypeCategory) {
		this.vehicleTypeCategory = vehicleTypeCategory;
	}

	public DealerDetail getDealerDetail() {
		return this.dealerDetail;
	}

	public void setDealerDetail(DealerDetail dealerDetail2) {
		this.dealerDetail = dealerDetail2;
	}

}