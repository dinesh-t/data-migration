package com.chrysler.migration.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;


/**
 * The persistent class for the BYBK_CN_RESALE_STATE database table.
 * 
 */
@Entity
@Table(name="BYBK_CN_RESALE_STATE")
@NamedQuery(name="BybkCnResaleState.findAll", query="SELECT b FROM BybkCnResaleState b")
public class BybkCnResaleState extends AuditColumns implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="I_RESALE_SEQ")
	private int iResaleSeq;

	//bi-directional many-to-one association to Buyback
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="I_BYBK")
	private Buyback buyback;

	//bi-directional many-to-one association to CodeMaster
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="I_RESALE_STATE")
	private CodeMaster codeMaster;

	public BybkCnResaleState() {
	}

	public int getIResaleSeq() {
		return this.iResaleSeq;
	}

	public void setIResaleSeq(int iResaleSeq) {
		this.iResaleSeq = iResaleSeq;
	}

	public Buyback getBuyback() {
		return this.buyback;
	}

	public void setBuyback(Buyback buyback) {
		this.buyback = buyback;
	}

	public CodeMaster getCodeMaster() {
		return this.codeMaster;
	}

	public void setCodeMaster(CodeMaster codeMaster) {
		this.codeMaster = codeMaster;
	}

}